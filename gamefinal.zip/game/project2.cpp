#include<stdio.h>
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<SDL2/SDL_timer.h>
#include<GL/gl.h>
#include<math.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>	
#include<bits/stdc++.h>
#include<time.h>


//Global declaration
	
	int RED=1,GREEN=2,BLUE=3,YELLOW=4;
	int level=1;
	int i,j,k;
	int doorclose[4]={0};
	
	SDL_Window* win;
	SDL_Renderer* rend;
	
	SDL_Surface* num;
	SDL_Texture* one;
	SDL_Texture* two;
	SDL_Texture* three;
	SDL_Texture* four;
	SDL_Texture* five;
	SDL_Texture* six;
	SDL_Texture* seven;
	SDL_Texture* eight;
	SDL_Texture* nine;
	
	SDL_Surface* grassfield;
	SDL_Texture* Grassfield;
	
	SDL_Surface* door1;
	SDL_Texture* DoorR;
	SDL_Surface* door2;
	SDL_Texture* DoorG;
	SDL_Surface* door3;
	SDL_Texture* DoorB;
	SDL_Surface* door4;
	SDL_Texture* DoorYe;
	
	SDL_Surface* ladder1;
	SDL_Surface* ladder2;
	SDL_Texture* Ladder;
	SDL_Texture* Ladder1;
	
	SDL_Surface* swtch1;
	SDL_Surface* swtch2;
	SDL_Surface* swtch3;
	SDL_Surface* swtch4;
	SDL_Surface* swtchoff1;
	SDL_Surface* swtchoff2;
	SDL_Surface* swtchoff3;
	SDL_Surface* swtchoff4;
	SDL_Texture* SwitchR;
	SDL_Texture* SwitchB;
	SDL_Texture* SwitchG;
	SDL_Texture* SwitchY;
	SDL_Texture* SwitchRoff;
	SDL_Texture* SwitchGoff;
	SDL_Texture* SwitchBoff;
	SDL_Texture* SwitchYoff;
	
	SDL_Surface* jack;
	SDL_Texture* Jackrest;
	SDL_Texture* Jackwalk1;
	SDL_Texture* Jackwalk2;
	SDL_Texture* Jackwalk3;
	SDL_Texture* Jackwalk4;
	SDL_Texture* Jackwalk5;
	SDL_Texture* Jackwalk6;
	SDL_Texture* Jackwalk7;
	SDL_Texture* Jackwalk8;
	SDL_Texture* Jackclimb1;
	SDL_Texture* Jackclimb2;
	SDL_Texture* Jackdrag;
	
	SDL_Surface* paper;
	SDL_Texture* PRoll;
		
	SDL_Surface* box;
	SDL_Texture* BoxS;
	SDL_Surface* barrel;
	SDL_Texture* Barrel;
	SDL_Rect JACKK;		
	SDL_Event event;
	SDL_Event e;
	
// Function



	void arrayprint(int a[],int sizea){
		int i;
		for(i=0;i<sizea;i++){
		
			printf("%d\t",a[i]);
		
		}
		printf("\n");
	
	
	
	
	
	
	
	}
	
	void matrixprint(int a[9][9],int b){
		int i,j;
		printf("\n#############################\n");
		for(i=0;i<b;i++){
			for(j=0;j<b;j++){
			
				printf("%d ",a[i][j]);	
			
			}
			printf("\n");
		}		
	
		printf("#############################\n");
	}

	void Grass(int t,int GrassX[],int GrassY[],int GrassNum[]){
		int i=0,j=0;
		SDL_Rect GRASSFIELD;
		SDL_QueryTexture(Grassfield,NULL,NULL,&GRASSFIELD.w,&GRASSFIELD.h);
		GRASSFIELD.h=60;
		GRASSFIELD.w=60;
		
		for(j=0;j<t;j++){
			for(i=0;i<GrassNum[j];i++){
				GRASSFIELD.x=GrassX[j]+60*i;
				GRASSFIELD.y=GrassY[j];
				SDL_RenderCopy(rend,Grassfield,NULL,&GRASSFIELD);
			}
		
			if(j==0){
				SDL_RenderCopy(rend,one,NULL,&GRASSFIELD);
			}
			else if(j==1){
				SDL_RenderCopy(rend,two,NULL,&GRASSFIELD);
			}
			else if(j==2){
				SDL_RenderCopy(rend,three,NULL,&GRASSFIELD);
			}
			else if(j==3){
				SDL_RenderCopy(rend,four,NULL,&GRASSFIELD);
			}
			else if(j==4){
				SDL_RenderCopy(rend,five,NULL,&GRASSFIELD);
			}
			else if(j==5){
				SDL_RenderCopy(rend,six,NULL,&GRASSFIELD);
			}
			else if(j==6){
				SDL_RenderCopy(rend,seven,NULL,&GRASSFIELD);
			}
			else if(j==7){
				SDL_RenderCopy(rend,eight,NULL,&GRASSFIELD);
			}
			else if(j==8){
				SDL_RenderCopy(rend,nine,NULL,&GRASSFIELD);
			}
			
		}	
	
	}
	
	void Lad(int t,int LadderX[],int LadderY[],int LadderNum[]){
		int i=0,j=0;
		SDL_Rect LADDER;
		SDL_QueryTexture(Ladder,NULL,NULL,&LADDER.w,&LADDER.h);
		LADDER.h=60;
		LADDER.w=50;
		
		for(j=0;j<t;j++){
			for(i=0;i<LadderNum[j];i++){
				LADDER.x=LadderX[j]+5;
				LADDER.y=LadderY[j]-60-60*i;
				SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
			}
			if(LadderNum[j]!=0 && LadderX[j]!=0 && LadderY[j]!=0){
			LADDER.y=LadderY[j]-60-60*(LadderNum[j]-1)-60;
			SDL_RenderCopy(rend,Ladder1,NULL,&LADDER);
			}
		}
			
	
	}

	void Grid(){
	
		SDL_SetRenderDrawColor(rend,0,0,0,SDL_ALPHA_OPAQUE);
		SDL_RenderDrawLine(rend,0,0,1920,1080);
		SDL_RenderDrawLine(rend,0,1080,1920,0);

	
		SDL_SetRenderDrawColor(rend,100,100,100,SDL_ALPHA_OPAQUE);
	
		SDL_Rect Display;
		Display.x=0;
		Display.y=0;
		Display.h=1080;
		Display.w=1920;
	
	
	
		SDL_RenderFillRect(rend,&Display);	
		SDL_SetRenderDrawColor(rend,0,0,0,SDL_ALPHA_OPAQUE);
		int hor,ver;
		for(hor=0;hor<=1920;hor=hor+10){
			SDL_RenderDrawLine(rend,hor,0,hor,1080);
		}
		for(ver=0;ver<=1080;ver=ver+10){
			SDL_RenderDrawLine(rend,0,ver,1920,ver);
		}	
		
		SDL_SetRenderDrawColor(rend,255,0,0,SDL_ALPHA_OPAQUE);
		for(hor=0;hor<=1920;hor=hor+100){
			SDL_RenderDrawLine(rend,hor,0,hor,1080);
		}
		for(ver=0;ver<=1080;ver=ver+100){
			SDL_RenderDrawLine(rend,0,ver,1920,ver);
		}		
	
	
	
	
	}
	
	
	void Switch(int t, int SwtchX[],int SwtchY[],int SwitchColour[],int SwitchCon[]){
		int i;
		
		
		
		for(i=0;i<t;i++){
		
			SDL_Rect SWITCH;
			SWITCH.h=30;
			SWITCH.w=40;
			
			SDL_Rect SWITCHOFF;
			SDL_QueryTexture(SwitchRoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SDL_QueryTexture(SwitchGoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SDL_QueryTexture(SwitchBoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SDL_QueryTexture(SwitchYoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SWITCHOFF.h=30;
			SWITCHOFF.w=40;
		
		
			SWITCH.x=SwtchX[i]+10;
			SWITCH.y=SwtchY[i]-30;
			SWITCHOFF.x=SwtchX[i]+10;
			SWITCHOFF.y=SwtchY[i]-25;
		if(SwitchColour[i]==1){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchR,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchRoff,NULL,&SWITCHOFF);
			}
		
		
		}
		else if(SwitchColour[i]==2){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchG,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchGoff,NULL,&SWITCHOFF);
			}
		
		}
		else if(SwitchColour[i]==3){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchB,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchBoff,NULL,&SWITCHOFF);
			}
		
		}
		else if(SwitchColour[i]==4){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchY,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchYoff,NULL,&SWITCHOFF);
			}
		
		}
		}
	
	}
	
	
	
	void Door(int t, int DoorX[],int DoorY[],int DoorColour[],int SwitchCon[]){
		int i;
		
			SDL_Rect DOORR;
			SDL_QueryTexture(DoorR,NULL,NULL,&DOORR.w,&DOORR.h);
			DOORR.h=80-0.25*doorclose[0];
			DOORR.w=20;
			DOORR.x=DoorX[0];
			DOORR.y=DoorY[0]-80+0.25*doorclose[0];
			
			SDL_Rect DOORG;
			SDL_QueryTexture(DoorG,NULL,NULL,&DOORG.w,&DOORG.h);
			DOORG.h=80-0.25*doorclose[1];
			DOORG.w=20;
			DOORG.x=DoorX[1];
			DOORG.y=DoorY[1]-80+0.25*doorclose[1];
			
			SDL_Rect DOORB;
			SDL_QueryTexture(DoorB,NULL,NULL,&DOORB.w,&DOORB.h);
			DOORB.h=80-0.25*doorclose[2];
			DOORB.w=20;
			DOORB.x=DoorX[2];
			DOORB.y=DoorY[2]-80+0.25*doorclose[2];
			
			SDL_Rect DOORYE;
			SDL_QueryTexture(DoorYe,NULL,NULL,&DOORYE.w,&DOORYE.h);
			DOORYE.h=80-0.25*doorclose[3];
			DOORYE.w=20;
			DOORYE.x=DoorX[3];
			DOORYE.y=DoorY[3]-80+0.25*doorclose[3];
			
				
		
		for(i=0;i<t;i++){
	
		if(DoorColour[i]==1){
			if(SwitchCon[i]==1  && DOORR.h>-80 ){
				doorclose[i]=doorclose[i]+5;
				if(doorclose[i]>4*80){
					doorclose[i]=4*160;
				}
			}
			else if(SwitchCon[i]==0 && DOORR.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}	
			SDL_RenderCopy(rend,DoorR,NULL,&DOORR);
		
		}
		else if(DoorColour[i]==2){
			if(SwitchCon[i]==1 && DOORG.h>-80){
				doorclose[i]=doorclose[i]+5;
				
			}
			else if(SwitchCon[i]==0 && DOORG.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}
			SDL_RenderCopy(rend,DoorG,NULL,&DOORG);
		}
		else if(DoorColour[i]==3){
			if(SwitchCon[i]==1  && DOORB.h>-80){
				doorclose[i]=doorclose[i]+5;
			}
			else if(SwitchCon[i]==0 && DOORB.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}
			SDL_RenderCopy(rend,DoorB,NULL,&DOORB);
		}
		else if(DoorColour[i]==4){
			if(SwitchCon[i]==1  && DOORYE.h>-80){
				doorclose[i]=doorclose[i]+5;
			}
			else if(SwitchCon[i]==0  && DOORYE.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}
			SDL_RenderCopy(rend,DoorYe,NULL,&DOORYE);
		
		}
		}
	
	}
	
	
	int Max(int MaxN,int maxcom[],int MAXX){
			int j;
					for(j=0;j<MaxN;j++){
						if(MAXX<=maxcom[j]){
						MAXX=maxcom[j];
						}
					}

				
				return MAXX;

			}
	
	int FirstUp(int grassX[],int grassY[],int t){
		int i,j,firstup=2000;
		for(i=0;i<t;i++){
		
			if(grassX[i]<=firstup){
				firstup=grassX[i];
			}
		
		}
		int upfirst=2000,min=2000;
		for(i=0;i<t;i++){
		
			if(grassY[i]<=min && grassX[i]==firstup){
				min=grassY[i];
				upfirst=i;
			}
		
		}
	
	
		return upfirst;
	}
	
	int LastUp(int grassX[],int grassY[],int grassNum[], int t){
		int i,j,lastup=0;
		for(i=0;i<t;i++){
		
			if(grassX[i]+grassNum[i]*60>=lastup){
				lastup=grassX[i]+grassNum[i]*60;
			}
		
		}
		int uplast=0,max=0;
		for(i=0;i<t;i++){
		
			if(grassY[i]>=max && grassX[i]+grassNum[i]*60==lastup){
				max=grassY[i];
				uplast=i;
			}
		
		}
	
	
		return uplast;
	}
	
	
	
			
	
	void Jack(int JackX,int JackY,int JackF,int JackR,int JackL,int JackU,int JackD){
				
		SDL_QueryTexture(Jackrest,NULL,NULL,&JACKK.w,&JACKK.h);
		JACKK.h=80;
		JACKK.w=60;
		JACKK.x=JackX+5*JackR-5*JackL;
		JACKK.y=JackY-80+5*JackD-5*JackU+5*JackF;
	
	
	
	
		SDL_RenderCopy(rend,Jackrest,NULL,&JACKK);
	}




	void Scroll(int scrollx,int scrolly){
		
		SDL_Rect PROLL;
		SDL_QueryTexture(PRoll,NULL,NULL,&PROLL.w,&PROLL.h);
		PROLL.h=50;
		PROLL.w=20;
		PROLL.x=scrollx;
		PROLL.y=scrolly-60;
	
		SDL_RenderCopy(rend,PRoll,NULL,&PROLL);
	
	}

		
	

	int RightValid(int grassX[],int grassY[],int grassNum[],int t){
		int p=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.y==grassY[i]-80 && JACKK.x>=grassX[i]-60 && JACKK.x+60<grassX[i]+grassNum[i]*60+60){
				p=1;
			}
		
		
		
		}
		
		
		return p;
	}


	int LeftValid(int grassX[],int grassY[],int grassNum[],int t){
		int p=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.y==grassY[i]-80 && JACKK.x>grassX[i]-60 && JACKK.x+60<=grassX[i]+grassNum[i]*60+60){
				p=1;
			}
		
		
		
		}
		
		
		return p;
	}
	
	int DownValid(int LadderX[],int LadderY[],int LadderNum[],int t){
		int p=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.x==LadderX[i] && JACKK.y+80<LadderY[i] && JACKK.y+80>=LadderY[i]-LadderNum[i]*60){
				p=1;
			}
		
		
		
		}
		
		
		return p;
	}

	int UpValid(int LadderX[],int LadderY[],int LadderNum[],int t){
		int p=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.x==LadderX[i] && JACKK.y+80<=LadderY[i] && JACKK.y+80>LadderY[i]-LadderNum[i]*60){
				p=1;
			}		
		
		
		}
		
		
		return p;
	}
	
	
	int FallValid(int grassX[],int grassY[],int grassNum[],int t1,int LadderX[],int LadderY[],int LadderNum[],int t2){
		int p=1;
		int i,j,k;
		for(i=0;i<t1;i++){
			if((JACKK.y==grassY[i]-80 && JACKK.x>grassX[i]-60 && JACKK.x+60<grassX[i]+grassNum[i]*60+60)){
				p=0;
				break;
			}		
		}
		
		for(i=0;i<t2;i++){
			if((JACKK.x==LadderX[i] && JACKK.y+80<=LadderY[i] && JACKK.y+80>=LadderY[i]-LadderNum[i]*60)){			
				p=0;
				break;
			}
		}
		
		
		return p;
	}
	
	
	int SwitchCondition(int switchX[],int switchY[],int t){
		if((JACKK.x>switchX[t]-30 && JACKK.x+50<switchX[t]+40+30 && JACKK.y+80==switchY[t])){
			return 1;
		}
		else{
			return 0;
		}
	
	}



	void Box(int BoxX[],int BoxY[],int t,int boxr,int boxl,int boxf){
	
		SDL_Rect BOXX;
		SDL_QueryTexture(BoxS,NULL,NULL,&BOXX.w,&BOXX.h);
		BOXX.h=80;
		BOXX.w=80;
		
		for(i=0;i<t;i++){
			BOXX.x=BoxX[i]+5*boxr-5*boxl;
			BOXX.y=BoxY[i]-80+5*boxf;
		
			SDL_RenderCopy(rend,BoxS,NULL,&BOXX);
		}
	}
	
	
	void BARL(int BarX,int BarY,int barr,int barl,int barf){
	
		SDL_Rect BARREL;
		SDL_QueryTexture(Barrel,NULL,NULL,&BARREL.w,&BARREL.h);
		BARREL.h=60;
		BARREL.w=60;
		
		
		BARREL.x=BarX+5*barr-5*barl;
		BARREL.y=BarY-60+5*barf;
		SDL_RenderCopy(rend,Barrel,NULL,&BARREL);
	}
	
	
	
	
	void BoxRightValid(int grassX[],int grassY[],int grassNum[],int t){
	
	
	
	}
	



























//END























int main(int agr, char* args[]){

	
	if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_AUDIO)!=0){
		printf("Video or timer error:%s\n",SDL_GetError());
	}
	if(!(IMG_Init(IMG_INIT_PNG))){
		printf("Image error:%s\n",IMG_GetError());
	}
	if(!(IMG_Init(IMG_INIT_JPG))){
		printf("Image error:%s\n",IMG_GetError());
	}
	printf("Initialization Complete");
	
	if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048)<0)
	{
	printf("Error");
	}	
	if(TTF_Init()<0){
		printf("ERROR");
	}
	
	int ScreenHeight=1080;
	int ScreenWidth=1920;
	int zerox=960;
	int zeroy=540;
	
	
	
	
//###################################################################################################
//function
	
		
		
//##############################################################################################
	
//Window loading

	SDL_Window* winload = SDL_CreateWindow("Dr Maddy",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, 500 , 400 ,SDL_WINDOW_BORDERLESS);
	
	
	Uint32 render_flagsload= SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;	
	SDL_Renderer* rendload= SDL_CreateRenderer(winload,-1,render_flagsload);
	SDL_Surface* Sur_load =IMG_Load("Texture/Loading/output-onlinepngtools(3).png");
	SDL_Texture* Tex_load =SDL_CreateTextureFromSurface(rendload,Sur_load);
	SDL_FreeSurface(Sur_load);

	SDL_Rect load;
	
	SDL_QueryTexture(Tex_load,NULL,NULL,&load.h,&load.w);
	load.h=400;
	load.w=500;
	load.x=0;
	load.y=0;
	
	SDL_RenderClear(rendload);
	
	
	SDL_RenderCopy(rendload, Tex_load, NULL,&load); 
	SDL_RenderPresent(rendload);
	SDL_Delay(2000);	
	
	Sur_load =IMG_Load("Texture/Loading/Loading motion.png");
	SDL_Texture* Tex_load3 =SDL_CreateTextureFromSurface(rendload,Sur_load);
	SDL_FreeSurface(Sur_load);
	
	SDL_Rect loc_2;
	SDL_QueryTexture(Tex_load3,NULL,NULL,&loc_2.w,&loc_2.h);
	loc_2.h=65;
	loc_2.w=65;
	loc_2.x=300;
	loc_2.y=170;
	
	Sur_load =IMG_Load("Texture/Loading/Loading Bar .png");
	SDL_Texture* Tex_load2 =SDL_CreateTextureFromSurface(rendload,Sur_load);
	SDL_FreeSurface(Sur_load);
	SDL_Rect loc_1;
	SDL_QueryTexture(Tex_load2,NULL,NULL,&loc_1.w,&loc_1.h);
	loc_1.h=30;
	loc_1.w=0;
	loc_1.x=0;
	loc_1.y=322.4;
	
	float p=30;
	int stop=0,speed=1;	
	while(loc_1.w!=800){
		loc_1.w+=5;
		p+=5*speed;
		stop++;
		if(stop%36>28){
			speed=0;
		}
		if(stop%36<15){
			speed=1;
		}
		if(stop%36<28 && stop%36>15){
			speed=2;
		}
		SDL_Delay(25);

		SDL_RenderClear(rendload);
		
		
		SDL_RenderCopy(rendload, Tex_load, NULL, &load);
		SDL_RenderCopyEx(rendload,Tex_load3,NULL,&loc_2,p,NULL,SDL_FLIP_NONE);
		SDL_RenderCopy(rendload, Tex_load2, NULL, &loc_1);
		SDL_RenderPresent(rendload);
	}
	//800
	SDL_Delay(0);
	SDL_DestroyRenderer(rendload);
	SDL_DestroyWindow(winload);
	//600
	SDL_Delay(0);


//##################################################################################################






//#################################################################################################
//Starting Menu

	win = SDL_CreateWindow("Dr Maddy",SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,1280,960,SDL_WINDOW_FULLSCREEN_DESKTOP);
	Uint32 render_flags= SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;	
	rend= SDL_CreateRenderer(win,-1,render_flags);
	SDL_Surface* Sur_Bg =IMG_Load("Texture/Starting/Warwolf.png");
	SDL_Texture* Tex_Bg_1 =SDL_CreateTextureFromSurface(rend,Sur_Bg);	
	SDL_FreeSurface(Sur_Bg);
	SDL_Rect war;
	SDL_QueryTexture(Tex_Bg_1,NULL,NULL,&war.w,&war.h);
	war.h=200;
	war.w=700;
	war.x=610;
	war.y=440;
	
	SDL_Rect FullRect;
	FullRect.w=1920;
	FullRect.h=1080;
	FullRect.x=0;
	FullRect.y=0;
	
	SDL_RenderDrawRect(rend,&FullRect);
	SDL_SetRenderDrawColor(rend,20,20,20,0);
	SDL_RenderFillRect(rend,&FullRect);
	int q=0;
	p=1;
	int pp=1;
	while(p!=0){
		if(q==0){
			p=p+1;
		}
		else{
			p=p-1;
		}
		if(p==255){
			q=1;
		}
		if(p<60){
			//0.5
			SDL_Delay(0.1);
		}
		else{	
			//0.2
			SDL_Delay(0.04);
		}
		SDL_SetTextureBlendMode(Tex_Bg_1,SDL_BLENDMODE_ADD);
		SDL_SetTextureAlphaMod(Tex_Bg_1,p);
		SDL_RenderClear(rend);
		SDL_RenderCopy(rend,Tex_Bg_1, NULL, &war);
		SDL_RenderPresent(rend);
		if(p==2 && q==0){
			//350
			SDL_Delay(0);
		}
	}
	
	//200
	SDL_Delay(0);
	
	Sur_Bg =IMG_Load("Texture/BgMenu/Background.png");
	SDL_Texture* Tex_Bg =SDL_CreateTextureFromSurface(rend,Sur_Bg);	
	SDL_FreeSurface(Sur_Bg);
	
	SDL_Surface* Cloud1=IMG_Load("Texture/BgMenu/Cloud.png");
	SDL_Surface* Cloud2=IMG_Load("Texture/BgMenu/Cloud3.png");
	SDL_Surface* Cloud3=IMG_Load("Texture/BgMenu/Cloud2rightlast.png");
	SDL_Surface* Leaf1=IMG_Load("Texture/BgMenu/Leaf.png");
	SDL_Surface* Leaf2=IMG_Load("Texture/BgMenu/Leaf2.png");
	SDL_Surface* Leaf3=IMG_Load("Texture/BgMenu/Leaf 3.png");
	SDL_Surface* Leaf4=IMG_Load("Texture/BgMenu/Leaf4.png");
	SDL_Surface* Leaf5=IMG_Load("Texture/BgMenu/Leaf5.png");
	SDL_Surface* Leaf6=IMG_Load("Texture/BgMenu/Leaf6.png");
	SDL_Surface* Bush=IMG_Load("Texture/BgMenu/Bush.png");
	SDL_Surface* Tree=IMG_Load("Texture/BgMenu/Tree.png");
	SDL_Surface* Fall=IMG_Load("Texture/BgMenu/FallingLeaf.png");
	SDL_Surface* sty=IMG_Load("Texture/Story.png");
	SDL_Surface* ran=IMG_Load("Texture/Random.png");
	SDL_Surface* lv1=IMG_Load("Texture/num1.png");
	SDL_Surface* lv2=IMG_Load("Texture/num2.png");
	SDL_Surface* lv3=IMG_Load("Texture/num3.png");
	SDL_Surface* lv4=IMG_Load("Texture/num4.png");
	SDL_Surface* lv5=IMG_Load("Texture/num5.png");
	SDL_Surface* lv6=IMG_Load("Texture/num6.png");
	SDL_Surface* lv7=IMG_Load("Texture/num7.png");
	SDL_Surface* lv8=IMG_Load("Texture/num8.png");
	SDL_Surface* lv9=IMG_Load("Texture/num9.png");
	SDL_Surface* lv10=IMG_Load("Texture/num10.png");
	
	
	
	SDL_Texture* c1= SDL_CreateTextureFromSurface(rend,Cloud1);
	SDL_Texture* c2= SDL_CreateTextureFromSurface(rend,Cloud2);
	SDL_Texture* c3= SDL_CreateTextureFromSurface(rend,Cloud3);
	SDL_Texture* l1= SDL_CreateTextureFromSurface(rend,Leaf1);
	SDL_Texture* l2= SDL_CreateTextureFromSurface(rend,Leaf2);
	SDL_Texture* l3= SDL_CreateTextureFromSurface(rend,Leaf3);
	SDL_Texture* l4= SDL_CreateTextureFromSurface(rend,Leaf4);
	SDL_Texture* l5= SDL_CreateTextureFromSurface(rend,Leaf5);
	SDL_Texture* l6= SDL_CreateTextureFromSurface(rend,Leaf6);
	SDL_Texture* b1= SDL_CreateTextureFromSurface(rend,Bush);
	SDL_Texture* t1= SDL_CreateTextureFromSurface(rend,Tree);
	SDL_Texture* f1= SDL_CreateTextureFromSurface(rend,Fall);
	
	SDL_Texture* num1= SDL_CreateTextureFromSurface(rend,lv1);
	SDL_Texture* num2= SDL_CreateTextureFromSurface(rend,lv2);
	SDL_Texture* num3= SDL_CreateTextureFromSurface(rend,lv3);
	SDL_Texture* num4= SDL_CreateTextureFromSurface(rend,lv4);
	SDL_Texture* num5= SDL_CreateTextureFromSurface(rend,lv5);
	SDL_Texture* num6= SDL_CreateTextureFromSurface(rend,lv6);
	SDL_Texture* num7= SDL_CreateTextureFromSurface(rend,lv7);
	SDL_Texture* num8= SDL_CreateTextureFromSurface(rend,lv8);
	SDL_Texture* num9= SDL_CreateTextureFromSurface(rend,lv9);
	SDL_Texture* num10= SDL_CreateTextureFromSurface(rend,lv10);
	
	SDL_Texture* Story= SDL_CreateTextureFromSurface(rend,sty);
	SDL_Texture* Random= SDL_CreateTextureFromSurface(rend,ran);
	
	SDL_Surface* ui=IMG_Load("Texture/BgMenu/Menu Background.png");
	SDL_Texture* UI=SDL_CreateTextureFromSurface(rend,ui);
	
	SDL_Surface* uit=IMG_Load("Texture/BgMenu/Menu Text.png");
	SDL_Texture* UIt=SDL_CreateTextureFromSurface(rend,uit);
		
		TTF_Font* font1=TTF_OpenFont("Font/ChrustyRock-ORLA.ttf",70);

		SDL_Surface* surfont= TTF_RenderText_Solid(font1,"Play",{100,100,100});
		SDL_Texture* textf=SDL_CreateTextureFromSurface(rend,surfont);
		SDL_FreeSurface(surfont);
		
	SDL_Surface* pl=IMG_Load("Texture/BgMenu/Play.png");
	SDL_Texture* Play=SDL_CreateTextureFromSurface(rend,pl);	
	
	SDL_Surface* le=IMG_Load("Texture/BgMenu/Level.png");
	SDL_Texture* Level=SDL_CreateTextureFromSurface(rend,le);	
	
	SDL_Surface* op=IMG_Load("Texture/BgMenu/Option.png");
	SDL_Texture* Option=SDL_CreateTextureFromSurface(rend,op);	
	
	SDL_Surface* qu=IMG_Load("Texture/BgMenu/Quit.png");
	SDL_Texture* Quit=SDL_CreateTextureFromSurface(rend,qu);	
	
	SDL_Surface* bgmon=IMG_Load("Texture/BgMenu/Musicon.png");
	SDL_Texture* Bgmon=SDL_CreateTextureFromSurface(rend,bgmon);
	
	SDL_Surface* bgmoff=IMG_Load("Texture/BgMenu/Musicoff.png");
	SDL_Texture* Bgmoff=SDL_CreateTextureFromSurface(rend,bgmoff);
	
	SDL_Surface* seon=IMG_Load("Texture/BgMenu/Soundeffecton.png");
	SDL_Texture* Seon=SDL_CreateTextureFromSurface(rend,seon);
	
	SDL_Surface* seoff=IMG_Load("Texture/BgMenu/Soundeffectoff.png");
	SDL_Texture* Seoff=SDL_CreateTextureFromSurface(rend,seoff);
	
	SDL_Surface* back=IMG_Load("Texture/BgMenu/Back.png");
	SDL_Texture* Back=SDL_CreateTextureFromSurface(rend,back);
	
	SDL_Surface* jl=IMG_Load("Texture/Jack.png");
	SDL_Texture* Jacklogo=SDL_CreateTextureFromSurface(rend,jl);
	
	Mix_Music* BackMusic= Mix_LoadMUS("Duck.mp3"); 
	Mix_Music* MenuMusic= Mix_LoadMUS("Nature.mp3");
		
	SDL_Rect Bg;
	SDL_Rect cl1;
	SDL_Rect cl2;
	SDL_Rect cl3;
	SDL_Rect Treee;
	
	p=1;
	int Bgx=-1080;
	int cx=2300,cxp=-1000;
	int count=0;
	int ui1=0;
	int mdown;
	int mouse_p,mouse_l,mouse_o,mouse_q,mouse_b,mouse_music=-1,mouse_sound=-1;
	

	Mix_PlayMusic(MenuMusic,-1);

	while(count!=-1){
	
	
	int story_big=0, random_big=0;
	int x,y;
	Uint32 mbutton;
	
	
		if(p<255){
			p=p+1;
		}
		if(Bgx!=0){
			Bgx=Bgx+4;
		}
		if(count!=-1){
			if(cx!=-1000){
				cx=cx-1;
				cxp=cxp+1;
			}
			else{
			cx=2300;
			cxp=-1000;
			}
				
		}
	count++;
	SDL_Delay(0.5);
	SDL_RenderClear(rend);
	
	
	SDL_QueryTexture(Tex_Bg,NULL,NULL,&Bg.w,&Bg.h);
	Bg.h=1080;
	Bg.w=3000;
	Bg.x=Bgx;
	Bg.y=0;
	
	SDL_Rect Ui;
	SDL_QueryTexture(UI,NULL,NULL,&Ui.w,&Ui.h);
	Ui.h=700;
	Ui.w=1100;
	Ui.x=960-550;
	Ui.y=540-350;
	
	SDL_Rect Uit;
	SDL_QueryTexture(UIt,NULL,NULL,&Uit.w,&Uit.h);
	Uit.h=400;
	Uit.w=600;
	Uit.x=960-300;
	Uit.y=610-200;
	
	
	SDL_QueryTexture(c1,NULL,NULL,&cl1.w,&cl1.h);
	cl1.h=70;
	cl1.w=0.3*1800;
	cl1.x=1.2*cx+Bgx;
	cl1.y=250;
	
	
	SDL_QueryTexture(c2,NULL,NULL,&cl2.w,&cl2.h);
	cl2.h=0.25*200;
	cl2.w=0.25*1800;
	cl2.x=1.5*cxp+Bgx;
	cl2.y=370;
	
	
	SDL_QueryTexture(c3,NULL,NULL,&cl3.w,&cl3.h);
	cl3.h=0.2*200;
	cl3.w=0.15*1800;
	cl3.x=600+0.9*cxp+Bgx;
	cl3.y=150;

	
	
	SDL_QueryTexture(t1,NULL,NULL,&Treee.w,&Treee.h);
	Treee.h=500;
	Treee.w=350;
	Treee.x=250+Bgx;
	Treee.y=310;
	
	SDL_Rect TT;
	SDL_QueryTexture(textf,NULL,NULL,&TT.w,&TT.h);
	TT.h=150;
	TT.w=500;
	TT.x=960-250;
	TT.y=280-75;

	SDL_Rect PLAY;
	SDL_QueryTexture(Play,NULL,NULL,&PLAY.w,&PLAY.h);
	PLAY.h=125;
	PLAY.w=1100;
	PLAY.x=350+50;
	PLAY.y=370;
	
	SDL_Rect STO;
	SDL_Rect RAN;

	SDL_Rect NUM1;
	SDL_QueryTexture(num1,NULL,NULL,&NUM1.w,&NUM1.h);
	NUM1.h=100;
	NUM1.w=100;
	NUM1.x=710;
	NUM1.y=420;
	
	SDL_Rect NUM5;
	SDL_QueryTexture(num5,NULL,NULL,&NUM5.w,&NUM5.h);
	NUM5.h=100;
	NUM5.w=100;
	NUM5.x=710;
	NUM5.y=420+130;
	
	SDL_Rect NUM9;
	SDL_QueryTexture(num9,NULL,NULL,&NUM9.w,&NUM9.h);
	NUM9.h=100;
	NUM9.w=100;
	NUM9.x=710;
	NUM9.y=420+260;
	
	SDL_Rect NUM2;
	SDL_QueryTexture(num2,NULL,NULL,&NUM2.w,&NUM2.h);
	NUM2.h=100;
	NUM2.w=100;
	NUM2.x=710+130;
	NUM2.y=420;
	
	SDL_Rect NUM6;
	SDL_QueryTexture(num6,NULL,NULL,&NUM6.w,&NUM6.h);
	NUM6.h=100;
	NUM6.w=100;
	NUM6.x=710+130;
	NUM6.y=420+130;
	
	SDL_Rect NUM10;
	SDL_QueryTexture(num10,NULL,NULL,&NUM10.w,&NUM10.h);
	NUM10.h=100;
	NUM10.w=100;
	NUM10.x=710+130;
	NUM10.y=420+260;
	
	SDL_Rect NUM3;
	SDL_QueryTexture(num3,NULL,NULL,&NUM3.w,&NUM3.h);
	NUM3.h=100;
	NUM3.w=100;
	NUM3.x=710+260;
	NUM3.y=420;
	
	SDL_Rect NUM7;
	SDL_QueryTexture(num7,NULL,NULL,&NUM7.w,&NUM7.h);
	NUM7.h=100;
	NUM7.w=100;
	NUM7.x=710+260;
	NUM7.y=420+130;
	
	SDL_Rect NUM4;
	SDL_QueryTexture(num4,NULL,NULL,&NUM4.w,&NUM4.h);
	NUM4.h=100;
	NUM4.w=100;
	NUM4.x=710+390;
	NUM4.y=420;
	
	SDL_Rect NUM8;
	SDL_QueryTexture(num8,NULL,NULL,&NUM8.w,&NUM8.h);
	NUM8.h=100;
	NUM8.w=100;
	NUM8.x=710+390;
	NUM8.y=420+130;

	SDL_Rect LEVEL;
	SDL_QueryTexture(Level,NULL,NULL,&LEVEL.w,&LEVEL.h);
	LEVEL.h=125;
	LEVEL.w=1100;
	LEVEL.x=360;
	LEVEL.y=490;
	
	SDL_Rect OPTION;
	SDL_QueryTexture(Option,NULL,NULL,&OPTION.w,&OPTION.h);
	OPTION.h=125;
	OPTION.w=1100;
	OPTION.x=330;
	OPTION.y=595;
	
	SDL_Rect QUIT;
	SDL_QueryTexture(Quit,NULL,NULL,&QUIT.w,&QUIT.h);
	QUIT.h=125;
	QUIT.w=1100;
	QUIT.x=340;
	QUIT.y=703;
	
	SDL_Rect MUSIC;
	SDL_QueryTexture(Bgmon,NULL,NULL,&MUSIC.w,&MUSIC.h);
	MUSIC.h=100;
	MUSIC.w=600;
	MUSIC.x=630;
	MUSIC.y=440;
	
	SDL_Rect SOUNDEFFECT;
	SDL_QueryTexture(Seon,NULL,NULL,&SOUNDEFFECT.w,&SOUNDEFFECT.h);
	SOUNDEFFECT.h=100;
	SOUNDEFFECT.w=600;
	SOUNDEFFECT.x=630;
	SOUNDEFFECT.y=590;
	
	SDL_Rect BACK;
	SDL_QueryTexture(Back,NULL,NULL,&BACK.w,&BACK.h);
	BACK.h=100;
	BACK.w=500;
	BACK.x=600;
	BACK.y=700;
	
	SDL_Rect BACK2;
	SDL_QueryTexture(Back,NULL,NULL,&BACK2.w,&BACK2.h);
	BACK2.h=120;
	BACK2.w=550;
	BACK2.x=575;
	BACK2.y=690;
	
	SDL_Rect JL;
	SDL_QueryTexture(Jacklogo,NULL,NULL,&JL.w,&JL.h);
	JL.h=200;
	JL.w=700;
	JL.x=960-350;
	JL.y=230;
	
	
	
	SDL_RenderClear(rend);
	SDL_SetTextureBlendMode(Tex_Bg,SDL_BLENDMODE_ADD);
	SDL_SetTextureAlphaMod(Tex_Bg,p);
	
	
	
		
	SDL_RenderCopy(rend,Tex_Bg, NULL, &Bg);
	if(count>200){
		SDL_RenderCopyEx(rend,c1, NULL, &cl1,2,NULL,SDL_FLIP_NONE);
	}
	

	
	SDL_RenderCopyEx(rend,c2, NULL, &cl2,0,NULL,SDL_FLIP_NONE);
	SDL_RenderCopyEx(rend,c3, NULL, &cl3,5,NULL,SDL_FLIP_NONE);
	SDL_RenderCopy(rend,t1,NULL,&Treee);
	
	SDL_RenderCopy(rend,UI,NULL,&Ui);
	if(ui1==0){
		SDL_RenderCopy(rend,UIt,NULL,&Uit);
	}
	else if(ui1==1){
		SDL_RenderCopy(rend,Bgmon,NULL,&MUSIC);
		SDL_RenderCopy(rend,Seon,NULL,&SOUNDEFFECT);

		SDL_RenderCopy(rend,Back,NULL,&BACK);		
	
	
	}
	
	if(SDL_PollEvent(&event)){
		if(event.type== SDL_QUIT){
			break;
		}
		
		if(event.type == SDL_MOUSEBUTTONDOWN || mdown==1){
			mdown=1;
			if(mdown==1 && event.type==SDL_MOUSEBUTTONUP){
				mdown=0;
				
			if(mouse_p==1 && ui1==0){
				SDL_RenderClear(rend);
				break;
				}
			if(mouse_l==1 && ui1==0){
				ui1=2;
			
			}
			if(mouse_o==1 && ui1==0){
				ui1=1;
				mouse_p=0;
				mouse_l=0;
				mouse_o=0;
				mouse_q=0;
				mouse_b=0;
			}
			if(mouse_q==1 && ui1==0){
				SDL_RenderClear(rend);
				SDL_RenderPresent(rend);
				
				SDL_DestroyRenderer(rend);
				SDL_DestroyWindow(win);
				SDL_Quit();
				
				break;
			}
			if(mouse_b==1 && ui1==1){
				ui1=0;
				mouse_p=0;
				mouse_l=0;
				mouse_o=0;
				mouse_q=0;
				mouse_b=0;
				
			}
			if(ui1==1 && x<1208 && y<515 && x>1132 && y>452){
			mouse_music=-1*mouse_music;
			}
			if(ui1==1 && x<1208 && y<665 && x>1132 && y>602){
			mouse_sound=-1*mouse_sound;
			}
			
			
			
			
			}
			
		}
		
		
		if(event.type == SDL_MOUSEBUTTONDOWN){
			if(ui1==2){
				if(x<960-250+500 && x>960-250 && y<370+100+125 && y>370+100 ){
					ui1=3;
				}
				else if(x<960-250+500 && x>960-250 && y<370+275+125 && y>370+275 ){
					level=0;
					break;
				
	
				
				}
			
			
			
			
			
			
			
			
			}
			else if(ui1==3){
				if(x<810 && x>710 && y<520 && y>420 ){
					level=1;
					break;
				}
				else if(x<810+130 && x>710+130 && y<520 && y>420){
					level=2;
					break;
				}
				else if(x<810+260 && x>710+260 && y<520 && y>420){
					level=3;
					break;
				}
				else if(x<810+390 && x>710+390 && y<520 && y>420){
					level=4;
					break;
				}
				else if(x<810 && x>710 && y<520+130 && y>420+130){
					level=5;
					break;
				}
				else if(x<810+130 && x>710+130 && y<520+130 && y>420+130){
					level=6;
					break;
				}
				else if(x<810+260 && x>710+260 && y<520+130 && y>420+130){
					level=7;
					break;
				}
				else if(x<810+390 && x>710+390 && y<520+130 && y>420+130){
					level=8;
					break;
				}
				else if(x<810 && x>710 && y<520+260 && y>420+260){
					level=9;
					break;
				}
				else if(x<810+130 && x>710+130 && y<520+260 && y>420+260){
					level=10;
					break;
				}
			
			
			
			
			
			}
			
			
		}	
		
		if(event.type== SDL_MOUSEMOTION){
		mbutton= SDL_GetMouseState(&x,&y);
		
			if((x>676 && y>417) && (x<1265 && y<495) && ui1==0){	
			mouse_p=1;
			mouse_l=0;
			mouse_o=0;
			mouse_q=0;
			
			}
			else if((x>676 && y>517) && (x<1265 && y<595) && ui1==0){
			mouse_p=0;
			mouse_l=1;
			mouse_o=0;
			mouse_q=0;
			}
			else if((x>676 && y>622) && (x<1265 && y<700) && ui1==0){
			mouse_p=0;
			mouse_l=0;
			mouse_o=1;
			mouse_q=0;
			}
			else if((x>676 && y>720) && (x<1265 && y<798) && ui1==0){
			mouse_p=0;
			mouse_l=0;
			mouse_o=0;
			mouse_q=1;
			}
			else if(x<1012 && y<795 && x>606 && y>705 && ui1==1){
			mouse_b=1;
			}
			else if(x<960-250+500 && x>960-250 && y<370+100+125 && y>370+100 && ui1==2){
			story_big=1;
			}
			else if(x<960-250+500 && x>960-250 && y<370+275+125 && y>370+275 && ui1==2){
			random_big=1;
			}
			
			else{
			mouse_p=0;
			mouse_l=0;
			mouse_o=0;
			mouse_q=0;
			mouse_b=0;
			}
		
		
		
		
		
		}
		

		
		}

	SDL_QueryTexture(Story,NULL,NULL,&STO.w,&STO.h);
	STO.h=125+20*story_big;
	STO.w=500+80*story_big;
	STO.x=960-250-40*story_big;
	STO.y=370+100-10*story_big;

	SDL_QueryTexture(Random,NULL,NULL,&RAN.w,&RAN.h);
	RAN.h=125+20*random_big;
	RAN.w=500+80*random_big;
	RAN.x=960-250-40*random_big;
	RAN.y=370+275-10*random_big;	
	
	
	if(ui1==0){
	if(mouse_p==1){
		SDL_RenderCopy(rend,Play,NULL,&PLAY);
	}
	if(mouse_l==1){
		SDL_RenderCopy(rend,Level,NULL,&LEVEL);
	}
	if(mouse_o==1){
		SDL_RenderCopy(rend,Option,NULL,&OPTION);
	}
	if(mouse_q==1){
		SDL_RenderCopy(rend,Quit,NULL,&QUIT);
	}
	}
	else if(ui1==1){
		if(mouse_b==1){
		SDL_RenderCopy(rend,Back,NULL,&BACK2);
		}
		if(mouse_music==1){
		SDL_RenderCopy(rend,Bgmoff,NULL,&MUSIC);
		
		}
		if(mouse_sound==1){
		SDL_RenderCopy(rend,Seoff,NULL,&SOUNDEFFECT);
		
		}
		
	}
	else if(ui1==2){
		SDL_RenderCopy(rend,Story,NULL,&STO);
		SDL_RenderCopy(rend,Random,NULL,&RAN);
	
	
	
	}
	else if(ui1==3){
		SDL_RenderCopy(rend,num1,NULL,&NUM1);	
		SDL_RenderCopy(rend,num5,NULL,&NUM5);	
		SDL_RenderCopy(rend,num9,NULL,&NUM9);	
		SDL_RenderCopy(rend,num2,NULL,&NUM2);	
		SDL_RenderCopy(rend,num6,NULL,&NUM6);	
		SDL_RenderCopy(rend,num10,NULL,&NUM10);
		SDL_RenderCopy(rend,num3,NULL,&NUM3);	
		SDL_RenderCopy(rend,num7,NULL,&NUM7);	
		SDL_RenderCopy(rend,num4,NULL,&NUM4);	
		SDL_RenderCopy(rend,num8,NULL,&NUM8);		
	
	
	}
	
	SDL_RenderCopy(rend,Jacklogo,NULL,&JL);
	SDL_RenderPresent(rend);
	
	
	}
	
	
	
	
	
	
	
	
//##################################################################################################
//Text input
//rand()???
		Sur_Bg =IMG_Load("Texture/BgMenu/Background.png");
		SDL_Texture* Tex_Bg2 =SDL_CreateTextureFromSurface(rend,Sur_Bg);	
		SDL_FreeSurface(Sur_Bg);
		SDL_QueryTexture(Tex_Bg2,NULL,NULL,&Bg.w,&Bg.h);
		Bg.h=2100;
		Bg.w=3000;
		Bg.x=0;
		Bg.y=0;

		grassfield=IMG_Load("Tiles/platformPack_tile001.png");
		Grassfield=SDL_CreateTextureFromSurface(rend,grassfield);
		SDL_FreeSurface(grassfield);
		
		
		ladder1=IMG_Load("Tiles/platformPack_tile037.png");
		Ladder1=SDL_CreateTextureFromSurface(rend,ladder1);
		SDL_FreeSurface(ladder1);
		
		
		
		ladder2=IMG_Load("Tiles/platformPack_tile038.png");
		Ladder=SDL_CreateTextureFromSurface(rend,ladder2);
		SDL_FreeSurface(ladder2);
		
		
		
		swtch1=IMG_Load("Tiles/platformPack_tile064.png");
		SwitchR=SDL_CreateTextureFromSurface(rend,swtch1);
		swtchoff1=IMG_Load("Tiles/platformPack_tile065.png");
		SwitchRoff=SDL_CreateTextureFromSurface(rend,swtchoff1);
		SDL_FreeSurface(swtchoff1);
		SDL_FreeSurface(swtch1);
		
		
		swtch2=IMG_Load("Tiles/platformPack_tile062.png");
		SwitchG=SDL_CreateTextureFromSurface(rend,swtch2);
		swtchoff2=IMG_Load("Tiles/platformPack_tile063.png");
		SwitchGoff=SDL_CreateTextureFromSurface(rend,swtchoff2);
		SDL_FreeSurface(swtchoff2);
		SDL_FreeSurface(swtch2);
		
		
		swtch3=IMG_Load("Tiles/platformPack_tile053.png");
		SwitchB=SDL_CreateTextureFromSurface(rend,swtch3);
		swtchoff3=IMG_Load("Tiles/platformPack_tile054.png");
		SwitchBoff=SDL_CreateTextureFromSurface(rend,swtchoff3);
		SDL_FreeSurface(swtchoff3);
		SDL_FreeSurface(swtch3);
		
		swtch4=IMG_Load("Tiles/platformPack_tile055.png");
		SwitchY=SDL_CreateTextureFromSurface(rend,swtch4);
		swtchoff4=IMG_Load("Tiles/platformPack_tile056.png");
		SwitchYoff=SDL_CreateTextureFromSurface(rend,swtchoff4);
		SDL_FreeSurface(swtchoff4);
		SDL_FreeSurface(swtch4);
		
		
		num=IMG_Load("Texture/a1.png");
		one=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a2.png");
		two=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a3.png");
		three=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a4.png");
		four=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a5.png");
		five=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a6.png");
		six=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a7.png");
		seven=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a8.png");
		eight=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a9.png");
		nine=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		door1=IMG_Load("Tiles/platformPack_tile020.png");
		DoorR=SDL_CreateTextureFromSurface(rend,door1);
		SDL_FreeSurface(door1);
		
		door2=IMG_Load("Tiles/platformPack_tile019.png");
		DoorG=SDL_CreateTextureFromSurface(rend,door2);
		SDL_FreeSurface(door2);
		
		door3=IMG_Load("Tiles/platformPack_tile007.png");
		DoorB=SDL_CreateTextureFromSurface(rend,door3);
		SDL_FreeSurface(door3);
		
		door4=IMG_Load("Tiles/platformPack_tile008.png");
		DoorYe=SDL_CreateTextureFromSurface(rend,door4);
		SDL_FreeSurface(door4);
		
		box=IMG_Load("Tiles/platformPack_tile047.png");
		BoxS=SDL_CreateTextureFromSurface(rend,box);
		SDL_FreeSurface(box);
		
		paper=IMG_Load("Tiles/paper roll.png");
		PRoll=SDL_CreateTextureFromSurface(rend,paper);
		SDL_FreeSurface(paper);
		
		jack=IMG_Load("Poses/character_maleAdventurer_idle.png");
		Jackrest=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk0.png");
		Jackwalk1=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk1.png");
		Jackwalk2=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk2.png");
		Jackwalk3=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk3.png");
		Jackwalk4=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk4.png");
		Jackwalk5=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk5.png");
		Jackwalk6=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk6.png");
		Jackwalk7=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk7.png");
		Jackwalk8=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_climb0.png");
		Jackclimb1=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_climb1.png");
		Jackclimb2=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_drag.png");
		Jackdrag=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		
		barrel=IMG_Load("Tiles/Barrel.png");
		Barrel=SDL_CreateTextureFromSurface(rend,barrel);
		SDL_FreeSurface(barrel);
		
		SDL_Surface* vic=IMG_Load("Texture/Vic.png");
		SDL_Texture* Vic=SDL_CreateTextureFromSurface(rend,vic);
		SDL_FreeSurface(vic);
		
		SDL_Surface* restart=IMG_Load("Texture/Restart.png");
		SDL_Texture* Restart=SDL_CreateTextureFromSurface(rend,restart);
		SDL_FreeSurface(restart);

	int sw1=0,sw2=0,dr1=0,dr2=0;
	int play=0;
	int right=0,left=0,up=0,down=0;
	int boxright=0,boxleft=0,boxfall=0;
	int barright=0,barleft=0,barfall=0;
	int fall=0;
	int okr=0,okl=0,oku=0,okd=0;
	int complete=0;
	int delaycount=0;
	int boxr=0,boxl=0,boxf=0;
	int doorclose1=0,doorclose2=0;
	int JACKrest=0,JACKwalk=1,JACKclimb=1,JACKdrag=1;
	int aa=0,bb=0;
	int rr=0,ll=0,uu=0,dd=0;
	double BarMov=0;
	int RollStart=0,RollStop=0,S=1;
	int switchcount=0;
	int rota=0;
	count=0;
	
	
	Mix_PlayMusic(BackMusic,-1);
	
	if(level==1){
	while(complete==0){
	
	
	
	int x2,y2;
	Uint32 m2button;
	
		if(cx>=-1000){
			cx=cx-1;			
			cxp=cxp+1;
		}
		else{
		cx=2300;
		cxp=-1000;
		}
				
	cl1.x=cx;
	cl1.y=250;
	
	cl2.x=cxp;
	cl2.y=370;
	
	cl3.x=600+cxp;
	cl3.y=150;
	
	SDL_RenderClear(rend);
	SDL_RenderCopy(rend,Tex_Bg2, NULL, &Bg);
	SDL_RenderCopyEx(rend,c1, NULL, &cl1,2,NULL,SDL_FLIP_NONE);
	SDL_RenderCopyEx(rend,c2, NULL, &cl2,0,NULL,SDL_FLIP_NONE);
	SDL_RenderCopyEx(rend,c3, NULL, &cl3,5,NULL,SDL_FLIP_NONE);
	
	
		
			
		
//Level one:
		
		int GrassCountlv1=4;
		int GrassXlv1[]={270,270+9*60,270+60*3,270+8*60};
		int GrassYlv1[]={370,370,650,930};
		int GrassNumlv1[]={8,6,12,16};
		Grass(GrassCountlv1,GrassXlv1,GrassYlv1,GrassNumlv1);
		
		SDL_Rect LADDER1;
		SDL_QueryTexture(Ladder1,NULL,NULL,&LADDER1.w,&LADDER1.h);
		LADDER1.h=40;
		LADDER1.w=54;
		LADDER1.x=273+8*60;
		LADDER1.y=310;
		SDL_RenderCopy(rend,Ladder1,NULL,&LADDER1);
		
		
		SDL_Rect LADDER;
		SDL_QueryTexture(Ladder,NULL,NULL,&LADDER.w,&LADDER.h);
		LADDER.h=60;
		LADDER.w=54;
		LADDER.x=273+8*60;
		LADDER.y=350;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		
		LADDER1.x=273+15*60;
		LADDER1.y=590;
		SDL_RenderCopy(rend,Ladder1,NULL,&LADDER1);
		
		LADDER.x=273+8*60;
		LADDER.y=350+1*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+8*60;
		LADDER.y=350+2*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+8*60;
		LADDER.y=350+3*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+8*60;
		LADDER.y=350+4*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		
		LADDER.x=273+15*60;
		LADDER.y=630;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+15*60;
		LADDER.y=630+1*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+15*60;
		LADDER.y=630+2*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+15*60;
		LADDER.y=630+3*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		LADDER.x=273+15*60;
		LADDER.y=630+4*60;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		
		
		
		SDL_Rect SWITCHR;	
		SDL_QueryTexture(SwitchR,NULL,NULL,&SWITCHR.w,&SWITCHR.h);
		SWITCHR.h=30;
		SWITCHR.w=40;
		SWITCHR.x=273+5*60;
		SWITCHR.y=620;
		
		SDL_Rect SWITCHG;
		SDL_QueryTexture(SwitchG,NULL,NULL,&SWITCHG.w,&SWITCHG.h);
		SWITCHG.h=30;
		SWITCHG.w=40;
		SWITCHG.x=273+10*60;
		SWITCHG.y=900;
		
		SDL_Rect SWITCHB;
		SDL_QueryTexture(SwitchB,NULL,NULL,&SWITCHB.w,&SWITCHB.h);
		SWITCHB.h=20;
		SWITCHB.w=40;
		SWITCHB.x=270+8*60;
		SWITCHB.y=320;
		
	
		if(sw1==0){
		SDL_RenderCopy(rend,SwitchR,NULL,&SWITCHR);
		}
		else{
		SDL_Rect SWITCHROFF;
		SDL_QueryTexture(SwitchRoff,NULL,NULL,&SWITCHROFF.w,&SWITCHROFF.h);
		SWITCHROFF.h=40;
		SWITCHROFF.w=40;
		SWITCHROFF.x=270+5*60;
		SWITCHROFF.y=615;
		SDL_RenderCopy(rend,SwitchRoff,NULL,&SWITCHROFF);
		}
		
		if(sw2==0){
		SDL_RenderCopy(rend,SwitchG,NULL,&SWITCHG);		
		}
		else{
		SDL_Rect SWITCHGOFF;
		SDL_QueryTexture(SwitchGoff,NULL,NULL,&SWITCHGOFF.w,&SWITCHGOFF.h);
		SWITCHGOFF.h=40;
		SWITCHGOFF.w=40;
		SWITCHGOFF.x=270+10*60;
		SWITCHGOFF.y=895;
		SDL_RenderCopy(rend,SwitchGoff,NULL,&SWITCHGOFF);
		}
		
		SDL_Rect DOORG;
		SDL_QueryTexture(DoorG,NULL,NULL,&DOORG.w,&DOORG.h);
		DOORG.h=80-doorclose2;
		DOORG.w=20;
		DOORG.x=270+12*60;
		DOORG.y=290+doorclose2;
		
		SDL_Rect DOORR;
		SDL_QueryTexture(DoorR,NULL,NULL,&DOORR.w,&DOORR.h);
		DOORR.h=80-doorclose1;
		DOORR.w=20;
		DOORR.x=270+16*60+20+30;
		DOORR.y=850+doorclose1;
		
		SDL_Rect DOORB;
		SDL_QueryTexture(DoorB,NULL,NULL,&DOORB.w,&DOORB.h);
		DOORB.h=60;
		DOORB.w=20;
		DOORB.x=270+8*60;
		DOORB.y=870;
		
		SDL_QueryTexture(Ladder,NULL,NULL,&LADDER.w,&LADDER.h);
		LADDER.h=60;
		LADDER.w=20;
		LADDER.x=270+9*60;
		LADDER.y=870;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		
		SDL_QueryTexture(Ladder,NULL,NULL,&LADDER.w,&LADDER.h);
		LADDER.h=60;
		LADDER.w=20;
		LADDER.x=270+22*60;
		LADDER.y=870;
		SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
		
		SDL_Rect BOXS;
		SDL_QueryTexture(BoxS,NULL,NULL,&BOXS.w,&BOXS.h);
		BOXS.h=80;
		BOXS.w=80;
		BOXS.x=270+9*60+5*boxr-5*boxl;
		BOXS.y=570+5*boxf;
		
		SDL_RenderCopy(rend,BoxS,NULL,&BOXS);
		
		
		SDL_Rect PROLL;
		SDL_QueryTexture(PRoll,NULL,NULL,&PROLL.w,&PROLL.h);
		PROLL.h=50;
		PROLL.w=20;
		PROLL.x=270+13*60;
		PROLL.y=320;
		
		SDL_RenderCopyEx(rend,PRoll,NULL,&PROLL,10,NULL,SDL_FLIP_NONE);
		
		SDL_Rect JACK;
		SDL_QueryTexture(Jackrest,NULL,NULL,&JACK.w,&JACK.h);
		JACK.h=80;
		JACK.w=60;
		JACK.x=270+2*60+5*right-5*left;
		JACK.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK1;
		SDL_QueryTexture(Jackwalk1,NULL,NULL,&JACKWALK1.w,&JACKWALK1.h);
		JACKWALK1.h=80;
		JACKWALK1.w=60;
		JACKWALK1.x=270+2*60+5*right-5*left;
		JACKWALK1.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK2;
		SDL_QueryTexture(Jackwalk2,NULL,NULL,&JACKWALK2.w,&JACKWALK2.h);
		JACKWALK2.h=80;
		JACKWALK2.w=60;
		JACKWALK2.x=270+2*60+5*right-5*left;
		JACKWALK2.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK3;
		SDL_QueryTexture(Jackwalk3,NULL,NULL,&JACKWALK3.w,&JACKWALK3.h);
		JACKWALK3.h=80;
		JACKWALK3.w=60;
		JACKWALK3.x=270+2*60+5*right-5*left;
		JACKWALK3.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK4;
		SDL_QueryTexture(Jackwalk4,NULL,NULL,&JACKWALK4.w,&JACKWALK4.h);
		JACKWALK4.h=80;
		JACKWALK4.w=60;
		JACKWALK4.x=270+2*60+5*right-5*left;
		JACKWALK4.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK5;
		SDL_QueryTexture(Jackwalk5,NULL,NULL,&JACKWALK5.w,&JACKWALK5.h);
		JACKWALK5.h=80;
		JACKWALK5.w=60;
		JACKWALK5.x=270+2*60+5*right-5*left;
		JACKWALK5.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK6;
		SDL_QueryTexture(Jackwalk6,NULL,NULL,&JACKWALK6.w,&JACKWALK6.h);
		JACKWALK6.h=80;
		JACKWALK6.w=60;
		JACKWALK6.x=270+2*60+5*right-5*left;
		JACKWALK6.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK7;
		SDL_QueryTexture(Jackwalk7,NULL,NULL,&JACKWALK7.w,&JACKWALK7.h);
		JACKWALK7.h=80;
		JACKWALK7.w=60;
		JACKWALK7.x=270+2*60+5*right-5*left;
		JACKWALK7.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKWALK8;
		SDL_QueryTexture(Jackwalk8,NULL,NULL,&JACKWALK8.w,&JACKWALK8.h);
		JACKWALK8.h=80;
		JACKWALK8.w=60;
		JACKWALK8.x=270+2*60+5*right-5*left;
		JACKWALK8.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKCLIMB1;
		SDL_QueryTexture(Jackclimb1,NULL,NULL,&JACKCLIMB1.w,&JACKCLIMB1.h);
		JACKCLIMB1.h=80;
		JACKCLIMB1.w=60;
		JACKCLIMB1.x=270+2*60+5*right-5*left;
		JACKCLIMB1.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKCLIMB2;
		SDL_QueryTexture(Jackclimb2,NULL,NULL,&JACKCLIMB2.w,&JACKCLIMB2.h);
		JACKCLIMB2.h=80;
		JACKCLIMB2.w=60;
		JACKCLIMB2.x=270+2*60+5*right-5*left;
		JACKCLIMB2.y=290+5*down-5*up+5*fall;
		
		SDL_Rect JACKDRAG;
		SDL_QueryTexture(Jackdrag,NULL,NULL,&JACKDRAG.w,&JACKDRAG.h);
		JACKDRAG.h=80;
		JACKDRAG.w=60;
		JACKDRAG.x=270+2*60+5*right-5*left;
		JACKDRAG.y=290+5*down-5*up+5*fall;
		
		SDL_Rect BARREL;
		SDL_QueryTexture(Barrel,NULL,NULL,&BARREL.w,&BARREL.h);
		BARREL.h=60;
		BARREL.w=60;
		BARREL.x=270+19*60+5*BarMov;
		BARREL.y=870;
		
		SDL_Rect VICTORY;
		SDL_QueryTexture(Vic,NULL,NULL,&VICTORY.w,&VICTORY.h);
		VICTORY.x=980-300;
		VICTORY.y=540-200;
		VICTORY.h=400;
		VICTORY.w=600;

		SDL_Rect RESTART;
		SDL_QueryTexture(Restart,NULL,NULL,&RESTART.w,&RESTART.h);
		RESTART.h=50;
		RESTART.w=50;
		RESTART.x=1800;
		RESTART.y=50;
		
		
		
		if(((JACK.y==290 && JACK.x>220 && JACK.x<270+13*60 && dr2==1) || ( JACK.x>220+3*60 && JACK.x<300+15*60 && JACK.y==570 ) || (JACK.x>270+9*60+10 && dr1==1 && JACK.x<270+21*60+10 && JACK.y==850) || (JACK.y==290 && JACK.x>220 && JACK.x-10<270+11*60 && dr2==0) || (((JACK.x>270+9*60+10 && JACK.x<270+17*60+10) || (JACK.x > DOORR.x+DOORR.w && JACK.x+50<270+21*60)) && JACK.y==850 && dr1==0) || (JACK.x==270+15*60 && JACK.y<850 && JACK.y>710) || (JACK.x==270+8*60 && JACK.y>430 && JACK.y<570 && !(BOXS.x<270+9*60+50 && JACK.y+80>=BOXS.y && JACK.y<BOXS.y+BOXS.h && JACK.x==270+8*60) && !(BOXS.x+BOXS.w>270+8*60-50 && JACK.y+80>=BOXS.y && JACK.y<BOXS.y+BOXS.h && JACK.x==270+8*60)) || (JACK.x>BOXS.x-50 && JACK.x+10<BOXS.x+BOXS.w && JACK.y+80==BOXS.y))&& !(JACK.y==BOXS.y && JACK.x+50>=BOXS.x && BOXS.x>JACK.x && BOXS.x+80==DOORR.x && dr1==0)||(JACK.y==770 && JACK.x+50>=DOORR.x && JACK.x-10<DOORR.x)){
		
		
			okr=0;
			okl=0;
		
		}
		else if(JACK.x==270+15*60 && JACK.y<850){
			okr=0;
			okl=1;
		}
		else if((JACK.x==270+9*60+10 && JACK.y==850)){
			okr=0;
			okl=1;
		
		
		}
		else if(((JACK.y>=290 && JACK.x==220) || ( JACK.x==220+3*60 && JACK.y>=570 ) || (( (JACK.x==270+16*60-10 && JACK.y<850)|| (JACK.x==270+14*60+10 && JACK.y<850 && JACK.y>710) || ((JACK.x==270+9*60-10 || JACK.x==270+7*60+10) && JACK.y<570 && JACK.y>430) || ((JACK.x==BOXS.x-50 || (JACK.x+10==BOXS.x+BOXS.w && (BOXS.x+BOXS.w+50<DOORR.x))) && JACK.y+80>=BOXS.y && JACK.y+80<BOXS.y+BOXS.h) || (JACK.y>=770 && JACK.y<850 && (BOXS.x+70<=JACK.x && JACK.x+50<=BOXS.x))|| ((JACK.y+JACK.h>=DOORR.y && JACK.x+50>DOORR.x && JACK.x<DOORR.x+DOORR.w) && JACK.y<DOORR.y)) && JACK.y<850 && (JACK.x<DOORR.x-50 || DOORR.x+DOORR.w<JACK.x))) && !(JACK.x==270+15*60+50 && BARREL.x>=270+15*60 && BARREL.x<=DOORR.x && JACK.y+JACK.h<BARREL.y)){
			if((JACK.x==270+9*60-10 || JACK.x==270+7*60+10) && JACK.y<=565){
				if(JACK.x>BOXS.x-50 && JACK.x+10<BOXS.x+BOXS.w && JACK.y+80<BOXS.y){
				printf("a");
				fall++;
				}
				else{
				fall++;
				printf("b");
				}
			}

			else if((JACK.x==BOXS.x-50 || (JACK.x+10==BOXS.x+BOXS.w && (BOXS.x+BOXS.w+50<DOORR.x))) && JACK.y+80>=BOXS.y && JACK.y<BOXS.y ){	
			printf("c");				
			fall++;
			
			}
			else if((JACK.x==270+16*60-10 || JACK.x==270+14*60+10) && JACK.y<=845){
			printf("d");
			fall++;
			}
			else if((JACK.y+JACK.h>=DOORR.y && JACK.x-10>DOORR.x+DOORR.w) && JACK.y<850){
			printf("f");
				fall++;
			
			
			}
			else{
			printf("e");

				fall++;
				
			}
			okr=1;
			okl=1;
			
		
		}
		else if((BOXS.x<270+9*60+50 && JACK.y+80>=BOXS.y && JACK.y<BOXS.y+BOXS.h && JACK.x==270+8*60)|| (JACK.y==BOXS.y && JACK.x+50>=BOXS.x && BOXS.x>JACK.x && BOXS.x+80==DOORR.x && dr1==0)){
		
			okr=1;
			okl=0;
		}
		else if(BOXS.x+BOXS.w>270+8*60-50 && JACK.y+80>=BOXS.y && JACK.y<BOXS.y+BOXS.h && JACK.x==270+8*60){
		
			okr=0;
			okl=1;
		}
		else if((JACK.x==300+14*60 && JACK.y==570 ) || (JACK.x==270+21*60+10 && JACK.y==850 && dr1==1) ||  (JACK.y==290 && JACK.x>=DOORG.x && dr2==0) || (dr1==0 && JACK.x-10>=DOORR.x && JACK.y==850)){
			okr=1;
			okl=0;
		
		
		}

		else{
			okr=1;
			okl=1;
		}
		
		
		
		
		if((JACK.x==270+8*60 && JACK.y>290 && JACK.y<570) || (JACK.x==270+15*60 && JACK.y>570 && JACK.y<850)){
			if(JACK.y+JACK.h>=BOXS.y && abs(JACK.x-BOXS.x)<=25){
			oku=0;
			okd=1;
			}
			else{
			oku=0;
			okd=0;	
			}
		
		}
		else if((JACK.x==270+8*60 && JACK.y==290) || (JACK.x==270+15*60 && JACK.y==570)){
			oku=1;
			okd=0;
		}
		else if((JACK.x==270+8*60 && JACK.y==570) || (JACK.x==270+15*60 && JACK.y==850)){
			oku=0;
			okd=1;
		}
		else{
			oku=1;
			okd=1;
		
		}
		if(JACK.y==BOXS.y && JACK.y==850 && JACK.x+10==270+9*60+20+BOXS.w && JACK.x>BOXS.x){
			okr=0;
			okl=1;
		}
		
		
		if(JACK.y>=770 && JACK.x-10>=DOORR.x && JACK.y<850){
			fall++;
			okr=1;
			okl=1;
		}
		if((JACK.x==270+15*60+50 && BARREL.x>=270+15*60 && BARREL.x<=DOORR.x && JACK.y+JACK.h<BARREL.y)){
			fall++;
			okr=1;
			okr=1;
		}
		if(JACK.x+10>DOORR.x+DOORR.w && ((JACK.x+10<270+22*60 && JACK.x>BARREL.x)||(JACK.x+45+60<270+22*60 && BARREL.x>JACK.x)) && JACK.y==850 && dr1==0){
			okr=0;
			okl=0;
		}
		if((JACK.x+10==DOORR.x+DOORR.w && JACK.x-10<270+21*60 && JACK.y==850 && dr1==0)||(JACK.x+15==270+9*60+20+BARREL.w && BARREL.x==270+9*60+20 && JACK.y==850)){
			okr=0;
			okl=1;
		}
		if((JACK.x+45>=270+21*60 && BARREL.x+BARREL.w==270+22*60 && JACK.y==850 && JACK.x<BARREL.x) || (JACK.x-10==270+11*60 && JACK.y==290 && dr2==0)){
			okr=1;
			okl=0;
			
		}
		if(JACK.y+JACK.h==BARREL.y && BARREL.x<270+15*60+50 && BARREL.x+BARREL.w>270+15*60){
			oku=0;
			okd=1;
		}
		
		if(JACK.y==850 && JACK.x<BARREL.x && JACK.x>=270+21*60-45){
			okr=1;
			okl=0;
		}
		if((JACK.y==850 && JACK.x+50==DOORR.x && dr1==0) || (dr1==0 && JACK.x==270+60*15 && JACK.y>770 && JACK.y<=850 && BARREL.x>=JACK.x && BARREL.x<=DOORR.x)){
			okr=1;
			okl=0;
		}
		else if(JACK.y==850 && JACK.x>BARREL.x && JACK.x<=270+10*60){
			okr=0;
			okl=1;
		}
		
		if(JACK.x==270+13*60-20 && JACK.y==290){
			okr=1;
			okl=1;
			complete=1;
			SDL_Delay(400);
		
		}
		
		if(delaycount!=0){
				delaycount--;
			}
		
		
		if(SDL_PollEvent(&e)){
			if(e.type==SDL_QUIT){
				break;
			}
			else if(e.key.keysym.sym==SDLK_RIGHT && okr==0 && delaycount==0){
				
				if(((JACK.x==270+7*60+10 && !(BOXS.x-JACK.x<110 && BOXS.x>JACK.x && JACK.y==570 && BOXS.y==570)) || (JACK.x==270+14*60+10 && !(BOXS.x-JACK.x<110 && BOXS.x>JACK.x && ((BOXS.y==850 && JACK.y==850) || (BOXS.y==570 && JACK.y==570)))) || (JACK.x==270+8*60 && !(BOXS.x-JACK.x<110 && BOXS.x>JACK.x && JACK.y==570 && BOXS.y==570)) || (JACK.x==270+15*60 && !(BOXS.x-JACK.x<110 && BOXS.x>JACK.x && ((BOXS.y==850 && JACK.y==850) || (BOXS.y==570 && JACK.y==570)))))){
				right=right+10;
				delaycount=10;
				}
				else{
				right++;
				}
				aa=count;
				rr=1;
				uu=0;
				ll=0;
				dd=0;
				
				
				
						if(JACK.x%240<=30 && JACK.x%240>=0){ 			
						SDL_RenderCopyEx(rend,Jackwalk1,NULL,&JACKWALK1,0,NULL,SDL_FLIP_NONE);
						}
						else if(JACK.x%240<=60 && JACK.x%240>30){ 			
						SDL_RenderCopyEx(rend,Jackwalk2,NULL,&JACKWALK2,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=90 && JACK.x%240>60){ 			
						SDL_RenderCopyEx(rend,Jackwalk3,NULL,&JACKWALK3,0,NULL,SDL_FLIP_NONE);
						}		
						else if(JACK.x%240<=120 && JACK.x%240>90){ 			
						SDL_RenderCopyEx(rend,Jackwalk4,NULL,&JACKWALK4,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=150 && JACK.x%240>120){ 			
						SDL_RenderCopyEx(rend,Jackwalk5,NULL,&JACKWALK5,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=180 && JACK.x%240>150){ 			
						SDL_RenderCopyEx(rend,Jackwalk6,NULL,&JACKWALK6,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=210 && JACK.x%240>180){ 			
						SDL_RenderCopyEx(rend,Jackwalk7,NULL,&JACKWALK7,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=240 && JACK.x%240>210){ 			
						SDL_RenderCopyEx(rend,Jackwalk8,NULL,&JACKWALK8,0,NULL,SDL_FLIP_NONE);
						}	
			}	
			else if(e.key.keysym.sym==SDLK_LEFT && okl==0 && delaycount==0){
				if(((JACK.x==270+9*60-10 && !(JACK.x-BOXS.x<110 && BOXS.x<JACK.x && JACK.y==570 && BOXS.y==570))|| ( JACK.x==270+16*60-10 && !(JACK.x-BOXS.x<110 && BOXS.x<JACK.x && JACK.y==850 && BOXS.y==850)) || ( JACK.x==270+8*60 && !(JACK.x-BOXS.x<110 && BOXS.x<JACK.x && JACK.y==570 && BOXS.y==570)) || ( JACK.x==270+15*60 && !(JACK.x-BOXS.x<110 && BOXS.x<JACK.x && JACK.y==850 && BOXS.y==850))) ){
				left=left+10;
				delaycount=10;
				}
				else{
				left++;
				}
				bb=count;
				rr=0;
				uu=0;
				ll=1;
				dd=0;
						if(JACK.x%240<=30 && JACK.x%240>=0){ 			
						SDL_RenderCopyEx(rend,Jackwalk1,NULL,&JACKWALK1,0,NULL,SDL_FLIP_HORIZONTAL);
						}
						else if(JACK.x%240<=60 && JACK.x%240>30){ 			
						SDL_RenderCopyEx(rend,Jackwalk2,NULL,&JACKWALK2,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=90 && JACK.x%240>60){ 			
						SDL_RenderCopyEx(rend,Jackwalk3,NULL,&JACKWALK3,0,NULL,SDL_FLIP_HORIZONTAL);
						}		
						else if(JACK.x%240<=120 && JACK.x%240>90){ 			
						SDL_RenderCopyEx(rend,Jackwalk4,NULL,&JACKWALK4,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=150 && JACK.x%240>120){ 			
						SDL_RenderCopyEx(rend,Jackwalk5,NULL,&JACKWALK5,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=180 && JACK.x%240>150){ 			
						SDL_RenderCopyEx(rend,Jackwalk6,NULL,&JACKWALK6,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=210 && JACK.x%240>180){ 			
						SDL_RenderCopyEx(rend,Jackwalk7,NULL,&JACKWALK7,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=240 && JACK.x%240>210){ 			
						SDL_RenderCopyEx(rend,Jackwalk8,NULL,&JACKWALK8,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
			}	
			else if(e.key.keysym.sym==SDLK_UP && oku==0){
				up++;
				rr=0;
				uu=1;
				ll=0;
				dd=0;
					
			}	
			else if(e.key.keysym.sym==SDLK_DOWN && okd==0){
				down++;
				rr=0;
				uu=0;
				ll=0;
				dd=1;
					
			}	
			else if(e.type==SDL_MOUSEBUTTONDOWN){
				m2button= SDL_GetMouseState(&x2,&y2);
				if(x2>1800 && x2<1850 && y2<100 && y2>50 ){
				sw1=0;
				sw2=0;dr1=0;dr2=0;
				play=0;
				right=0;left=0;up=0;down=0;
				fall=0;
				okr=0;okl=0;oku=0;okd=0;
				complete=0;
				delaycount=0;
				boxr=0;boxl=0;boxf=0;
				doorclose1=0;doorclose2=0;
				JACKrest=0;JACKwalk=1;JACKclimb=1;JACKdrag=1;
				aa=0;bb=0;
				rr=0;ll=0;uu=0;dd=0;
				BarMov=0;
				RollStart=0;RollStop=0;S=1;
				switchcount=0;
				rota=0;
				count=0;
				}
			}
		}
		else{
			if(((count-aa>10 && count-bb>10) || e.type==SDL_MOUSEMOTION) && !(JACK.x==270+8*60 && JACK.y<=570) && !(JACK.x==270+15*60 && JACK.y<=850)){
			SDL_RenderCopyEx(rend,Jackrest,NULL,&JACK,0,NULL,SDL_FLIP_NONE);
				rr=0;
				uu=0;
				ll=0;
				dd=0;
			}
			else if(rr==1 && !(JACK.x==270+8*60 && JACK.y<=570) && !(JACK.x==270+15*60 && JACK.y<=850)){
			if(JACK.x%240<=30 && JACK.x%240>=0){ 			
						SDL_RenderCopyEx(rend,Jackwalk1,NULL,&JACKWALK1,0,NULL,SDL_FLIP_NONE);
						}
						else if(JACK.x%240<=60 && JACK.x%240>30){ 			
						SDL_RenderCopyEx(rend,Jackwalk2,NULL,&JACKWALK2,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=90 && JACK.x%240>60){ 			
						SDL_RenderCopyEx(rend,Jackwalk3,NULL,&JACKWALK3,0,NULL,SDL_FLIP_NONE);
						}		
						else if(JACK.x%240<=120 && JACK.x%240>90){ 			
						SDL_RenderCopyEx(rend,Jackwalk4,NULL,&JACKWALK4,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=150 && JACK.x%240>120){ 			
						SDL_RenderCopyEx(rend,Jackwalk5,NULL,&JACKWALK5,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=180 && JACK.x%240>150){ 			
						SDL_RenderCopyEx(rend,Jackwalk6,NULL,&JACKWALK6,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=210 && JACK.x%240>180){ 			
						SDL_RenderCopyEx(rend,Jackwalk7,NULL,&JACKWALK7,0,NULL,SDL_FLIP_NONE);
						}	
						else if(JACK.x%240<=240 && JACK.x%240>210){ 			
						SDL_RenderCopyEx(rend,Jackwalk8,NULL,&JACKWALK8,0,NULL,SDL_FLIP_NONE);
						}	
			}
			else if(ll==1 && !(JACK.x==270+8*60 && JACK.y<=570) && !(JACK.x==270+15*60 && JACK.y<=850)){
				if(JACK.x%240<=30 && JACK.x%240>=0){ 			
						SDL_RenderCopyEx(rend,Jackwalk1,NULL,&JACKWALK1,0,NULL,SDL_FLIP_HORIZONTAL);
						}
						else if(JACK.x%240<=60 && JACK.x%240>30){ 			
						SDL_RenderCopyEx(rend,Jackwalk2,NULL,&JACKWALK2,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=90 && JACK.x%240>60){ 			
						SDL_RenderCopyEx(rend,Jackwalk3,NULL,&JACKWALK3,0,NULL,SDL_FLIP_HORIZONTAL);
						}		
						else if(JACK.x%240<=120 && JACK.x%240>90){ 			
						SDL_RenderCopyEx(rend,Jackwalk4,NULL,&JACKWALK4,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=150 && JACK.x%240>120){ 			
						SDL_RenderCopyEx(rend,Jackwalk5,NULL,&JACKWALK5,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=180 && JACK.x%240>150){ 			
						SDL_RenderCopyEx(rend,Jackwalk6,NULL,&JACKWALK6,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=210 && JACK.x%240>180){ 			
						SDL_RenderCopyEx(rend,Jackwalk7,NULL,&JACKWALK7,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
						else if(JACK.x%240<=240 && JACK.x%240>210){ 			
						SDL_RenderCopyEx(rend,Jackwalk8,NULL,&JACKWALK8,0,NULL,SDL_FLIP_HORIZONTAL);
						}	
			}
		}
		
		
		if(JACK.x+50>BOXS.x && BOXS.x>JACK.x && JACK.y==BOXS.y && ((BOXS.x+BOXS.w<DOORR.x && BOXS.x<DOORR.x) || (BOXS.x>DOORR.x+DOORR.w))){
			boxr++;
			
		}
		else if((BOXS.x+70>JACK.x && JACK.x>BOXS.x && JACK.y==BOXS.y) || (BOXS.x>270+9*60+20 && BOXS.y==850 && BOXS.x+70>JACK.x && JACK.y==850 && JACK.x>BOXS.x)){
			boxl++;
		}
		if((BOXS.x<=270+3*60-80 && BOXS.y>=570) || (BOXS.x>=270+15*60 && BOXS.y>=570 && BOXS.y<850)){
		boxf++;
		}
		
		
		
		
		
		if((BOXS.x>270+4*60+20 && BOXS.x<270+5*60 && BOXS.y==570) || (JACK.x>270+4*60+40 && JACK.x<270+5*60+10 && JACK.y==570)){
			sw1=1;
		}
		else{
			sw1=0;
		}
		if((BOXS.x>=270+9*60+20 && BOXS.x<=270+10*60 && BOXS.y==850) || (JACK.x>=270+9*60+40 && JACK.x<=270+10*60+10 && JACK.y==850) || (BARREL.x>=270+9*60+40 && BARREL.x<=270+10*60+10 && BARREL.y==870)){
			sw2=1;
		}
		else{
			sw2=0;
		}
		
		
		
		
		
		
		
		
		
		
		
		if(sw1==1 && doorclose1<80){
		
			doorclose1=doorclose1+10;
		}
		else if(sw1==0 && doorclose1>0){
			if(switchcount<100){
			switchcount++;
			}
			if(switchcount==100){
			doorclose1--;
				if(doorclose1==0){
				switchcount=0;
				}
			}
		}
		if(sw2==1 && doorclose2<80){
			
			doorclose2=doorclose2+10;
			
		}
		else if(sw2==0 && doorclose2>0){
			if(switchcount<100){
			switchcount++;
			}
			if(switchcount==100){
			doorclose2--;
			if(doorclose2==0){
				switchcount=0;
				}
			}
		}
		
		
		
		if(rr==0 && ll==0 && uu==0 && dd==0 && !(JACK.x==270+8*60 && JACK.y<=570) && !(JACK.x==270+15*60 && JACK.y<=850)){
			SDL_RenderCopyEx(rend,Jackrest,NULL,&JACK,0,NULL,SDL_FLIP_NONE);
		}
		else if((JACK.x==270+8*60 && JACK.y<=570) || (JACK.x==270+15*60 && JACK.y<=850)){
			if(JACK.y%100<50){
			SDL_RenderCopyEx(rend,Jackclimb1,NULL,&JACKCLIMB1,0,NULL,SDL_FLIP_NONE);
			}
			else{
			SDL_RenderCopyEx(rend,Jackclimb2,NULL,&JACKCLIMB2,0,NULL,SDL_FLIP_NONE);
			}
		}
		
		
		if(count<1000){
		count++;
		}
		else{
		count=0;
		}
		
		
		if(doorclose1>=80){
			dr1=1;
		}
		else if(doorclose1<80){
			dr1=0;
		}
		if(doorclose2>=80){
			dr2=1;
		}
		else if(doorclose2<80){
			dr2=0;
		}
		
		if(JACKrest==0){
		
		}
		else if(JACKwalk==0){
		
		}
		else if(JACKclimb==0){
			
		
		}
		else if(JACKdrag==0){
		
		}
		
		
		if(JACK.x<=BARREL.x){
		if((JACK.x+45>=BARREL.x && JACK.y+JACK.h==BARREL.y+BARREL.h && rr==1 && BARREL.x+BARREL.w<270+22*60) && !(dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x)))){
			RollStart=1;
			BarMov++;
			S=1;
			rota=rota+5*S;
		}
		else if(RollStart==1 && BARREL.x+BARREL.w<270+22*60 && (!(JACK.x+45==BARREL.x && JACK.y+JACK.h>BARREL.y) || JACK.y+JACK.h<=BARREL.y || !(dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x))) ) && BARREL.x>270+9*60+20){

			BarMov=BarMov+0.5*S;
			rota=rota+5*S;
		}
		else if(RollStart==1 && BARREL.x+BARREL.w==270+22*60 && (!(JACK.x+45==BARREL.x && JACK.y+JACK.h<=BARREL.y) || JACK.y+JACK.h<=BARREL.y || !(dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x))) ) && BARREL.x>270+9*60+20){

			S=-1;
			BarMov=BarMov+0.5*S;
			rota=rota+5*S;
		}
		else if(RollStart==1 && BARREL.x==270+9*60+20){
			S=1;
			BarMov=BarMov+0.5*S;
			rota=rota+5*S;
		}

		if((JACK.x+45==BARREL.x && JACK.y+JACK.h>BARREL.y && JACK.x<BARREL.x && rr==0) || (dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x)))){
			RollStart=0;
			
		}
		else{

		}
		}
//left movement}	
		else if(JACK.x>=BARREL.x){
		
		
		if((BARREL.x+BARREL.w-5>=JACK.x+10 && JACK.y+JACK.h==BARREL.y+BARREL.h && ll==1 && BARREL.x>270+9*60+20) && !(dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x)))){
			RollStart=1;
			BarMov--;
			S=-1;
			rota=rota+5*S;
		}
		else if(RollStart==1 && BARREL.x>270+9*60+20 && (!(BARREL.x+BARREL.w-5==JACK.x+10 && JACK.y+JACK.h>BARREL.y) || JACK.y+JACK.h<=BARREL.y || !(dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x))) ) && BARREL.x+BARREL.w<270+22*60){

			BarMov=BarMov+0.5*S;
			rota=rota+5*S;
		}
		else if(RollStart==1 && BARREL.x==270+9*60+20 && (!(BARREL.x+BARREL.w-5==JACK.x+10 && JACK.y+JACK.h>BARREL.y) || JACK.y+JACK.h<=BARREL.y || !(dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x))) ) && BARREL.x+BARREL.w<270+22*60){

			S=1;
			rota=rota+5*S;
			BarMov=BarMov+0.5*S;
		}
		else if(RollStart==1 && BARREL.x+BARREL.w==270+22*60){
			S=-1;
			rota=rota+5*S;
			BarMov=BarMov+0.5*S;
		}
		if((BARREL.x+BARREL.w-5>=JACK.x+10 && JACK.x>=BARREL.x && JACK.y+JACK.h>BARREL.y && ll==0) || (dr1==0 && ((BARREL.x>DOORR.x && DOORR.x+DOORR.w==BARREL.x)||(BARREL.x<DOORR.x && BARREL.x+BARREL.w==DOORR.x)))){
			RollStart=0;
			
			
		}
		
		else{
		
		}
		
		
		}
		
		
		SDL_RenderCopyEx(rend,Barrel,NULL,&BARREL,rota,NULL,SDL_FLIP_NONE);

		SDL_RenderCopy(rend,DoorR,NULL,&DOORR);
		SDL_RenderCopy(rend,DoorG,NULL,&DOORG);		
		SDL_RenderCopy(rend,Restart,NULL,&RESTART);

		if(complete==1){
			SDL_RenderCopy(rend,Vic,NULL,&VICTORY);
			SDL_RenderPresent(rend);
			SDL_Delay(8000);
			SDL_Quit();
		}
		
		SDL_RenderPresent(rend);
	
		SDL_Delay(1000/60);
		}
		
		}
		else if(level==2){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
			
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv2=8;
			int GrassXlv2[]={840,600,480,360,240,840,1320,1200};
			int GrassYlv2[]={300,540,600,540,720,780,540,300};
			int GrassNumlv2[]={2,9,2,2,10,11,5,5};
			Grass(GrassCountlv2,GrassXlv2,GrassYlv2,GrassNumlv2);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv2=4;
			int LadderXlv2[]={960,480,300,1140};
			int LadderYlv2[]={540,600,720,780};
			int LadderNumlv2[]={4,1,3,8};
			Lad(LadderCountlv2,LadderXlv2,LadderYlv2,LadderNumlv2);
			
//switch------------------------------------------------		
			int SwitchCount=4;
			int SwitchConlv2[]={0,0,0,0};
			int SwitchX[]={540,600,1320,1400};
			int SwitchY[]={600,720,780,780};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			
			for(i=0;i<SwitchCount;i++){
				SwitchConlv2[i]=SwitchCondition(SwitchX,SwitchY,i);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConlv2);
			
			int DoorCount=4;
			int DoorX[]={460,700,1400,1440};
			int DoorY[]={540,720,540,540};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};
			
			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConlv2);
			
			int rvalid=RightValid(GrassXlv2,GrassYlv2,GrassNumlv2,GrassCountlv2);
			int lvalid=LeftValid(GrassXlv2,GrassYlv2,GrassNumlv2,GrassCountlv2);
			int dvalid=DownValid(LadderXlv2,LadderYlv2,LadderNumlv2,2*GrassCountlv2);
			int uvalid=UpValid(LadderXlv2,LadderYlv2,LadderNumlv2,2*GrassCountlv2);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(1340,540);
			Jack(840,300,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv2,GrassYlv2,GrassNumlv2,GrassCountlv2,LadderXlv2,LadderYlv2,LadderNumlv2,2*GrassCountlv2);
			if(fvalid==1){
				fall++;
			}
			
			int BoxCountlv2=1;
			int BoxXlv2[]={880};
			int BoxYlv2[]={540};
			
			Box(BoxXlv2,BoxYlv2,BoxCountlv2,boxright,boxleft,boxfall);
			
			BARL(480,720,barright,barleft,barfall);
			
			SDL_RenderPresent(rend);
		
			}
		
		}
		else if(level==3){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
		
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv3=4;
			int GrassXlv3[]={360,520,1200,750};
			int GrassYlv3[]={480,780,300,980};
			int GrassNumlv3[]={8,13,6,17};
			Grass(GrassCountlv3,GrassXlv3,GrassYlv3,GrassNumlv3);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv3=3;
			int LadderXlv3[]={840,1140,1560};
			int LadderYlv3[]={780,780,980};
			int LadderNumlv3[]={5,8,11};
			Lad(LadderCountlv3,LadderXlv3,LadderYlv3,LadderNumlv3);
			
//switch------------------------------------------------		
			int SwitchCount=4;
			int SwitchConlv3[]={0,0,0,0};
			int SwitchX[]={740,0,1060,1680};
			int SwitchY[]={780,0,780,980};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			
			for(i=0;i<SwitchCount;i++){
				SwitchConlv3[i]=SwitchCondition(SwitchX,SwitchY,i);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConlv3);
			
			int DoorCount=4;
			int DoorConlv3[]={0,0,0,0};
			int DoorX[]={1300,0,1500,900};
			int DoorY[]={300,0,300,980};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};
			
			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConlv3);
	
				


			int rvalid=RightValid(GrassXlv3,GrassYlv3,GrassNumlv3,GrassCountlv3);
			int lvalid=LeftValid(GrassXlv3,GrassYlv3,GrassNumlv3,GrassCountlv3);
			int dvalid=DownValid(LadderXlv3,LadderYlv3,LadderNumlv3,2*GrassCountlv3);
			int uvalid=UpValid(LadderXlv3,LadderYlv3,LadderNumlv3,2*GrassCountlv3);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(800,980);
			Jack(360,480,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv3,GrassYlv3,GrassNumlv3,GrassCountlv3,LadderXlv3,LadderYlv3,LadderNumlv3,2*GrassCountlv3);
			if(fvalid==1){
				fall++;
			}
			
			
			int BoxCountlv3=1;
			int BoxXlv3[]={1380};
			int BoxYlv3[]={300};
			
			Box(BoxXlv3,BoxYlv3,BoxCountlv3,boxright,boxleft,boxfall);
			
			BARL(780,780,barright,barleft,barfall);
			
			
			
			SDL_RenderPresent(rend);
		
			}
		
		
		
		
		
		}
		else if(level==4){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
			
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv4=6;
			int GrassXlv4[]={360,480,720,840,840,1200};
			int GrassYlv4[]={840,540,420,600,240,420};
			int GrassNumlv4[]={5,4,4,10,8,6};
			Grass(GrassCountlv4,GrassXlv4,GrassYlv4,GrassNumlv4);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv4=6;
			int LadderXlv4[]={420,660,780,1140,960,1320};
			int LadderYlv4[]={840,540,420,600,600,420};
			int LadderNumlv4[]={5,2,3,3,3,3};
			Lad(LadderCountlv4,LadderXlv4,LadderYlv4,LadderNumlv4);
			
//switch------------------------------------------------		
			
		int SwitchCount=4;
			int SwitchConlv4[]={0,0,0,0};
			int SwitchX[]={600,1240,1040,0};
			int SwitchY[]={840,420,600,0};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			
			for(i=0;i<SwitchCount;i++){
				SwitchConlv4[i]=SwitchCondition(SwitchX,SwitchY,i);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConlv4);
			
			int DoorCount=4;
			int DoorConlv4[]={0,0,0,0};
			int DoorX[]={1200,920,1300,0};
			int DoorY[]={420,420,600,0};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};
			
			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConlv4);
		








			int rvalid=RightValid(GrassXlv4,GrassYlv4,GrassNumlv4,GrassCountlv4);
			int lvalid=LeftValid(GrassXlv4,GrassYlv4,GrassNumlv4,GrassCountlv4);
			int dvalid=DownValid(LadderXlv4,LadderYlv4,LadderNumlv4,2*GrassCountlv4);
			int uvalid=UpValid(LadderXlv4,LadderYlv4,LadderNumlv4,2*GrassCountlv4);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(1340,600);
			Jack(360,840,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv4,GrassYlv4,GrassNumlv4,GrassCountlv4,LadderXlv4,LadderYlv4,LadderNumlv4,2*GrassCountlv4);
			if(fvalid==1){
				fall++;
			}
			
			SDL_RenderPresent(rend);
		
			}
		
		
		
		
		
		
		}
		else if(level==5){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
		
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv5=8;
			int GrassXlv5[]={360,420,600,600,780,840,1140,1200};
			int GrassYlv5[]={300,840,-100,600,840,300,720,580};
			int GrassNumlv5[]={3,4,3,7,8,7,9,6};
			Grass(GrassCountlv5,GrassXlv5,GrassYlv5,GrassNumlv5);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv5=8;
			int LadderXlv5[]={540,780,780,1020,1080,1140,1260,1560};
			int LadderYlv5[]={840,600,-100,840,840,-100,580,720};
			int LadderNumlv5[]={9,5,2,4,2,2,5,3};
			Lad(LadderCountlv5,LadderXlv5,LadderYlv5,LadderNumlv5);
			
//switch------------------------------------------------		
			
			int SwitchCount=4;
			int SwitchConlv5[]={0,0,0,0};
			int SwitchX[]={420,0,700,900};
			int SwitchY[]={300,0,600,840};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			
			for(i=0;i<SwitchCount;i++){
				SwitchConlv5[i]=SwitchCondition(SwitchX,SwitchY,i);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConlv5);
			
			int DoorCount=4;
			int DoorConlv5[]={0,0,0,0};
			int DoorX[]={1000,0,1400,1200};
			int DoorY[]={300,0,720,300};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};
			
			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConlv5);
		
		
			



			int rvalid=RightValid(GrassXlv5,GrassYlv5,GrassNumlv5,GrassCountlv5);
			int lvalid=LeftValid(GrassXlv5,GrassYlv5,GrassNumlv5,GrassCountlv5);
			int dvalid=DownValid(LadderXlv5,LadderYlv5,LadderNumlv5,2*GrassCountlv5);
			int uvalid=UpValid(LadderXlv5,LadderYlv5,LadderNumlv5,2*GrassCountlv5);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(1100,300);
			Jack(440,840,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv5,GrassYlv5,GrassNumlv5,GrassCountlv5,LadderXlv5,LadderYlv5,LadderNumlv5,2*GrassCountlv5);
			if(fvalid==1){
				fall++;
			}
			SDL_RenderPresent(rend);
		
			}

		}
		else if(level==6){
		while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
		
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv6=5;
			int GrassXlv6[]={540,420,960,840,1260};
			int GrassYlv6[]={300,780,300,600,780};
			int GrassNumlv6[]={6,13,6,9,5};
			Grass(GrassCountlv6,GrassXlv6,GrassYlv6,GrassNumlv6);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv6=5;
			int LadderXlv6[]={480,780,900,1320,1380};
			int LadderYlv6[]={780,780,600,600,780};
			int LadderNumlv6[]={8,3,5,5,3};
			Lad(LadderCountlv6,LadderXlv6,LadderYlv6,LadderNumlv6);
			
//switch------------------------------------------------		
			
		
			







			int rvalid=RightValid(GrassXlv6,GrassYlv6,GrassNumlv6,GrassCountlv6);
			int lvalid=LeftValid(GrassXlv6,GrassYlv6,GrassNumlv6,GrassCountlv6);
			int dvalid=DownValid(LadderXlv6,LadderYlv6,LadderNumlv6,2*GrassCountlv6);
			int uvalid=UpValid(LadderXlv6,LadderYlv6,LadderNumlv6,2*GrassCountlv6);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(1500,780);
			Jack(420,780,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv6,GrassYlv6,GrassNumlv6,GrassCountlv6,LadderXlv6,LadderYlv6,LadderNumlv6,2*GrassCountlv6);
			if(fvalid==1){
				fall++;
			}

			SDL_RenderPresent(rend);
		
			}	

		}
		else if(level==7){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
	
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv7=7;
			int GrassXlv7[]={480,720,900,360,1140,1320,1100};
			int GrassYlv7[]={300,480,480,660,300,480,840};
			int GrassNumlv7[]={10,2,6,10,5,5,7};
			Grass(GrassCountlv7,GrassXlv7,GrassYlv7,GrassNumlv7);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv7=7;
			int LadderXlv7[]={420,660,840,1080,1260,1080,1440};
			int LadderYlv7[]={660,660,660,480,840,480,480};
			int LadderNumlv7[]={6,3,3,3,6,3,3};
			Lad(LadderCountlv7,LadderXlv7,LadderYlv7,LadderNumlv7);
			
//switch------------------------------------------------		
			
		
			







			int rvalid=RightValid(GrassXlv7,GrassYlv7,GrassNumlv7,GrassCountlv7);
			int lvalid=LeftValid(GrassXlv7,GrassYlv7,GrassNumlv7,GrassCountlv7);
			int dvalid=DownValid(LadderXlv7,LadderYlv7,LadderNumlv7,2*GrassCountlv7);
			int uvalid=UpValid(LadderXlv7,LadderYlv7,LadderNumlv7,2*GrassCountlv7);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(1420,840);
			Jack(360,660,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv7,GrassYlv7,GrassNumlv7,GrassCountlv7,LadderXlv7,LadderYlv7,LadderNumlv7,2*GrassCountlv7);
			if(fvalid==1){
				fall++;
			}


			SDL_RenderPresent(rend);
		
			}
		}
		else if(level==8){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv8=7;
			int GrassXlv8[]={600,360,720,780,960,840,1020};
			int GrassYlv8[]={480,840,840,300,300,480,660};
			int GrassNumlv8[]={3,5,8,2,7,10,9};
			Grass(GrassCountlv8,GrassXlv8,GrassYlv8,GrassNumlv8);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv8=6;
			int LadderXlv8[]={540,780,720,900,1380,1440};
			int LadderYlv8[]={840,840,480,480,480,660};
			int LadderNumlv8[]={6,6,3,3,3,3};
			Lad(LadderCountlv8,LadderXlv8,LadderYlv8,LadderNumlv8);
			
//switch------------------------------------------------		
			









			int rvalid=RightValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8);
			int lvalid=LeftValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8);
			int dvalid=DownValid(LadderXlv8,LadderYlv8,LadderNumlv8,2*GrassCountlv8);
			int uvalid=UpValid(LadderXlv8,LadderYlv8,LadderNumlv8,2*GrassCountlv8);
			
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			Scroll(1140,840);
			Jack(360,840,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,LadderXlv8,LadderYlv8,LadderNumlv8,2*GrassCountlv8);
			if(fvalid==1){
				fall++;
			}
			
			SDL_RenderPresent(rend);
		
			}
		}
		else if(level==9){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
		
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv9=7;
			int GrassXlv9[]={360,360,480,840,1020,1140,1140};
			int GrassYlv9[]={300,840,540,840,720,540,300};
			int GrassNumlv9[]={7,4,7,8,3,10,7};
			Grass(GrassCountlv9,GrassXlv9,GrassYlv9,GrassNumlv9);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv9=6;
			int LadderXlv9[]={420,780,900,1080,1200,1560};
			int LadderYlv9[]={840,540,840,720,840,540};
			int LadderNumlv9[]={5,4,5,7,2,4};
			Lad(LadderCountlv9,LadderXlv9,LadderYlv9,LadderNumlv9);
			
//switch------------------------------------------------

			int rvalid = RightValid(GrassXlv9, GrassYlv9, GrassNumlv9, GrassCountlv9);
			int lvalid = LeftValid(GrassXlv9, GrassYlv9, GrassNumlv9, GrassCountlv9);
			int dvalid = DownValid(LadderXlv9, LadderYlv9, LadderNumlv9, 2 * GrassCountlv9);
			int uvalid = UpValid(LadderXlv9, LadderYlv9, LadderNumlv9, 2 * GrassCountlv9);

			SDL_Event ev;
			if (SDL_PollEvent(&ev))
			{

				if (ev.key.keysym.sym == SDLK_RIGHT && rvalid == 1)
				{

					right++;
				}
				else if (ev.key.keysym.sym == SDLK_LEFT && lvalid == 1)
				{
					left++;
				}
				else if (ev.key.keysym.sym == SDLK_UP && uvalid == 1)
				{
					up++;
				}
				else if (ev.key.keysym.sym == SDLK_DOWN && dvalid == 1)
				{
					down++;
				}
			}

			Scroll(1700,540);
			Jack(360,840, fall, right, left, up, down);

			int fvalid = FallValid(GrassXlv9, GrassYlv9, GrassNumlv9, GrassCountlv9, LadderXlv9, LadderYlv9, LadderNumlv9, 2 * GrassCountlv9);
			if (fvalid == 1)
			{
				fall++;
			}

			SDL_RenderPresent(rend);
		
			}
		}
		else if(level==10){
			while(complete==0){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
		
	
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv10=5;
			int GrassXlv10[]={300,600,960,1080,960};
			int GrassYlv10[]={780,840,780,600,300};
			int GrassNumlv10[]={6,7,10,7,3};
			Grass(GrassCountlv10,GrassXlv10,GrassYlv10,GrassNumlv10);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv10=5;
			int LadderXlv10[]={660,900,1020,1140,1400};
			int LadderYlv10[]={840,840,780,600,780};
			int LadderNumlv10[]={2,11,3,5,3};
			Lad(LadderCountlv10,LadderXlv10,LadderYlv10,LadderNumlv10);
			
//switch------------------------------------------------		
			







			int rvalid = RightValid(GrassXlv10,GrassYlv10,GrassNumlv10,GrassCountlv10);
			int lvalid = LeftValid(GrassXlv10,GrassYlv10,GrassNumlv10,GrassCountlv10);
			int dvalid = DownValid(LadderXlv10,LadderYlv10,LadderNumlv10,2 * GrassCountlv10);
			int uvalid = UpValid(LadderXlv10,LadderYlv10,LadderNumlv10,2 * GrassCountlv10);

			SDL_Event ev;
			if (SDL_PollEvent(&ev))
			{

				if (ev.key.keysym.sym == SDLK_RIGHT && rvalid == 1)
				{

					right++;
				}
				else if (ev.key.keysym.sym == SDLK_LEFT && lvalid == 1)
				{
					left++;
				}
				else if (ev.key.keysym.sym == SDLK_UP && uvalid == 1)
				{
					up++;
				}
				else if (ev.key.keysym.sym == SDLK_DOWN && dvalid == 1)
				{
					down++;
				}
			}

			Scroll(1500, 540);
			Jack(840, 300, fall, right, left, up, down);

			int fvalid = FallValid(GrassXlv10, GrassYlv10, GrassNumlv10, GrassCountlv10, LadderXlv10, LadderYlv10, LadderNumlv10, 2 * GrassCountlv10);
			if (fvalid == 1)
			{
				fall++;
			}
			
			SDL_RenderPresent(rend);
		
			}
		}
		else if(level==0){
			SDL_RenderClear(rend);
			srand(time(0));
			
			int i,j;
			int GrassCountend=(rand()%9);
				while(GrassCountend<5){
					GrassCountend=(rand()%9);
				}
			int GrassXend[GrassCountend];
			int GrassYend[GrassCountend];
			int GrassNumend[GrassCountend];
			
			int GrassXMin=29*60, GrassXMax=2*60, GrassYMin=1040, GrassYMax=100;
			int totalNum=0;
			int SortY[GrassCountend];
			int sortavr=0;
			int GrassDummyY[GrassCountend],GrassDummyNum[GrassCountend];
			int P=1;
			//Grassfield randomized organization
			
			while((!((GrassXMin<=8*60) && (GrassXMax<=26*60 && GrassXMax>=24*60) && (GrassYMin<=360) && (GrassYMax<=840 && GrassYMax>=780 && totalNum>=5*GrassCountend && sortavr>=3) && P==0))){
				
				GrassXMin=29*60;
				GrassXMax=2*60; 
				GrassYMin=1040;
				GrassYMax=100;
				totalNum=0;
				P=0;
				
			
				
				for(i=0;i<GrassCountend;i++){
					GrassXend[i]=360+(rand()%17)*60;
					GrassYend[i]=300+(rand()%10)*60;
					GrassNumend[i]=(rand()%10);
					while(GrassNumend[i]<2){
						GrassNumend[i]=(rand()%10);
					}
					if(GrassXend[i]<=GrassXMin){
						GrassXMin=GrassXend[i];
					}
					if(GrassXend[i]+GrassNumend[i]*60>=GrassXMax){
						GrassXMax=GrassXend[i]+GrassNumend[i]*60;
					}
					if(GrassYend[i]<=GrassYMin){
						GrassYMin=GrassYend[i];
					}
					if(GrassYend[i]>=GrassYMax){
						GrassYMax=GrassYend[i];
					}	
				}
				
				for(i=0;i<GrassCountend;i++){
					totalNum+=GrassNumend[i];
				}
				
				int j,YMax=0,sortp;
				
				for(i=0;i<GrassCountend;i++){
					GrassDummyY[i]=GrassYend[i];
				}
				
				for(i=0;i<GrassCountend;i++){
					YMax=0;
					for(j=0;j<GrassCountend;j++){
						if(YMax<=GrassDummyY[j]){
						YMax=GrassDummyY[j];
						sortp=j;
						}
					}
					GrassDummyY[sortp]=0;
					SortY[i]=YMax;
				}
				int sortn=0,sortdiff=0;
				for(i=1;i<GrassCountend;i++){
					if(SortY[i-1]>SortY[i]){
						sortn++;
						sortdiff+=(SortY[i-1]-SortY[i]);
					}
				}
				if(sortn!=0){
				sortavr=sortdiff/(60*sortn);
				printf("\navr:%d\tP:%d\tTotnum:%d\tGrass:%d|tXmin:%d\tXmax:%d\tYmin:%d\tYmax:%d\n",sortavr,P,totalNum,GrassCountend,GrassXMin,GrassXMax,GrassYMin,GrassYMax);
				}
				else{
					sortavr=1;
				}
				
				for(i=0;i<GrassCountend;i++){
					for(j=0;j<GrassCountend;j++){
						if(GrassYend[i]==GrassYend[j] && ((GrassXend[i]>GrassXend[j] && GrassXend[i]<=GrassXend[j]+GrassNumend[j]*60)||(i!=j && GrassXend[i]==GrassXend[j]))){
							P=1;
							break;
						}
					
					
					}
					if(P==1){
						break;
					}
				
				
				}
				
			
			}
			
			
			for(i=0;i<GrassCountend;i++){
					GrassDummyY[i]=GrassYend[i];
				}
			for(i=0;i<GrassCountend;i++){
					GrassDummyNum[i]=GrassNumend[i];
				}	
			
			//ladder randomized organisation
			
			int sortp,Xmin=30*60,GrassDummyX[GrassCountend],sortX[GrassCountend],sortn=0,sortdiff=0;
			
			int LadMapping[9][9]={0};
			int PosFinder[GrassCountend]={0};
			int pos,kkk;
			for(i=0;i<GrassCountend;i++){
				PosFinder[i]=i;
			}
			for(i=0;i<GrassCountend;i++){
				GrassDummyX[i]=GrassXend[i];
			}
			for(j=0;j<GrassCountend;j++){
				for(i=1;i<GrassCountend;i++){
					if(GrassDummyX[i-1]>GrassDummyX[i]){
						sortp=GrassDummyX[i-1];
						GrassDummyX[i-1]=GrassDummyX[i];
						GrassDummyX[i]=sortp;
						sortp=GrassDummyY[i-1];
						GrassDummyY[i-1]=GrassDummyY[i];
						GrassDummyY[i]=sortp;
						sortp=GrassDummyNum[i-1];
						GrassDummyNum[i-1]=GrassDummyNum[i];
						GrassDummyNum[i]=sortp;
						kkk=PosFinder[i-1];
						PosFinder[i-1]=PosFinder[i];
						PosFinder[i]=kkk;
					}
				
				}
			}
			
			arrayprint(GrassDummyX,GrassCountend);
			arrayprint(GrassDummyY,GrassCountend);
			arrayprint(GrassDummyNum,GrassCountend);
			arrayprint(PosFinder,GrassCountend);
			//LADDER - sorted GrassDummyX and GrassDummyY base on GrassDummyX
			
			int LadYlim[GrassCountend],limcount=0;
			int LadderYend[2*GrassCountend]={0};
			int LadderXend[2*GrassCountend]={0};
			int LadderNumend[2*GrassCountend]={0};
			int brk=0;
			int ladi=0;
			
			int Ladpos[GrassCountend];
			
			//ladder left(-60) Y-ground
			for(i=0;i<GrassCountend;i++){
				limcount=0;
				for(j=0;j<GrassCountend;j++){
					LadYlim[j]=30*60;
				}
				brk=0;
				for(j=0;j<i;j++){
					if((GrassDummyY[j]==GrassDummyY[i] && GrassDummyX[i]<=GrassDummyX[j]+GrassDummyNum[j]*60) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]+GrassDummyNum[j]*60>=GrassDummyX[i] && GrassDummyX[j]<GrassDummyX[i]) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]==GrassDummyX[i])){
						brk=1;	
					}
				}
				if(brk==1){
					continue;
				}
				
				
				
				for(j=0;j<GrassCountend;j++){
					if(GrassDummyX[j]<GrassDummyX[i] && GrassDummyX[j]+GrassDummyNum[j]*60>=GrassDummyX[i]){		
						LadYlim[limcount]=GrassDummyY[j];
						Ladpos[limcount]=j;
						limcount++;
						
					}
					
				
				}
				int MaxLim=30*60;
				
				printf("i=%d ",i);
				printf("lim:%dpos:%d\n",limcount,pos);
					
				arrayprint(LadYlim,GrassCountend);
				
				for(j=0;j<GrassCountend;j++){
					if(LadYlim[j]>GrassDummyY[i] && MaxLim>=LadYlim[j] && LadYlim[j]<18*60 && LadYlim[j]>0){
						MaxLim=LadYlim[j];
						pos=Ladpos[j];
					}
				}
				
				
				
				if(MaxLim==30*60){
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]==GrassDummyX[i] && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
							MaxLim=GrassDummyY[j];
							pos=j;
							break;
						}
					
				
					}
				
				}
				
				if(MaxLim==30*60){
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]+GrassDummyNum[j]*60==GrassDummyX[i]-60 && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
							MaxLim=GrassDummyY[j];
							pos=j;
							break;
						}
					
				
					}
				
				}
				
				
				
				
				LadderXend[ladi]=GrassDummyX[i]-60;
				
				printf("\n%d  pos%d   max%d\n",ladi,pos,MaxLim);
				arrayprint(PosFinder,GrassCountend);
				
				if(MaxLim!=30*60){
				LadMapping[PosFinder[i]][PosFinder[pos]]++;
				LadMapping[PosFinder[pos]][PosFinder[i]]++;
				}
				if(MaxLim<16*60 && MaxLim>0){
					LadderYend[ladi]=MaxLim;
				}
				else{
					LadderYend[ladi]=0;
				}
				LadderNumend[ladi]=(0-GrassDummyY[i]+LadderYend[ladi])/60;
				ladi++;
				
				printf("\nLX: ");
				arrayprint(LadderXend,2*GrassCountend);
				printf("\nLY: ");
				arrayprint(LadderYend,2*GrassCountend);
				printf("\nLN: ");
				arrayprint(LadderNumend,2*GrassCountend);
			
			}
			
			
			for(i=0;i<GrassCountend;i++){
				GrassDummyX[i]=GrassDummyX[i]+GrassDummyNum[i]*60;
			}
			int MaxLim;
			arrayprint(PosFinder,GrassCountend);
			
			for(i=0;i<GrassCountend;i++){
				for(j=1;j<GrassCountend;j++){
					if(GrassDummyX[j-1]>GrassDummyX[j]){
						MaxLim=GrassDummyX[j];
						GrassDummyX[j]=GrassDummyX[j-1];
						GrassDummyX[j-1]=MaxLim;
						MaxLim=GrassDummyY[j];
						GrassDummyY[j]=GrassDummyY[j-1];
						GrassDummyY[j-1]=MaxLim;
						MaxLim=GrassDummyNum[j];
						GrassDummyNum[j]=GrassDummyNum[j-1];
						GrassDummyNum[j-1]=MaxLim;
						kkk=PosFinder[j-1];
						PosFinder[j-1]=PosFinder[j];
						PosFinder[j]=kkk;
						
					}
				
				
				}
			
			
			}
			
			arrayprint(PosFinder,GrassCountend);
			
			printf("LADDER Right\n");
			
			
			printf("\nGrassX:");
			arrayprint(GrassDummyX,GrassCountend);
			printf("\nGrassY:");
			arrayprint(GrassDummyY,GrassCountend);
			printf("\nGrassNUM:");
			arrayprint(GrassDummyNum,GrassCountend);
			
			//ladder Right(+60) to ground
			
				for(i=0;i<GrassCountend;i++){
					printf("pass1\n");
					limcount=0;
					for(j=0;j<GrassCountend;j++){
						LadYlim[j]=30*60;
					}
					brk=0;
					for(j=i+1;j<GrassCountend;j++){
						if((GrassDummyY[j]==GrassDummyY[i] && GrassDummyX[i]>=GrassDummyX[j]-GrassDummyNum[j]*60) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]>=GrassDummyX[i] && GrassDummyX[j]-GrassDummyNum[j]*60<GrassDummyX[i]) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]==GrassDummyX[i])){
							brk=1;	
						}
					}
					if(brk==1){
						continue;
					}
					printf("pass2\n");
					printf("lim:%dpos:%d\n",limcount,pos);
					
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]>GrassDummyX[i] && GrassDummyX[j]-GrassDummyNum[j]*60<=GrassDummyX[i]){		
							LadYlim[limcount]=GrassDummyY[j];
							Ladpos[limcount]=j;
							limcount++;
						}
					
				
					}
					MaxLim=30*60;
					printf("i=%d ",i);
					arrayprint(LadYlim,GrassCountend);
					for(j=0;j<GrassCountend;j++){
						if(LadYlim[j]>GrassDummyY[i] && MaxLim>=LadYlim[j] && LadYlim[j]<18*60 && LadYlim[j]>0){
							MaxLim=LadYlim[j];
							pos=Ladpos[j];
						}
					}
				
				
				
					if(MaxLim==30*60){
						for(j=0;j<GrassCountend;j++){
							if(GrassDummyX[j]==GrassDummyX[i] && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
								MaxLim=GrassDummyY[j];
								pos=j;
								break;
							}
					
				
						}
				
					}
					
					if(MaxLim==30*60){
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]-GrassDummyNum[j]*60==GrassDummyX[i]+60 && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
							MaxLim=GrassDummyY[j];
							pos=j;
							break;
						}
					
				
					}
				
				}
				
				
				
					printf("\n%d  pos%d   max%d\n",ladi,pos,MaxLim);
					arrayprint(PosFinder,GrassCountend);
					LadderXend[ladi]=GrassDummyX[i];
					printf("PossFinder[i]: %d\t PossFinder[pos]:%d\n",PosFinder[i],PosFinder[pos]);
					if(MaxLim!=30*60){
					LadMapping[PosFinder[i]][PosFinder[pos]]++;
					LadMapping[PosFinder[pos]][PosFinder[i]]++;
					}
					
					printf("%d\n",MaxLim);
					
					if(MaxLim<16*60 && MaxLim>0){
						LadderYend[ladi]=MaxLim;
					}
					else{
						LadderYend[ladi]=0;
					}
					LadderNumend[ladi]=(0-GrassDummyY[i]+LadderYend[ladi])/60;
					ladi++;
					printf("\nLadderX: ");
					arrayprint(LadderXend,2*GrassCountend);
					printf("\nLadderY: ");
					arrayprint(LadderYend,2*GrassCountend);
					printf("\nLadderNUM: ");
					arrayprint(LadderNumend,2*GrassCountend);
			
			}
			printf("pos:");
			
			//single grassfield removing
			
			int connected[GrassCountend],connect=0;
			int unconnected[GrassCountend];
			
			for(i=0;i<GrassCountend;i++){
				int no_connection=0;
				for(j=0;j<GrassCountend;j++){
					if(LadMapping[i][j]!=0){
					no_connection=1;
					break;
					}
				
				}
				if(no_connection==0){
					connected[connect]=i;
					connect++;
					GrassYend[i]=-100;
				}
			
			
			}
			
			
			
			
			//Ladder map modifying && sequencing
			kkk=0;
			int k;
			for(i=0;i<GrassCountend;i++){
				for(j=0;j<GrassCountend;j++){
					if(kkk==1 && rand()%2==0 && LadMapping[i][j]==2){
						LadMapping[i][j]=1;
						LadMapping[j][i]=1;
						for(k=0;k<GrassCountend;k++){
							if((LadderXend[k]==GrassXend[i] && LadderYend[k]==GrassYend[j])){
								LadderYend[k]=0;
							}
							else if((LadderXend[k]==GrassXend[j] && LadderYend[k]==GrassYend[i])){
								LadderYend[k]=0;
							}
						}
						
					}
					else if(kkk==1 && rand()%2==1 && LadMapping[i][j]==2){
						continue;
					}
					if(LadMapping[i][j]==2){
						kkk=1;
					}
				}
			
			
			
			}

			int firstup= FirstUp(GrassXend,GrassYend,GrassCountend);
			int lastup= LastUp(GrassXend,GrassYend,GrassNumend,GrassCountend);
			
			connected[connect]=firstup;
			connect++;
			
			for(i=0;i<connect;i++){
				for(j=0;j<GrassCountend;j++){
					int nc=0;
					for(k=0;k<connect;k++){
						if(j==connected[k]){
							nc=1;
						}
					}
					
					if(LadMapping[connected[i]][j]!=0 && nc==0){
						connected[connect]=j;
						connect++;
						i=0;
						break;
					
					}
				}
			}
			
			connect=0;
			for(i=0;i<connect;i++){
				int nc=0;
				for(j=0;j<GrassCountend;j++){
					if(i==connected[j]){
						nc=1;
						break;
					}
				}
				
				if(nc==0){
					unconnected[connect]=i;
					connect++;
				}
			}
			
			for(i=0;i<connect;i++){
				for(j=0;j<GrassCountend;j++){
					int nc=0;
					for(k=0;k<connect;k++){
						if(j==unconnected[k]){
							nc=1;
						}
					}
					
					if(LadMapping[unconnected[i]][j]!=0 && nc==0){
						unconnected[connect]=j;
						connect++;
						i=0;
						break;
					
					}
				}
			}
			
			printf("CONNECTED:");
			arrayprint(connected,GrassCountend);
			
			printf("\nUNCONNECTED:");
			arrayprint(unconnected,GrassCountend);
			
			
			arrayprint(PosFinder,GrassCountend);
			matrixprint(LadMapping,GrassCountend);
			
			int jacky=GrassYend[firstup];
			
			int jackx;
			
			int endy=GrassYend[lastup],endx;
			
			
				GrassNumend[lastup]=GrassNumend[lastup]+3;
				endx=GrassXend[lastup]+(GrassNumend[lastup]-1)*60;
			

			printf("\nendx:%d endy:%d\n",endx,endy);
			
			
			if(GrassNumend[firstup]>=4){
				jackx=GrassXend[firstup]+3*60;
			}
			else{
				jackx=GrassXend[firstup];
			}
			
			printf("firstup:%d",firstup);
			
			SDL_Event ev;
			
			
			//SWITCH & DOOR CONFIG:			
			int switchRendX,switchRendY;
			int switchGendX,switchGendY;
			int switchBendX,switchBendY;
			int switchYendX,switchYendY;
			
			int doorRendX,doorRendY;
			int doorGendX,doorGendY;
			int doorBendX,doorBendY;
			int doorYendX,doorYendY;
			
			
			doorRendX=endx-60;
			doorRendY=endy;
			
			int singlelad=0,p,single[GrassCountend]={0};
			for(i=0;i<GrassCountend;i++){
				p=0;
				for(j=0;j<GrassCountend;j++){
					if(LadMapping[i][j]==1){
						p++;
					}
				}
				if(p==1){
					single[i]=1;
					singlelad++;
				}
			}
			
			for(j=0;j<singlelad;j++){
				for(i=0;i<GrassCountend;i++){
					if(single[i]==1){
						if(j==0){
						switchRendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchRendY=GrassYend[i];
						
						doorGendX=switchRendX-60;
						doorGendY=GrassYend[i];
						}
						else if(j==1){
						switchGendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchGendY=GrassYend[i];
						
						doorBendX=switchGendX-60;
						doorBendY=GrassYend[i];
						
						
						}
						else if(j==2){
						switchBendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchBendY=GrassYend[i];
						
						doorYendX=switchBendX-60;
						doorYendY=GrassYend[i];
						
						
						}
						else if(j==3){
						switchYendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchYendY=GrassYend[i];
						
						
						
						}
				
					}
				}
			}
			
			int a=rand()%GrassCountend,BoxX1=GrassXend[a]+60*(rand()%GrassNumend[a]),BoxY1=GrassYend[a];
			int b=rand()%GrassCountend;
			while(b==a){
			b=rand()%GrassCountend;
			}
			int BoxX2=GrassXend[b]+60*(rand()%GrassNumend[b]),BoxY2=GrassYend[b];
			
			int c=rand()%GrassCountend;
			while(b==c || a==c){
			c=rand()%GrassCountend;
			}
			int BarX=GrassXend[c]+60*(rand()%GrassNumend[c]),BarY=GrassYend[c];
			while(i!=-1){
			
			int rvalid=RightValid(GrassXend,GrassYend,GrassNumend,GrassCountend);
			int lvalid=LeftValid(GrassXend,GrassYend,GrassNumend,GrassCountend);
			int dvalid=DownValid(LadderXend,LadderYend,LadderNumend,2*GrassCountend);
			int uvalid=UpValid(LadderXend,LadderYend,LadderNumend,2*GrassCountend);
			
			
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
	
					right++;
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			
			SDL_RenderClear(rend);

			Grass(GrassCountend,GrassXend,GrassYend,GrassNumend);
			Lad(2*GrassCountend,LadderXend,LadderYend,LadderNumend);
			Scroll(endx,endy);
			Jack(jackx,jacky,fall,right,left,up,down);
			
			int fvalid=FallValid(GrassXend,GrassYend,GrassNumend,GrassCountend,LadderXend,LadderYend,LadderNumend,2*GrassCountend);
			if(fvalid==1){
				fall++;
			}



			
			
			
			
			
			
			
			int SwitchCount=4;
			int SwitchConend[]={0,0,0,0};
			int SwitchX[]={switchRendX,switchGendX,switchBendX,switchYendX};
			int SwitchY[]={switchRendY,switchGendY,switchBendY,switchYendY};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			
			for(i=0;i<SwitchCount;i++){
				SwitchConend[i]=SwitchCondition(SwitchX,SwitchY,i);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConend);
			
			int DoorCount=4;
			int DoorX[]={doorRendX,doorGendX,doorBendX,doorYendX};
			int DoorY[]={doorRendY,doorGendY,doorBendY,doorYendY};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};
			
			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConend);
			
			
			int BoxCountlv2=2;
			int BoxXlv2[]={BoxX1,BoxX2};
			int BoxYlv2[]={BoxY1,BoxY2};
			
			Box(BoxXlv2,BoxYlv2,BoxCountlv2,boxright,boxleft,boxfall);
			
			BARL(BarX,BarY,barright,barleft,barfall);
			
			
			
			SDL_RenderPresent(rend);
			SDL_Delay(20);
			
			}
		}
	SDL_Delay(1000000);

	SDL_Quit();

}

