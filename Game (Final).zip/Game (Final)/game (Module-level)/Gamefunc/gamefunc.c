#include<stdio.h>
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<SDL2/SDL_timer.h>
#include<GL/gl.h>
#include<math.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>	
#include<bits/stdc++.h>
#include<time.h>
#include"gamefunc.h"
	
	
	int i,j,k;
	int doorclose[4]={0};
	int boxr[4]={0},boxl[4]={0},boxf[4]={0};
	int barterm=0;
	int rev=1;
	int rollr=0,rolll=0;
	
	SDL_Window* win;
	SDL_Renderer* rend;
	
	SDL_Surface* num;
	SDL_Texture* one;
	SDL_Texture* two;
	SDL_Texture* three;
	SDL_Texture* four;
	SDL_Texture* five;
	SDL_Texture* six;
	SDL_Texture* seven;
	SDL_Texture* eight;
	SDL_Texture* nine;
	
	
	SDL_Surface* grassfield;
	SDL_Texture* Grassfield;
	
	SDL_Surface* door1;
	SDL_Texture* DoorR;
	SDL_Surface* door2;
	SDL_Texture* DoorG;
	SDL_Surface* door3;
	SDL_Texture* DoorB;
	SDL_Surface* door4;
	SDL_Texture* DoorYe;
	
	SDL_Surface* ladder1;
	SDL_Surface* ladder2;
	SDL_Texture* Ladder;
	SDL_Texture* Ladder1;
	
	SDL_Surface* swtch1;
	SDL_Surface* swtch2;
	SDL_Surface* swtch3;
	SDL_Surface* swtch4;
	SDL_Surface* swtchoff1;
	SDL_Surface* swtchoff2;
	SDL_Surface* swtchoff3;
	SDL_Surface* swtchoff4;
	SDL_Texture* SwitchR;
	SDL_Texture* SwitchB;
	SDL_Texture* SwitchG;
	SDL_Texture* SwitchY;
	SDL_Texture* SwitchRoff;
	SDL_Texture* SwitchGoff;
	SDL_Texture* SwitchBoff;
	SDL_Texture* SwitchYoff;
	
	SDL_Surface* bggg;
	SDL_Texture* Bgg;
	
	SDL_Surface* jack;
	SDL_Texture* Jackrest;
	SDL_Texture* Jackwalk1;
	SDL_Texture* Jackwalk2;
	SDL_Texture* Jackwalk3;
	SDL_Texture* Jackwalk4;
	SDL_Texture* Jackwalk5;
	SDL_Texture* Jackwalk6;
	SDL_Texture* Jackwalk7;
	SDL_Texture* Jackwalk8;
	SDL_Texture* Jackclimb1;
	SDL_Texture* Jackclimb2;
	SDL_Texture* Jackdrag;
	
	SDL_Surface* paper;
	SDL_Texture* PRoll;
		
	SDL_Surface* box;
	SDL_Texture* BoxS;
	SDL_Surface* barrel;
	SDL_Texture* Barrel;
	
	SDL_Surface* restart;
	SDL_Texture* Restart;
	SDL_Surface* hhome;
	SDL_Texture* Home;
	
	SDL_Rect JACKK;
	SDL_Rect BOXX;
	SDL_Rect BARREL;
	SDL_Rect BARRIER;		
	SDL_Event event;
	SDL_Event e;
	SDL_Surface* vic;
	SDL_Texture* Vic;
	SDL_Rect PROLL;
	int levelup=0;
	extern int EventDiffChecker;
	extern int rrr;
	extern int lll;
	extern int barright,barleft;
	int fullterm=0;
	int rota=0;
		

void arrayprint(int a[],int sizea){
		int i;
		for(i=0;i<sizea;i++){
		
			printf("%d\t",a[i]);
		
		}
		printf("\n");
	
	
	
	
	
	
	
	}
	
void matrixprint(int a[9][9],int b){
		int i,j;
		printf("\n#############################\n");
		for(i=0;i<b;i++){
			for(j=0;j<b;j++){
			
				printf("%d ",a[i][j]);	
			
			}
			printf("\n");
		}		
	
		printf("#############################\n");
	}

void Grass(int t,int GrassX[],int GrassY[],int GrassNum[]){
		int i=0,j=0;
		SDL_Rect GRASSFIELD;
		SDL_QueryTexture(Grassfield,NULL,NULL,&GRASSFIELD.w,&GRASSFIELD.h);
		GRASSFIELD.h=60;
		GRASSFIELD.w=60;
		
		for(j=0;j<t;j++){
			for(i=0;i<GrassNum[j];i++){
				GRASSFIELD.x=GrassX[j]+60*i;
				GRASSFIELD.y=GrassY[j];
				SDL_RenderCopy(rend,Grassfield,NULL,&GRASSFIELD);
			}
		
			if(j==0){
				SDL_RenderCopy(rend,one,NULL,&GRASSFIELD);
			}
			else if(j==1){
				SDL_RenderCopy(rend,two,NULL,&GRASSFIELD);
			}
			else if(j==2){
				SDL_RenderCopy(rend,three,NULL,&GRASSFIELD);
			}
			else if(j==3){
				SDL_RenderCopy(rend,four,NULL,&GRASSFIELD);
			}
			else if(j==4){
				SDL_RenderCopy(rend,five,NULL,&GRASSFIELD);
			}
			else if(j==5){
				SDL_RenderCopy(rend,six,NULL,&GRASSFIELD);
			}
			else if(j==6){
				SDL_RenderCopy(rend,seven,NULL,&GRASSFIELD);
			}
			else if(j==7){
				SDL_RenderCopy(rend,eight,NULL,&GRASSFIELD);
			}
			else if(j==8){
				SDL_RenderCopy(rend,nine,NULL,&GRASSFIELD);
			}
			
		}	
	
	}
	
		
void Lad(int t,int LadderX[],int LadderY[],int LadderNum[]){
		int i=0,j=0;
		SDL_Rect LADDER;
		SDL_QueryTexture(Ladder,NULL,NULL,&LADDER.w,&LADDER.h);
		LADDER.h=60;
		LADDER.w=50;
		
		for(j=0;j<t;j++){
			for(i=0;i<LadderNum[j];i++){
				LADDER.x=LadderX[j]+5;
				LADDER.y=LadderY[j]-60-60*i;
				SDL_RenderCopy(rend,Ladder,NULL,&LADDER);
			}
			if(LadderNum[j]!=0 && LadderX[j]!=0 && LadderY[j]!=0){
			LADDER.y=LadderY[j]-60-60*(LadderNum[j]-1)-60;
			SDL_RenderCopy(rend,Ladder1,NULL,&LADDER);
			}
		}
			
	
	}

void Grid(){
	
		SDL_SetRenderDrawColor(rend,0,0,0,SDL_ALPHA_OPAQUE);
		SDL_RenderDrawLine(rend,0,0,1920,1080);
		SDL_RenderDrawLine(rend,0,1080,1920,0);

	
		SDL_SetRenderDrawColor(rend,100,100,100,SDL_ALPHA_OPAQUE);
	
		SDL_Rect Display;
		Display.x=0;
		Display.y=0;
		Display.h=1080;
		Display.w=1920;
	
	
	
		SDL_RenderFillRect(rend,&Display);	
		SDL_SetRenderDrawColor(rend,0,0,0,SDL_ALPHA_OPAQUE);
		int hor,ver;
		for(hor=0;hor<=1920;hor=hor+10){
			SDL_RenderDrawLine(rend,hor,0,hor,1080);
		}
		for(ver=0;ver<=1080;ver=ver+10){
			SDL_RenderDrawLine(rend,0,ver,1920,ver);
		}	
		
		SDL_SetRenderDrawColor(rend,255,0,0,SDL_ALPHA_OPAQUE);
		for(hor=0;hor<=1920;hor=hor+100){
			SDL_RenderDrawLine(rend,hor,0,hor,1080);
		}
		for(ver=0;ver<=1080;ver=ver+100){
			SDL_RenderDrawLine(rend,0,ver,1920,ver);
		}		
	
	
	
	
	}
	
	
void Switch(int t, int SwtchX[],int SwtchY[],int SwitchColour[],int SwitchCon[]){
		int i;
		
		
		
		for(i=0;i<t;i++){
		
			SDL_Rect SWITCH;
			SDL_QueryTexture(SwitchR,NULL,NULL,&SWITCH.w,&SWITCH.h);
			SDL_QueryTexture(SwitchG,NULL,NULL,&SWITCH.w,&SWITCH.h);
			SDL_QueryTexture(SwitchB,NULL,NULL,&SWITCH.w,&SWITCH.h);
			SDL_QueryTexture(SwitchY,NULL,NULL,&SWITCH.w,&SWITCH.h);
			SWITCH.h=30;
			SWITCH.w=40;
			
			SDL_Rect SWITCHOFF;
			SDL_QueryTexture(SwitchRoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SDL_QueryTexture(SwitchGoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SDL_QueryTexture(SwitchBoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SDL_QueryTexture(SwitchYoff,NULL,NULL,&SWITCHOFF.w,&SWITCHOFF.h);
			SWITCHOFF.h=30;
			SWITCHOFF.w=40;
		
		
			SWITCH.x=SwtchX[i]+10;
			SWITCH.y=SwtchY[i]-30;
			SWITCHOFF.x=SwtchX[i]+10;
			SWITCHOFF.y=SwtchY[i]-25;
		if(SwitchColour[i]==1){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchR,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchRoff,NULL,&SWITCHOFF);
			}
		
		
		}
		else if(SwitchColour[i]==2){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchG,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchGoff,NULL,&SWITCHOFF);
			}
		
		}
		else if(SwitchColour[i]==3){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchB,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchBoff,NULL,&SWITCHOFF);
			}
		
		}
		else if(SwitchColour[i]==4){
			if(SwitchCon[i]==0){
				SDL_RenderCopy(rend,SwitchY,NULL,&SWITCH);
			}
			else if(SwitchCon[i]==1){
				SDL_RenderCopy(rend,SwitchYoff,NULL,&SWITCHOFF);
			}
		
		}
		}
	
	}
	
	
	
void Door(int t, int DoorX[],int DoorY[],int DoorColour[],int SwitchCon[]){
		int i;
		
			SDL_Rect DOORR;
			SDL_QueryTexture(DoorR,NULL,NULL,&DOORR.w,&DOORR.h);
			DOORR.h=80-0.25*doorclose[0];
			DOORR.w=20;
			DOORR.x=DoorX[0];
			DOORR.y=DoorY[0]-80+0.25*doorclose[0];
			
			SDL_Rect DOORG;
			SDL_QueryTexture(DoorG,NULL,NULL,&DOORG.w,&DOORG.h);
			DOORG.h=80-0.25*doorclose[1];
			DOORG.w=20;
			DOORG.x=DoorX[1];
			DOORG.y=DoorY[1]-80+0.25*doorclose[1];
			
			SDL_Rect DOORB;
			SDL_QueryTexture(DoorB,NULL,NULL,&DOORB.w,&DOORB.h);
			DOORB.h=80-0.25*doorclose[2];
			DOORB.w=20;
			DOORB.x=DoorX[2];
			DOORB.y=DoorY[2]-80+0.25*doorclose[2];
			
			SDL_Rect DOORYE;
			SDL_QueryTexture(DoorYe,NULL,NULL,&DOORYE.w,&DOORYE.h);
			DOORYE.h=80-0.25*doorclose[3];
			DOORYE.w=20;
			DOORYE.x=DoorX[3];
			DOORYE.y=DoorY[3]-80+0.25*doorclose[3];
			
				
		
		for(i=0;i<t;i++){
	
		if(DoorColour[i]==1){
			if(SwitchCon[i]==1  && DOORR.h>-80 ){
				doorclose[i]=doorclose[i]+20;
				if(doorclose[i]>4*80){
					doorclose[i]=4*160;
				}
			}
			else if(SwitchCon[i]==0 && DOORR.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}	
			SDL_RenderCopy(rend,DoorR,NULL,&DOORR);
		
		}
		else if(DoorColour[i]==2){
			if(SwitchCon[i]==1 && DOORG.h>-80){
				doorclose[i]=doorclose[i]+20;
				
			}
			else if(SwitchCon[i]==0 && DOORG.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}
			SDL_RenderCopy(rend,DoorG,NULL,&DOORG);
		}
		else if(DoorColour[i]==3){
			if(SwitchCon[i]==1  && DOORB.h>-80){
				doorclose[i]=doorclose[i]+20;
			}
			else if(SwitchCon[i]==0 && DOORB.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}
			SDL_RenderCopy(rend,DoorB,NULL,&DOORB);
		}
		else if(DoorColour[i]==4){
			if(SwitchCon[i]==1  && DOORYE.h>-80){
				doorclose[i]=doorclose[i]+20;
			}
			else if(SwitchCon[i]==0  && DOORYE.h<80){
				doorclose[i]=doorclose[i]-1.25;
			}
			SDL_RenderCopy(rend,DoorYe,NULL,&DOORYE);
		
		}
		}
	
	}
	
	
int Max(int MaxN,int maxcom[],int MAXX){
			int j;
					for(j=0;j<MaxN;j++){
						if(MAXX<=maxcom[j]){
						MAXX=maxcom[j];
						}
					}

				
				return MAXX;

			}
	
int FirstUp(int grassX[],int grassY[],int t){
		int i,j,firstup=2000;
		for(i=0;i<t;i++){
		
			if(grassX[i]<=firstup){
				firstup=grassX[i];
			}
		
		}
		int upfirst=2000,min=2000;
		for(i=0;i<t;i++){
		
			if(grassY[i]<=min && grassX[i]==firstup){
				min=grassY[i];
				upfirst=i;
			}
		
		}
	
	
		return upfirst;
	}
	
int LastUp(int grassX[],int grassY[],int grassNum[], int t){
		int i,j,lastup=0;
		for(i=0;i<t;i++){
		
			if(grassX[i]+grassNum[i]*60>=lastup){
				lastup=grassX[i]+grassNum[i]*60;
			}
		
		}
		int uplast=0,max=0;
		for(i=0;i<t;i++){
		
			if(grassY[i]>=max && grassX[i]+grassNum[i]*60==lastup){
				max=grassY[i];
				uplast=i;
			}
		
		}
	
	
		return uplast;
	}
	
	
	
			
	
void Jack(int JackX,int JackY,int JackF,int JackR,int JackL,int JackU,int JackD,int uvalid,int dvalid, int fvalid){
				
		SDL_QueryTexture(Jackrest,NULL,NULL,&JACKK.w,&JACKK.h);
		JACKK.h=80;
		JACKK.w=60;
		JACKK.x=JackX+5*JackR-5*JackL;
		JACKK.y=JackY-80+5*JackD-5*JackU+5*JackF;
	
	
		if((uvalid==1||dvalid==1) && JACKK.y%40<20){
		SDL_RenderCopy(rend,Jackclimb1,NULL,&JACKK);
		}
		else if((uvalid==1||dvalid==1) && JACKK.y%40>=20){
		SDL_RenderCopy(rend,Jackclimb2,NULL,&JACKK);
		}
		else if(EventDiffChecker>3 || fvalid==1){
		SDL_RenderCopy(rend,Jackrest,NULL,&JACKK);
		}
		else if(rrr!=0 && lll==0){
			if(rrr%28<4){
				SDL_RenderCopy(rend,Jackwalk1,NULL,&JACKK);
			}
			else if(rrr%28>=4 && rrr%28<8){
				SDL_RenderCopy(rend,Jackwalk2,NULL,&JACKK);
			}
			else if(rrr%28>=24){
				SDL_RenderCopy(rend,Jackwalk3,NULL,&JACKK);
			}
			else if(rrr%28>=8 && rrr%28<12){
				SDL_RenderCopy(rend,Jackwalk4,NULL,&JACKK);
			}
			else if(rrr%28>=12 && rrr%28<16){
				SDL_RenderCopy(rend,Jackwalk5,NULL,&JACKK);
			}
			else if(rrr%28>=16 && rrr%28<20){
				SDL_RenderCopy(rend,Jackwalk6,NULL,&JACKK);
			}
			else if(rrr%28>=20 && rrr%28<24){
				SDL_RenderCopy(rend,Jackwalk7,NULL,&JACKK);
			}
			
		
		}
		else if(lll!=0 && rrr==0){
			if(lll%28<4){
				SDL_RenderCopyEx(rend,Jackwalk1,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
			else if(lll%28>=4 && lll%28<8){
				SDL_RenderCopyEx(rend,Jackwalk2,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
			else if(lll%28>=24){
				SDL_RenderCopyEx(rend,Jackwalk3,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
			else if(lll%28>=8 && lll%28<12){
				SDL_RenderCopyEx(rend,Jackwalk4,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
			else if(lll%28>=12 && lll%28<16){
				SDL_RenderCopyEx(rend,Jackwalk5,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
			else if(lll%28>=16 && lll%28<20){
				SDL_RenderCopyEx(rend,Jackwalk6,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
			else if(lll%28>=20 && lll%28<24){
				SDL_RenderCopyEx(rend,Jackwalk7,NULL,&JACKK,0,NULL,SDL_FLIP_HORIZONTAL);
			}
		
		
		}
		else{
			SDL_RenderCopy(rend,Jackrest,NULL,&JACKK);
		}
		
	}




void Scroll(int scrollx,int scrolly){
		
		SDL_QueryTexture(PRoll,NULL,NULL,&PROLL.w,&PROLL.h);
		PROLL.h=50;
		PROLL.w=20;
		PROLL.x=scrollx;
		PROLL.y=scrolly-60;
	
		SDL_RenderCopy(rend,PRoll,NULL,&PROLL);
	
	}

		
	

int RightValid(int grassX[],int grassY[],int grassNum[],int t,int boxcount, int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[],int dcount,int doorX[],int doorY[],int ladderX[],int ladderY[],int ladderNum[],int bcount,int barrierX[],int barrierY[]){
		int p=0,q=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.y==grassY[i]-80 && JACKK.x>=grassX[i]-60 && JACKK.x+60<grassX[i]+grassNum[i]*60+60){
				p=1;
			}
		
		}
		for(i=0;i<2*t;i++){
			if(JACKK.x==ladderX[i] && JACKK.y+80<=ladderY[i] && JACKK.y+80>=ladderY[i]-ladderNum[i]*60){
				p=1;
				q=1;
			}
		
		
		
		}
		for(i=0;i<boxcount;i++){
			if(JACKK.x+50>BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.x+10<=BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 && JACKK.y+80==BoxY[i]-80+5*Boxf[i]){
				p=1;
			}
		
		
		
		}
		
		if(JACKK.x+50>BARREL.x && JACKK.x+10<BARREL.x+60 && JACKK.y+80==BARREL.y){
				p=1;
			}
		
		for(i=0;i<bcount;i++){
			if((JACKK.y+80==barrierY[i]-60 && JACKK.x+50>barrierX[i] && JACKK.x+10<barrierX[i]+20)){
				p=1;
				break;
			}
			
		}
		
		for(i=0;i<dcount;i++){
			if((JACKK.y+80==doorY[i]-80+doorclose[i]/4 && JACKK.x+50>doorX[i] && JACKK.x+10<doorX[i]+20)){
				p=1;
				break;
			}
			
		}
		for(i=0;i<t;i++){
			if((JACKK.y+20<grassY[i]+60 && JACKK.y>grassY[i]-80) && (JACKK.x+50==grassX[i] || (JACKK.x+60==grassX[i] && q==1))){
				p=0;
			}
		
		}
		for(i=0;i<boxcount;i++){
			if((boxr[i]==0 && JACKK.y==BoxY[i]-80+5*Boxf[i] && JACKK.x+50==BoxX[i]+5*Boxr[i]-5*Boxl[i]) || ( JACKK.y<BoxY[i]-80+5*Boxf[i] && JACKK.y+80>BoxY[i]-80+5*Boxf[i] && (JACKK.x+50==BoxX[i]+5*Boxr[i]-5*Boxl[i] || (q==1 && JACKK.x+60<=BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.x+120>BoxX[i]+5*Boxr[i]-5*Boxl[i])))){
				p=0;
				break;
			}
			
		}
		if(BARREL.x>=JACKK.x+50 && BARREL.x<JACKK.x+110 && JACKK.y+80<BARREL.y+60 && JACKK.y+80>BARREL.y){
			p=0;
			
		}
		
		for(i=0;i<dcount;i++){
			if(JACKK.y<=doorY[i]-80 && JACKK.y+80>doorY[i]-80 && JACKK.x+50==doorX[i] && doorclose[i]<320){
				p=0;
			}
		
		}
		
		for(i=0;i<bcount;i++){
			if(JACKK.y<=barrierY[i]-80 && JACKK.y+80>barrierY[i]-60 && JACKK.x+50==barrierX[i]){
				p=0;
			}
		
		}
		for(i=0;i<bcount;i++){
		if(BARREL.x==JACKK.x+50 && BARREL.x+60>=barrierX[i] && BARREL.x+60<=barrierX[i]+10 && BARREL.y+60==barrierY[i]+60 && BARREL.y+60==JACKK.y+80){
			p=0;
		}
		}
		
		if((barterm==1 || fullterm==1) && BARREL.x<=JACKK.x+50 && BARREL.x+10>=JACKK.x+50 && BARREL.y+60==JACKK.y+80){
			p=0;
		}
		
		
		return p;
	}


int LeftValid(int grassX[],int grassY[],int grassNum[],int t,int boxcount, int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[],int dcount,int doorX[],int doorY[],int ladderX[],int ladderY[],int ladderNum[],int bcount,int barrierX[],int barrierY[]){
		int p=0,q=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.y==grassY[i]-80 && JACKK.x>grassX[i]-60 && JACKK.x+60<=grassX[i]+grassNum[i]*60+60){
				p=1;
			}
		
		
		
		}
		
		for(i=0;i<2*t;i++){
			if(JACKK.x==ladderX[i] && JACKK.y+80<=ladderY[i] && JACKK.y+80>=ladderY[i]-ladderNum[i]*60){
				p=1;
				q=1;
			}
		
		}
		
		for(i=0;i<boxcount;i++){
			if(JACKK.x+50>BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.x+10<=BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 && JACKK.y+80==BoxY[i]-80+5*Boxf[i]){
				p=1;
			}
		
		
		
		}
		
		if(JACKK.x+50>BARREL.x && JACKK.x+10<BARREL.x+60 && JACKK.y+80==BARREL.y){
				p=1;
			}
			
		for(i=0;i<bcount;i++){
			if((JACKK.y+80==barrierY[i]-60 && JACKK.x+50>barrierX[i] && JACKK.x+10<barrierX[i]+20)){
				p=1;
				break;
			}
			
		}
		
		for(i=0;i<dcount;i++){
			if((JACKK.y+80==doorY[i]-80+doorclose[i]/4 && JACKK.x+50>doorX[i] && JACKK.x+10<doorX[i]+20)){
				p=1;
				break;
			}
			
		}	

		for(i=0;i<t;i++){
			if((JACKK.y+20<grassY[i]+60 && JACKK.y>grassY[i]-80) && (JACKK.x+10==grassX[i]+grassNum[i]*60 || (JACKK.x==grassX[i]+grassNum[i]*60 && q==1))){
				p=0;
			}
		
		}
		for(i=0;i<boxcount;i++){
			if(boxl[i]==0 && JACKK.y==BoxY[i]-80+5*Boxf[i] && JACKK.x==BoxX[i]+5*Boxr[i]-5*Boxl[i]+70|| ( JACKK.y<BoxY[i]-80+5*Boxf[i] && JACKK.y+80>BoxY[i]-80+5*Boxf[i] && (JACKK.x+10==BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 || (q==1 && JACKK.x>=BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 && JACKK.x<BoxX[i]+5*Boxr[i]-5*Boxl[i]+80+60 )))){
				p=0;
				break;
			}
			
		}
		
		if(BARREL.x+60<=JACKK.x+10 && BARREL.x+120>JACKK.x+10 && JACKK.y+80<BARREL.y+60 && JACKK.y+80>BARREL.y){
			p=0;
			
		}
		
		for(i=0;i<dcount;i++){
			if(JACKK.y<=doorY[i]-80 && JACKK.y+80>doorY[i]-80 && JACKK.x+10==doorX[i]+20 && doorclose[i]<320){
				p=0;
			}
		
		}
		for(i=0;i<bcount;i++){
			if(JACKK.y<=barrierY[i]-80 && JACKK.y+80>barrierY[i]-60 && JACKK.x+10==barrierX[i]+20){
				p=0;
			}
		
		}
		
		for(i=0;i<bcount;i++){
		if(BARREL.x+60==JACKK.x+10 && BARREL.x<=barrierX[i]+20 && BARREL.x>=barrierX[i] && BARREL.y+60==barrierY[i]+60 && BARREL.y+60==JACKK.y+80){
			p=0;
		}
		}
		if((barterm==1 || fullterm==1) && BARREL.x+60>=JACKK.x+10 && BARREL.x+60<=JACKK.x+20 && BARREL.y+60==JACKK.y+80){
			p=0;
		}
		
		
		return p;
	}
	
int DownValid(int LadderX[],int LadderY[],int LadderNum[],int t,int boxcount,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[]){
		int p=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.x==LadderX[i] && JACKK.y+80<LadderY[i] && JACKK.y+80>=LadderY[i]-LadderNum[i]*60){
				p=1;
			}
		
		
		
		}
		
		for(i=0;i<boxcount;i++){
			if((JACKK.y+80==BoxY[i]-80+5*Boxf[i] && JACKK.x+50>BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.x<BoxX[i]+5*Boxr[i]-5*Boxl[i]+80)){
				p=0;
				break;
			}
			
		}
		
		
		if((JACKK.y+80==BARREL.y && JACKK.x+50>BARREL.x && JACKK.x+10<BARREL.x+60)){
				p=0;
			}
		
			
			
		return p;
	}

int UpValid(int LadderX[],int LadderY[],int LadderNum[],int t,int boxcount, int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[]){
		int p=0;
		int i,j,k;
		
		for(i=0;i<t;i++){
			if(JACKK.x==LadderX[i] && JACKK.y+80<=LadderY[i] && JACKK.y+80>LadderY[i]-LadderNum[i]*60){
				p=1;
			}		
		
		
		}
		
		
		for(i=0;i<boxcount;i++){
			if((JACKK.y==BoxY[i]+5*Boxf[i] && JACKK.x+50>BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.x<BoxX[i]+5*Boxr[i]-5*Boxl[i]+80)){
				p=0;
				break;
			}
			
		}
		
		return p;
	}
	
	
int FallValid(int grassX[],int grassY[],int grassNum[],int t1,int LadderX[],int LadderY[],int LadderNum[],int t2,int boxcount,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[],int barrierX[],int barrierY[],int t3,int DoorX[],int DoorY[],int t4){
		int p=1;
		int i,j,k;
		for(i=0;i<t1;i++){
			if((JACKK.y==grassY[i]-80 && JACKK.x>grassX[i]-60 && JACKK.x+60<grassX[i]+grassNum[i]*60+60)){
				p=0;
				break;
			}		
		}
		
		for(i=0;i<t2;i++){
			if((JACKK.x==LadderX[i] && JACKK.y+80<=LadderY[i] && JACKK.y+80>=LadderY[i]-LadderNum[i]*60)){			
				p=0;
				break;
			}
		}
		
		for(i=0;i<boxcount;i++){
			if((JACKK.y+80==BoxY[i]-80+5*Boxf[i] && JACKK.x+50>BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.x+10<BoxX[i]+5*Boxr[i]-5*Boxl[i]+80)){
				p=0;
				break;
			}
			
		}
		for(i=0;i<t3;i++){
			if((JACKK.y+80==barrierY[i]-60 && JACKK.x+50>barrierX[i] && JACKK.x+10<barrierX[i]+20)){
				p=0;
				break;
			}
			
		}
		
		for(i=0;i<t4;i++){
			if((JACKK.y+80==DoorY[i]-80+doorclose[i]/4 && JACKK.x+50>DoorX[i] && JACKK.x+10<DoorX[i]+20)){
				p=0;
				break;
			}
			
		}
		
		if((JACKK.y+80==BARREL.y && JACKK.x+50>BARREL.x && JACKK.x+10<BARREL.x+60)){
				p=0;
			}
		
		return p;
	}
	
	
int SwitchCondition(int switchX[],int switchY[],int t1,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[],int t2){
		int p=0;
		if((JACKK.x>switchX[t1]-30 && JACKK.x+60<switchX[t1]+60+30 && JACKK.y+80==switchY[t1])){
			p=1;
		}
		if((BARREL.x>switchX[t1]-40 && BARREL.x+60<switchX[t1]+60+40 && BARREL.y+60==switchY[t1])){
			p=1;
		}
		for(j=0;j<t2;j++){
			if((BoxX[j]+5*Boxr[j]-5*Boxl[j]-10<switchX[t1] && BoxX[j]+5*Boxr[j]-5*Boxl[j]+50>switchX[t1] && BoxY[j]+5*Boxf[j]==switchY[t1])){
				p=1;
			}
		
		}
		return p;
		
	}



void Box(int BoxX[],int BoxY[],int t,int Boxr[],int Boxl[],int Boxf[]){
	
		
		SDL_QueryTexture(BoxS,NULL,NULL,&BOXX.w,&BOXX.h);
		BOXX.h=80;
		BOXX.w=80;
		
		for(i=0;i<t;i++){
			BOXX.x=BoxX[i]+5*Boxr[i]-5*Boxl[i];
			BOXX.y=BoxY[i]-80+5*Boxf[i];
		
			SDL_RenderCopy(rend,BoxS,NULL,&BOXX);
		}
	}
	
int BoxRightValid(int t1,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[], int grassX[],int grassY[],int grassNum[],int t2,int DoorX[],int DoorY[],int t3){
		for(i=0;i<t1;i++){
			boxr[i]=0;
		}
		for(i=0;i<t1;i++){
			if(JACKK.x+50==BoxX[i]+5*Boxr[i]-5*Boxl[i] && JACKK.y==BoxY[i]-80+5*Boxf[i]){
				boxr[i]=1;
			}
						
		}
		for(j=0;j<t1;j++){
			if(BoxX[j]+5*Boxr[j]-5*Boxl[j]>BARREL.x-80 && BoxX[j]+5*Boxr[j]-5*Boxl[j]<BARREL.x+60 && BoxY[j]+5*Boxf[j]==BARREL.y+60){		

				boxr[j]=0;
			}			
	
	
		}
	
		for(j=0;j<t1;j++){
			for(i=0;i<t2;i++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]+80==grassX[i] && BoxY[j]+5*Boxf[j]-60==grassY[i]){		

					boxr[j]=0;
				}		
			}	
		
	
		}
		for(j=0;j<t1;j++){
			for(i=0;i<t3;i++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]+80==DoorX[i] && BoxY[j]+5*Boxf[j]==DoorY[i] && doorclose[i]<320){		

					boxr[j]=0;
				}		
			}	
		
	
		}
		for(j=0;j<t1;j++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]+80==BARREL.x && BoxY[j]+5*Boxf[j]==BARREL.y+60){		

					boxr[j]=0;
				}		
		}
		
		
		for(i=0;i<t1;i++){
			if(boxr[i]==1){
				return i+1;
			}
		}
		return 0;
	
	}
int BoxLeftValid(int t1,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[], int grassX[],int grassY[],int grassNum[],int t2,int DoorX[],int DoorY[],int t3){
		for(i=0;i<t1;i++){
			boxl[i]=0;
		}
		for(i=0;i<t1;i++){
			if(JACKK.x+10==BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 && JACKK.y==BoxY[i]-80+5*Boxf[i]){
				boxl[i]=1;
			}
						
		}
		for(j=0;j<t1;j++){
			if(BoxX[j]+5*Boxr[j]-5*Boxl[j]>BARREL.x-80 && BoxX[j]+5*Boxr[j]-5*Boxl[j]<BARREL.x+60 && BoxY[j]+5*Boxf[j]==BARREL.y+60){		

				boxl[j]=0;
			}			
	
	
		}
		
		for(j=0;j<t1;j++){
			for(i=0;i<t2;i++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]==grassX[i]+grassNum[i]*60 && BoxY[j]+5*Boxf[j]-60==grassY[i]){		

					boxl[j]=0;
				}		
			}	
		
	
		}
		
		for(j=0;j<t1;j++){
			for(i=0;i<t3;i++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]==DoorX[i]+20 && BoxY[j]+5*Boxf[j]==DoorY[i] && doorclose[i]<320){		

					boxl[j]=0;
				}		
			}	
		
	
		}
		
		for(j=0;j<t1;j++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]==BARREL.x+60 && BoxY[j]+5*Boxf[j]==BARREL.y+60){		

					boxl[j]=0;
				}		
		}
		
		
		for(i=0;i<t1;i++){
			if(boxl[i]==1){
				return i+1;
			}
		}
		return 0;
	
	}

int BoxFallValid(int t1,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[], int grassX[],int grassY[],int grassNum[],int t2){
		
		for(i=0;i<t1;i++){
			boxf[i]=1;
		}
		for(j=0;j<t1;j++){
			for(i=0;i<t2;i++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]+80>grassX[i] && BoxX[j]+5*Boxr[j]-5*Boxl[j]<grassX[i]+60*grassNum[i] && BoxY[j]+5*Boxf[j]==grassY[i]){		

					boxf[j]=0;
				}		
			}	
		
	
		}
		for(j=0;j<t1;j++){
			for(i=0;i<t1;i++){
				if(BoxX[j]+5*Boxr[j]-5*Boxl[j]>BoxX[i]+5*Boxr[i]-5*Boxl[i]-80 && BoxX[j]+5*Boxr[j]-5*Boxl[j]<BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 && BoxY[j]+5*Boxf[j]==BoxY[i]+5*Boxf[i]-80){		

					boxf[j]=0;
				}		
			}	
		
	
		}
		
		for(j=0;j<t1;j++){
			if(BoxX[j]+5*Boxr[j]-5*Boxl[j]>BARREL.x-80 && BoxX[j]+5*Boxr[j]-5*Boxl[j]<BARREL.x+60 && BoxY[j]+5*Boxf[j]==BARREL.y+60){		

				boxf[j]=0;
			}			
	
	
		}
		
		for(i=0;i<t1;i++){
			if(boxf[i]==1){
				return i+1;
			}
		}
		return 0;
	}	
		
	
void BARL(int BarX,int BarY,int barr,int barl,int barf){
		
		if(rollr==1){
			rota=rota+5;
		}
		if(rolll==1){
			rota=rota-5;
		}
		
		SDL_QueryTexture(Barrel,NULL,NULL,&BARREL.w,&BARREL.h);
		BARREL.h=60;
		BARREL.w=60;
		
		
		BARREL.x=BarX+2.5*barr-2.5*barl;
		BARREL.y=BarY-60+5*barf;
		SDL_RenderCopyEx(rend,Barrel,NULL,&BARREL,rota,NULL,SDL_FLIP_NONE);
	}
	
int BarRightValid(int grassX[],int grassY[],int grassNum[],int t1,int DoorX[],int DoorY[],int t2,int t3,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[]){
		int p=0;
		if(JACKK.y+80==BARREL.y+60 && JACKK.x+50<=BARREL.x+10 && JACKK.x+50>=BARREL.x){
		
			p=1;
		
		}
				
		return p;

	}	
	
int BarLeftValid(int grassX[],int grassY[],int grassNum[],int t1,int DoorX[],int DoorY[],int t2,int t3,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[]){
		int p=0;
		if(JACKK.y+80==BARREL.y+60 && JACKK.x+10<=BARREL.x+60 && JACKK.x+10>=BARREL.x+50){
		
			p=1;
		
		}
		return p;

	}	
	
int BarFallValid(int grassX[],int grassY[],int grassNum[],int t,int t1,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[]){
		int p=1;
		for(i=0;i<t;i++){
				if(BARREL.x>grassX[i]-60 && BARREL.x<grassX[i]+60*grassNum[i] && BARREL.y+60==grassY[i]){		

					p=0;
				}		
			}
		for(i=0;i<t1;i++){
				if(BARREL.x>BoxX[i]+5*Boxr[i]-5*Boxl[i]-60 && BARREL.x<BoxX[i]+5*Boxr[i]-5*Boxl[i]+80 && BARREL.y+60==BoxY[i]+5*Boxf[i]-80){		

					p=0;
				}		
			}
		
			
		return p;

	}	

int BarTerminate(int t1,int BoxX[],int BoxY[],int Boxr[],int Boxl[],int Boxf[],int t2,int grassX[],int grassY[],int grassNum[],int t3,int DoorX[],int DoorY[],int barrierX[],int barrierY[],int t4){
		int p=0;
		for(j=0;j<t1;j++){
			if((BARREL.x+60==BoxX[j]+5*Boxr[j]-5*Boxl[j] || BARREL.x==BoxX[j]+5*Boxr[j]-5*Boxl[j]+80) && (BARREL.y+60>BoxY[j]-80+5*Boxf[j] && BARREL.y+60<=BoxY[j]+5*Boxf[j])){
				fullterm=1;
				p=1;
			}
		}
		for(j=0;j<t2;j++){
			if((BARREL.x+60==grassX[j] || BARREL.x==grassX[j]+grassNum[j]*60) && (BARREL.y+60>grassY[j] && BARREL.y-60<grassY[j])){
				fullterm=1;
				p=1;
			}
		}
		for(i=0;i<t3;i++){
				if(((BARREL.x+60==DoorX[i] && BARREL.y+60==DoorY[i])||(BARREL.x==DoorX[i]+20 && BARREL.y+60==DoorY[i]))&& doorclose[i]<320){	
					p=1;
				}		
			}
		if( JACKK.x+10<=BARREL.x+60 && JACKK.x+10>=BARREL.x+55 && BARREL.y+60>=JACKK.y+80 && BARREL.y<JACKK.y+80 && rollr==1){
					rollr=0;
					p=1;
				}	
		if(JACKK.x+50<=BARREL.x+5 && JACKK.x+50>=BARREL.x && BARREL.y+60>=JACKK.y+80 && BARREL.y<JACKK.y+80 && rolll==1 ){
					rolll=0;	
					p=1;
				}
		
		for(i=0;i<t4;i++){	
		if((BARREL.x>=JACKK.x+40 && BARREL.x<=JACKK.x+50 && (BARREL.x+60>=barrierX[i] && BARREL.x+60<=barrierX[i]+10 ) && BARREL.y+60==barrierY[i] && BARREL.y+60==JACKK.y+80) || (BARREL.x+60>=JACKK.x+10 && BARREL.x+40<=JACKK.x && (BARREL.x<=barrierX[i]+20 && BARREL.x>=barrierX[i]+10) && BARREL.y+60==barrierY[i] && BARREL.y+60==JACKK.y+80)){
			fullterm=1;
			p=1;
		}
		}
		if(p==1){
			rolll=0;
			rollr=0;
		}					

		return p;

}	
void Barrier(int barrierX[],int barrierY[],int t){
		
		
		SDL_QueryTexture(Ladder,NULL,NULL,&BARRIER.w,&BARRIER.h);
		BARRIER.h=60;
		BARRIER.w=20;
		
		for(i=0;i<t;i++){
			BARRIER.x=barrierX[i];
			BARRIER.y=barrierY[i]-60;
		
			SDL_RenderCopy(rend,Ladder,NULL,&BARRIER);
		}




}	

void BarReverse(int barrierX[],int barrierY[],int t){
	int p=0;
	for(i=0;i<t;i++){
		if((((BARREL.x+60>=barrierX[i] && BARREL.x+60<=barrierX[i]+5) && rollr==1) || ((BARREL.x<=barrierX[i]+20 && BARREL.x>=barrierX[i]+15) && rolll==1)) && BARREL.y+60==barrierY[i]){
			p=1;
		}
	}
	
	if(p==1){
		int q=rollr;
		rollr=rolll;
		rolll=q;
	}
	


}

void UI_restart(){

	SDL_Rect PLAYMENUBUTTON;
	SDL_QueryTexture(Restart,NULL,NULL,&PLAYMENUBUTTON.w,&PLAYMENUBUTTON.h);
	PLAYMENUBUTTON.h=50;
	PLAYMENUBUTTON.w=50;
	PLAYMENUBUTTON.x=1800;
	PLAYMENUBUTTON.y=50;
	
	SDL_RenderCopy(rend,Restart,NULL,&PLAYMENUBUTTON);
	
	PLAYMENUBUTTON.x=1700;
	PLAYMENUBUTTON.y=50;
	
	SDL_RenderCopy(rend,Home,NULL,&PLAYMENUBUTTON);

}	
void LevelUP(){
	if(JACKK.x+20==PROLL.x && JACKK.y+80==PROLL.y+60){
		levelup=1;
	}
		SDL_Rect VICTORY;
		SDL_QueryTexture(Vic,NULL,NULL,&VICTORY.w,&VICTORY.h);
		VICTORY.x=980-300;
		VICTORY.y=540-200;
		VICTORY.h=550;
		VICTORY.w=600;
	if(levelup==1){	
	SDL_RenderCopy(rend,Vic,NULL,&VICTORY);
	}

}
void background(){
	SDL_Rect BGG;
	SDL_QueryTexture(Bgg,NULL,NULL,&BGG.w,&BGG.h);
	BGG.x=-540;
	BGG.y=0;
	BGG.h=2*1080;
	BGG.w=2*1920;
	
	SDL_RenderCopy(rend,Bgg,NULL,&BGG);
}


	
