
#include<stdio.h>
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<SDL2/SDL_timer.h>
#include<GL/gl.h>
#include<math.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>	
#include<bits/stdc++.h>
#include<time.h>
#include"../Gamefunc/gamefunc.h"
	
	extern int i,j,k;
	extern int doorclose[4];
	extern int boxr[4],boxl[4],boxf[4];
	extern int barterm;
	extern int rev;
	extern int rollr,rolll;
	extern int right,left,up,down;
	extern int boxright[4],boxleft[4],boxfall[4];
	extern int barright,barleft,barfall;
	extern int RED,GREEN,BLUE,YELLOW;
	extern int fall;
	extern int oneinc;
	
	extern SDL_Window* win;
	extern SDL_Renderer* rend;
	
	extern SDL_Surface* num;
	extern SDL_Texture* one;
	extern SDL_Texture* two;
	extern SDL_Texture* three;
	extern SDL_Texture* four;
	extern SDL_Texture* five;
	extern SDL_Texture* six;
	extern SDL_Texture* seven;
	extern SDL_Texture* eight;
	extern SDL_Texture* nine;
	
	
	extern SDL_Surface* grassfield;
	extern SDL_Texture* Grassfield;
	
	extern SDL_Surface* door1;
	extern SDL_Texture* DoorR;
	extern SDL_Surface* door2;
	extern SDL_Texture* DoorG;
	extern SDL_Surface* door3;
	extern SDL_Texture* DoorB;
	extern SDL_Surface* door4;
	extern SDL_Texture* DoorYe;
	
	extern SDL_Surface* ladder1;
	extern SDL_Surface* ladder2;
	extern SDL_Texture* Ladder;
	extern SDL_Texture* Ladder1;
	
	extern SDL_Surface* swtch1;
	extern SDL_Surface* swtch2;
	extern SDL_Surface* swtch3;
	extern SDL_Surface* swtch4;
	extern SDL_Surface* swtchoff1;
	extern SDL_Surface* swtchoff2;
	extern SDL_Surface* swtchoff3;
	extern SDL_Surface* swtchoff4;
	extern SDL_Texture* SwitchR;
	extern SDL_Texture* SwitchB;
	extern SDL_Texture* SwitchG;
	extern SDL_Texture* SwitchY;
	extern SDL_Texture* SwitchRoff;
	extern SDL_Texture* SwitchGoff;
	extern SDL_Texture* SwitchBoff;
	extern SDL_Texture* SwitchYoff;
	
	extern SDL_Surface* jack;
	extern SDL_Texture* Jackrest;
	extern SDL_Texture* Jackwalk1;
	extern SDL_Texture* Jackwalk2;
	extern SDL_Texture* Jackwalk3;
	extern SDL_Texture* Jackwalk4;
	extern SDL_Texture* Jackwalk5;
	extern SDL_Texture* Jackwalk6;
	extern SDL_Texture* Jackwalk7;
	extern SDL_Texture* Jackwalk8;
	extern SDL_Texture* Jackclimb1;
	extern SDL_Texture* Jackclimb2;
	extern SDL_Texture* Jackdrag;
	
	extern SDL_Surface* paper;
	extern SDL_Texture* PRoll;
		
	extern SDL_Surface* box;
	extern SDL_Texture* BoxS;
	extern SDL_Surface* barrel;
	extern SDL_Texture* Barrel;
	extern SDL_Rect JACKK;
	extern SDL_Rect BOXX;
	extern SDL_Rect BARREL;
	extern SDL_Rect BARRIER;		
	extern SDL_Event event;
	extern SDL_Event e;
	extern int savex,savey;
	extern int ui1;
	extern int home;
	extern int levelup;
	extern int level;
	extern int EventDiffChecker;
	extern int rrr;
	extern int lll;
	
void level_4(int *barx, int *bary){
		SDL_RenderClear(rend);
		background();
// Grid--------------------------------------------------
			if(savex==0){
				savex=*barx;
			}
			if(savey==0){
				savey=*bary;
			}
// Grass(coordinate UPPER LEFT)-------------------------------------------------

			int GrassCountlv4 = 6;
			int GrassXlv4[] = {360, 480, 720, 900, 840, 1200};
			int GrassYlv4[] = {840, 540, 420, 600, 240, 420};
			int GrassNumlv4[] = {5, 4, 4, 6, 8, 8};
			Grass(GrassCountlv4, GrassXlv4, GrassYlv4, GrassNumlv4);

// Ladder(coordinate LOWER LEFT)------------------------------------------------

			int LadderCountlv4 = 6;
			int LadderXlv4[] = {420, 660, 780, 1140, 960, 1320};
			int LadderYlv4[] = {840, 540, 420, 600, 600, 420};
			int LadderNumlv4[] = {5, 2, 3, 3, 3, 3};
			Lad(LadderCountlv4, LadderXlv4, LadderYlv4, LadderNumlv4);

// switch------------------------------------------------

			int SwitchCount = 4;
			int SwitchConlv4[] = {0, 0, 0, 0};
			int SwitchX[] = {600, 1240, 1060, 0};
			int SwitchY[] = {840, 420, 600, 0};
			int SwitchColour[] = {RED, GREEN, BLUE, YELLOW};
          		int BoxCountlv4 = 2;
			int BoxXlv4[] = {840,420};
			int BoxYlv4[] = {420,840};


			for (i = 0; i < SwitchCount; i++)
			{
				SwitchConlv4[i] = SwitchCondition(SwitchX, SwitchY, i,BoxXlv4, BoxYlv4, boxright, boxleft, boxfall, BoxCountlv4);
			}

			Switch(SwitchCount, SwitchX, SwitchY, SwitchColour, SwitchConlv4);

			int DoorCount = 4;
			int DoorConlv4[] = {0, 0, 0, 0};
			int DoorX[] = {1200, 920, 1560, 0};
			int DoorY[] = {420, 420, 420, 0};
			int DoorColour[] = {RED, GREEN, BLUE, YELLOW};
			int barrierCount=0;
			int barrierX[]={0};
			int barrierY[]={0};
			
			Door(DoorCount, DoorX, DoorY, DoorColour, SwitchConlv4);

            Box(BoxXlv4, BoxYlv4, BoxCountlv4, boxright, boxleft, boxfall);

			int rvalid = RightValid(GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4,BoxCountlv4,BoxXlv4, BoxYlv4 , boxright, boxleft, boxfall, DoorCount, DoorX, DoorY, LadderXlv4, LadderYlv4, LadderNumlv4,barrierCount,barrierX,barrierY);
			int lvalid = LeftValid(GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4,BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall, DoorCount, DoorX, DoorY, LadderXlv4, LadderYlv4, LadderNumlv4,barrierCount,barrierX,barrierY);
			int dvalid = DownValid(LadderXlv4, LadderYlv4, LadderNumlv4, LadderCountlv4, BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall);
			int uvalid = UpValid(LadderXlv4, LadderYlv4, LadderNumlv4, LadderCountlv4,BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall);
           		int boxrvalid = BoxRightValid(BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall, GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4,DoorX,DoorY,DoorCount);
			int boxlvalid = BoxLeftValid(BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall, GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4,DoorX,DoorY,DoorCount);

			int barrvalid = BarRightValid(GrassXlv4,GrassYlv4,GrassNumlv4,GrassCountlv4,DoorX,DoorY,DoorCount,BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall);
			int barlvalid = BarLeftValid(GrassXlv4,GrassYlv4,GrassNumlv4,GrassCountlv4,DoorX,DoorY,DoorCount,BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall);
			barterm = BarTerminate(BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall, GrassCountlv4, GrassXlv4, GrassYlv4, GrassNumlv4,DoorCount,DoorX,DoorY,barrierX,barrierY,barrierCount);
			BarReverse(barrierX,barrierY,barrierCount);
			if (barterm == 1)
			{
				*barx=*barx+2.5*barright-2.5*barleft;
				*bary=*bary+5*barfall;
				
				barright=0;
				barleft=0;
				barfall=0;
			}
			if(rollr==1 && barterm==0){
				barright=barright+1;
			}
			if(rolll==1 && barterm==0){
				barleft=barleft+1;
			}
			
			BARL(*barx,*bary, barright, barleft, barfall);


			if(oneinc!=0){
				oneinc--;
			
			}
			
			if(EventDiffChecker<5){
			EventDiffChecker++;
			printf("%d\n",EventDiffChecker);
			}
			else{
				rrr=0;
				lll=0;
			}
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			if(levelup==0){
				
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1 && oneinc==0){
					
					if(EventDiffChecker>3){
						rrr=1;
					}
					else if(EventDiffChecker<=3){
						rrr++;
					}
					EventDiffChecker=0;

					int boxpass=1,barrelpass=1;
					for(i=0;i<4;i++){
						if(BoxXlv4[i]+5*boxright[i]-5*boxleft[i]>=JACKK.x+50 && BoxXlv4[i]+5*boxright[i]-5*boxleft[i]<JACKK.x+50+60 && BoxYlv4[i]+5*boxfall[i]-80==JACKK.y){
							boxpass=0;
						}
					
					}
					
					if(BARREL.x>=JACKK.x+50 && BARREL.x<JACKK.x+50+60 && BARREL.y+60==JACKK.y+80){
						barrelpass=0;
					}
				
					for(i=0;i<LadderCountlv4;i++){
						if(boxpass==1 && barrelpass==1){
						if(JACKK.x+50>=LadderXlv4[i] && JACKK.x<LadderXlv4[i] && JACKK.y+80<=LadderYlv4[i] && JACKK.y+80>=LadderYlv4[i]-LadderNumlv4[i]*60){
							oneinc=15;
							right=right+(LadderXlv4[i]-JACKK.x)/5;
							break;
						}
						else if(JACKK.x==LadderXlv4[i] && JACKK.y+80<=LadderYlv4[i] && JACKK.y+80>=LadderYlv4[i]-LadderNumlv4[i]*60){
							oneinc=15;
							right=right+10;
							break;
						
						}
						}
					
					}
					if(oneinc==0){
						right++;
					}
					
					for(j=0;j<BoxCountlv4;j++){
						if(boxrvalid==j+1){
						
							boxright[j]++;
							
						}
					}
					if(barrvalid==1 && barterm==0){
						rollr=1;
						barright=barright+1;
					
					}	
				}
				else if (ev.key.keysym.sym == SDLK_LEFT && lvalid == 1 && oneinc==0){
					if(EventDiffChecker>3){
						lll=1;
					}
					else if(EventDiffChecker<=3){
						lll++;
					}
					
					EventDiffChecker=0;
					int boxpass=1,barrelpass=1;
					for(i=0;i<4;i++){
						if(BoxXlv4[i]+5*boxright[i]-5*boxleft[i]+80<=JACKK.x+10 && BoxXlv4[i]+5*boxright[i]-5*boxleft[i]+80>JACKK.x+10-60 && BoxYlv4[i]+5*boxfall[i]-80==JACKK.y){
							boxpass=0;
						}
					
					}
					
					if(BARREL.x+60<=JACKK.x+10 && BARREL.x+120>JACKK.x+10 && BARREL.y+60==JACKK.y+80){
						barrelpass=0;
					}
					
					for(i=0;i<LadderCountlv4;i++){
						if(boxpass==1 && barrelpass==1){
						if(JACKK.x+10<=LadderXlv4[i]+60 && JACKK.x>LadderXlv4[i] && JACKK.y+80<=LadderYlv4[i] && JACKK.y+80>=LadderYlv4[i]-LadderNumlv4[i]*60){
							oneinc=15;
							left=left+(JACKK.x-LadderXlv4[i])/5;
							break;
						}
						else if(JACKK.x==LadderXlv4[i] && JACKK.y+80<=LadderYlv4[i] && JACKK.y+80>=LadderYlv4[i]-LadderNumlv4[i]*60){
							oneinc=15;
							left=left+10;
							break;
						
						}
						}
					
					
					}
					if(oneinc==0){
						left++;
					}
					
					for(j=0;j<BoxCountlv4;j++){
						if(boxlvalid==j+1){
						
							boxleft[j]++;
						}
					}
					if(barlvalid==1 && barterm==0){
						rolll=1;
						barleft=barleft+1;
					
					}
				}
				else if (ev.key.keysym.sym == SDLK_UP && uvalid == 1)
				{
					up++;
				}
				else if (ev.key.keysym.sym == SDLK_DOWN && dvalid == 1)
				{
					down++;
				}
				else if(ev.type==SDL_MOUSEBUTTONDOWN){
					int x2,y2;
					int m2button= SDL_GetMouseState(&x2,&y2);
					if(x2>1800 && x2<1850 && y2<100 && y2>50 ){
					*barx=savex;
					*bary=savey;
					right=0;left=0;up=0;down=0;
					fall=-3;
					for(k=0;k<BoxCountlv4;k++){
						boxright[k]=0;
						boxleft[k]=0;
						boxfall[k]=-3;
					}
					for(k=0;k<DoorCount;k++){
						doorclose[k]=0;
					}
					barright=0;
					barleft=0;
					barfall=-3;
					rolll=0;rollr=0;
					}
					else if(x2>1700 && x2<1750 && y2<100 && y2>50 ){
						home=1;
						ui1=0;
						}
				}
	
			}
			else if(levelup==1){
				if(ev.type==SDL_MOUSEBUTTONDOWN){
					int x2,y2;
					int m2button= SDL_GetMouseState(&x2,&y2);
					if(x2>990 && x2<1050 && y2<790 && y2>740 ){
					*barx=savex;
					*bary=savey;
					right=0;left=0;up=0;down=0;
					fall=-3;
					for(k=0;k<BoxCountlv4;k++){
						boxright[k]=0;
						boxleft[k]=0;
						boxfall[k]=-3;
					}
					for(k=0;k<DoorCount;k++){
						doorclose[k]=0;
					}
					barright=0;
					barleft=0;
					barfall=-3;
					rolll=0;
					rollr=0;
					levelup=0;
					
					}
					else if(x2>890 && x2<940 && y2<790 && y2>740 ){
						right=0;left=0;up=0;down=0;
						home=1;
						levelup=0;
						ui1=0;
						}
					else if(x2>1120 && x2<1190 && y2<790 && y2>740 ){
						right=0;left=0;up=0;down=0;
						home=1;
						levelup=0;
						ui1=-1;
						level++;

					}
					else if(x2>780 && x2<840 && y2<790 && y2>740 ){
						right=0;left=0;up=0;down=0;
						home=1;
						levelup=0;
						ui1=3;
					
					}	
				}
			
			
			
			
			}
			}
			UI_restart();
			int fvalid;
			Scroll(1620, 420);
			Jack(360, 840, fall, right, left, up, down,uvalid,dvalid,fvalid);

			fvalid = FallValid(GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4, LadderXlv4, LadderYlv4, LadderNumlv4, LadderCountlv4, BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall,barrierX,barrierY,barrierCount,DoorX,DoorY,DoorCount);
			if (fvalid == 1)
			{
				fall++;
			}

          		int barfvalid = BarFallValid(GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4,BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall);
			if (barfvalid == 1)
			{
				barfall++;
			}

			int boxfvalid = BoxFallValid(BoxCountlv4, BoxXlv4, BoxYlv4, boxright, boxleft, boxfall, GrassXlv4, GrassYlv4, GrassNumlv4, GrassCountlv4);
			for (k = 0; k < BoxCountlv4; k++)
			{
				if (boxfvalid == k + 1)
				{BoxCountlv4, BoxXlv4, BoxYlv4,BoxCountlv4, BoxXlv4, BoxYlv4,
					boxfall[k]++;
				}
			}

			LevelUP();
			SDL_RenderPresent(rend);
		

}
