
#include<stdio.h>
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<SDL2/SDL_timer.h>
#include<GL/gl.h>
#include<math.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>	
#include<bits/stdc++.h>
#include<time.h>
#include"../Gamefunc/gamefunc.h"
	
	extern int i,j,k;
	extern int doorclose[4];
	extern int boxr[4],boxl[4],boxf[4];
	extern int barterm;
	extern int rev;
	extern int rollr,rolll;
	extern int right,left,up,down;
	extern int boxright[4],boxleft[4],boxfall[4];
	extern int barright,barleft,barfall;
	extern int RED,GREEN,BLUE,YELLOW;
	extern int fall;
	extern int oneinc;
	
	extern SDL_Window* win;
	extern SDL_Renderer* rend;
	
	extern SDL_Surface* num;
	extern SDL_Texture* one;
	extern SDL_Texture* two;
	extern SDL_Texture* three;
	extern SDL_Texture* four;
	extern SDL_Texture* five;
	extern SDL_Texture* six;
	extern SDL_Texture* seven;
	extern SDL_Texture* eight;
	extern SDL_Texture* nine;
	
	
	extern SDL_Surface* grassfield;
	extern SDL_Texture* Grassfield;
	
	extern SDL_Surface* door1;
	extern SDL_Texture* DoorR;
	extern SDL_Surface* door2;
	extern SDL_Texture* DoorG;
	extern SDL_Surface* door3;
	extern SDL_Texture* DoorB;
	extern SDL_Surface* door4;
	extern SDL_Texture* DoorYe;
	
	extern SDL_Surface* ladder1;
	extern SDL_Surface* ladder2;
	extern SDL_Texture* Ladder;
	extern SDL_Texture* Ladder1;
	
	extern SDL_Surface* swtch1;
	extern SDL_Surface* swtch2;
	extern SDL_Surface* swtch3;
	extern SDL_Surface* swtch4;
	extern SDL_Surface* swtchoff1;
	extern SDL_Surface* swtchoff2;
	extern SDL_Surface* swtchoff3;
	extern SDL_Surface* swtchoff4;
	extern SDL_Texture* SwitchR;
	extern SDL_Texture* SwitchB;
	extern SDL_Texture* SwitchG;
	extern SDL_Texture* SwitchY;
	extern SDL_Texture* SwitchRoff;
	extern SDL_Texture* SwitchGoff;
	extern SDL_Texture* SwitchBoff;
	extern SDL_Texture* SwitchYoff;
	
	extern SDL_Surface* jack;
	extern SDL_Texture* Jackrest;
	extern SDL_Texture* Jackwalk1;
	extern SDL_Texture* Jackwalk2;
	extern SDL_Texture* Jackwalk3;
	extern SDL_Texture* Jackwalk4;
	extern SDL_Texture* Jackwalk5;
	extern SDL_Texture* Jackwalk6;
	extern SDL_Texture* Jackwalk7;
	extern SDL_Texture* Jackwalk8;
	extern SDL_Texture* Jackclimb1;
	extern SDL_Texture* Jackclimb2;
	extern SDL_Texture* Jackdrag;
	
	extern SDL_Surface* paper;
	extern SDL_Texture* PRoll;
		
	extern SDL_Surface* box;
	extern SDL_Texture* BoxS;
	extern SDL_Surface* barrel;
	extern SDL_Texture* Barrel;
	extern SDL_Rect JACKK;
	extern SDL_Rect BOXX;
	extern SDL_Rect BARREL;
	extern SDL_Rect BARRIER;		
	extern SDL_Event event;
	extern SDL_Event e;
	extern int savex,savey;
	extern int ui1;
	extern int home;
	extern int levelup;
	extern int level;
	extern int EventDiffChecker;
	extern int rrr;
	extern int lll;
	
void level_8(int *barx, int *bary){
		
			SDL_RenderClear(rend);
//Grid--------------------------------------------------			
			if(savex==0){
				savex=*barx;
			}
			if(savey==0){
				savey=*bary;
			}
//Grass(coordinate UPPER LEFT)-------------------------------------------------			
			int GrassCountlv8=7;
			int GrassXlv8[]={600,360,720,780,960,840,1020};
			int GrassYlv8[]={480,840,840,300,300,480,660};
			int GrassNumlv8[]={4,5,8,2,7,10,9};
			Grass(GrassCountlv8,GrassXlv8,GrassYlv8,GrassNumlv8);
//Ladder(coordinate LOWER LEFT)------------------------------------------------			
			int LadderCountlv8=5;
			int LadderXlv8[]={540,720,900,1380,1440};
			int LadderYlv8[]={840,480,480,480,660};
			int LadderNumlv8[]={6,3,3,3,3};
			Lad(LadderCountlv8,LadderXlv8,LadderYlv8,LadderNumlv8);
			
//switch------------------------------------------------		
			
			int SwitchCount=4;
			int SwitchConlv8[]={0,0,0,0};
			int SwitchX[]={600,1260,1200,1240};
			int SwitchY[]={840,300,660,660};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			int BoxCountlv8=3;
			int BoxXlv8[]={460,1000,1000};
			int BoxYlv8[]={840,300,480};
			
			for(i=0;i<SwitchCount;i++){	
				SwitchConlv8[i]=SwitchCondition(SwitchX,SwitchY,i,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,BoxCountlv8);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConlv8);

			int DoorCount=4;
			int DoorConlv8[]={0,0,0,0};
			int DoorX[]={1320,970,1080,1080};
			int DoorY[]={300,480,660,840};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};

			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConlv8);
			
			Box(BoxXlv8,BoxYlv8,BoxCountlv8,boxright,boxleft,boxfall);
			
			int barrierCount=0;
			int barrierX[]={0};
			int barrierY[]={0};
			
			int rvalid=RightValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,DoorCount,DoorX,DoorY,LadderXlv8,LadderYlv8,LadderNumlv8,barrierCount,barrierX,barrierY);
			int lvalid=LeftValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,DoorCount,DoorX,DoorY,LadderXlv8,LadderYlv8,LadderNumlv8,barrierCount,barrierX,barrierY);
			int dvalid=DownValid(LadderXlv8,LadderYlv8,LadderNumlv8,LadderCountlv8,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall);
			int uvalid=UpValid(LadderXlv8,LadderYlv8,LadderNumlv8,LadderCountlv8,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall);
			int boxrvalid=BoxRightValid(BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,DoorX,DoorY,DoorCount);
			int boxlvalid=BoxLeftValid(BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,DoorX,DoorY,DoorCount);
			int barrvalid=BarRightValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,DoorX,DoorY,DoorCount,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall);
			int barlvalid=BarLeftValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,DoorX,DoorY,DoorCount,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall);
			
			barterm=BarTerminate(BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,GrassCountlv8,GrassXlv8,GrassYlv8,GrassNumlv8,DoorCount,DoorX,DoorY,barrierX,barrierY,barrierCount);
			BarReverse(barrierX,barrierY,barrierCount);
			if (barterm == 1)
			{
				*barx=*barx+2.5*barright-2.5*barleft;
				*bary=*bary+5*barfall;
				
				barright=0;
				barleft=0;
				barfall=0;				
			}

			if(rollr==1 && barterm==0){
				barright=barright+1;
			}
			if(rolll==1 && barterm==0){
				barleft=barleft+1;
			}
			

			if(oneinc!=0){
				oneinc--;
			
			}
			
			if(EventDiffChecker<5){
			EventDiffChecker++;
			printf("%d\n",EventDiffChecker);
			}
			else{
				rrr=0;
				lll=0;
			}
			SDL_Event ev;
			if(SDL_PollEvent(&ev)){
			if(levelup==0){
				
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1 && oneinc==0){
					
					if(EventDiffChecker>3){
						rrr=1;
					}
					else if(EventDiffChecker<=3){
						rrr++;
					}
					EventDiffChecker=0;
					int boxpass=1,barrelpass=1;
					for(i=0;i<4;i++){
						if(BoxXlv8[i]+5*boxright[i]-5*boxleft[i]>=JACKK.x+50 && BoxXlv8[i]+5*boxright[i]-5*boxleft[i]<JACKK.x+50+60 && BoxYlv8[i]+5*boxfall[i]-80==JACKK.y){
							boxpass=0;
						}
					
					}
					
					if(BARREL.x>=JACKK.x+50 && BARREL.x<JACKK.x+50+60 && BARREL.y+60==JACKK.y+80){
						barrelpass=0;
					}
				
					for(i=0;i<LadderCountlv8;i++){
						if(boxpass==1 && barrelpass==1){
						if(JACKK.x+50>=LadderXlv8[i] && JACKK.x<LadderXlv8[i] && JACKK.y+80<=LadderYlv8[i] && JACKK.y+80>=LadderYlv8[i]-LadderNumlv8[i]*60){
							oneinc=15;
							right=right+(LadderXlv8[i]-JACKK.x)/5;
							break;
						}
						else if(JACKK.x==LadderXlv8[i] && JACKK.y+80<=LadderYlv8[i] && JACKK.y+80>=LadderYlv8[i]-LadderNumlv8[i]*60){
							oneinc=15;
							right=right+10;
							break;
						
						}
						}
					
					}
					if(oneinc==0){
						right++;
					}
					
					for(j=0;j<BoxCountlv8;j++){
						if(boxrvalid==j+1){
						
							boxright[j]++;
							
						}
					}
					if(barrvalid==1 && barterm==0){
						rollr=1;
						barright=barright+1;
					
					}	
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1 && oneinc==0){
					if(EventDiffChecker>3){
						lll=1;
					}
					else if(EventDiffChecker<=3){
						lll++;
					}
					
					EventDiffChecker=0;
					int boxpass=1,barrelpass=1;
					for(i=0;i<4;i++){
						if(BoxXlv8[i]+5*boxright[i]-5*boxleft[i]+80<=JACKK.x+10 && BoxXlv8[i]+5*boxright[i]-5*boxleft[i]+80>JACKK.x+10-60 && BoxYlv8[i]+5*boxfall[i]-80==JACKK.y){
							boxpass=0;
						}
					
					}
					
					if(BARREL.x+60<=JACKK.x+10 && BARREL.x+120>JACKK.x+10 && BARREL.y+60==JACKK.y+80){
						barrelpass=0;
					}
					
					for(i=0;i<LadderCountlv8;i++){
						if(boxpass==1 && barrelpass==1){
						if(JACKK.x+10<=LadderXlv8[i]+60 && JACKK.x>LadderXlv8[i] && JACKK.y+80<=LadderYlv8[i] && JACKK.y+80>=LadderYlv8[i]-LadderNumlv8[i]*60){
							oneinc=15;
							left=left+(JACKK.x-LadderXlv8[i])/5;
							break;
						}
						else if(JACKK.x==LadderXlv8[i] && JACKK.y+80<=LadderYlv8[i] && JACKK.y+80>=LadderYlv8[i]-LadderNumlv8[i]*60){
							oneinc=15;
							left=left+10;
							break;
						
						}
						}
					
					
					}
					if(oneinc==0){
						left++;
					}
					
					for(j=0;j<BoxCountlv8;j++){
						if(boxlvalid==j+1){
						
							boxleft[j]++;
						}
					}
					if(barlvalid==1 && barterm==0){
						rolll=1;
						barleft=barleft+1;
					
					}
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
				else if(ev.type==SDL_MOUSEBUTTONDOWN){
					int x2,y2;
					int m2button= SDL_GetMouseState(&x2,&y2);
					if(x2>1800 && x2<1850 && y2<100 && y2>50 ){
					*barx=savex;
					*bary=savey;
					right=0;left=0;up=0;down=0;
					fall=-3;
					for(k=0;k<BoxCountlv8;k++){
						boxright[k]=0;
						boxleft[k]=0;
						boxfall[k]=-3;
					}
					for(k=0;k<DoorCount;k++){
						doorclose[k]=0;
					}
					barright=0;
					barleft=0;
					barfall=-3;
					rolll=0;rollr=0;
					}
					else if(x2>1700 && x2<1750 && y2<100 && y2>50 ){
						home=1;
						ui1=0;
						}
				}
	
			}
			else if(levelup==1){
				if(ev.type==SDL_MOUSEBUTTONDOWN){
					int x2,y2;
					int m2button= SDL_GetMouseState(&x2,&y2);
					if(x2>990 && x2<1050 && y2<790 && y2>740 ){
					*barx=savex;
					*bary=savey;
					right=0;left=0;up=0;down=0;
					fall=-3;
					for(k=0;k<BoxCountlv8;k++){
						boxright[k]=0;
						boxleft[k]=0;
						boxfall[k]=-3;
					}
					for(k=0;k<DoorCount;k++){
						doorclose[k]=0;
					}
					barright=0;
					barleft=0;
					barfall=-3;
					rolll=0;
					rollr=0;
					levelup=0;
					
					}
					else if(x2>890 && x2<940 && y2<790 && y2>740 ){
						right=0;left=0;up=0;down=0;
						home=1;
						levelup=0;
						ui1=0;
						}
					else if(x2>1120 && x2<1190 && y2<790 && y2>740 ){
						right=0;left=0;up=0;down=0;
						home=1;
						levelup=0;
						ui1=-1;
						level++;

					}
					else if(x2>780 && x2<840 && y2<790 && y2>740 ){
						right=0;left=0;up=0;down=0;
						home=1;
						levelup=0;
						ui1=3;
					
					}	
				}
			
			
			
			
			}
			}
			UI_restart();
			int fvalid;
			Scroll(1140,840);
			Jack(840,300,fall,right,left,up,down,uvalid,dvalid,fvalid);
			
			 fvalid=FallValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,LadderXlv8,LadderYlv8,LadderNumlv8,LadderCountlv8,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,barrierX,barrierY,barrierCount,DoorX,DoorY,DoorCount);
			if(fvalid==1){
				fall++;
			}
			
			int barfvalid=BarFallValid(GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8,BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall);
			if(barfvalid==1){
				barfall++;
			}
			
			int boxfvalid=BoxFallValid(BoxCountlv8,BoxXlv8,BoxYlv8,boxright,boxleft,boxfall,GrassXlv8,GrassYlv8,GrassNumlv8,GrassCountlv8);
			for(k=0;k<BoxCountlv8;k++){
					if(boxfvalid==k+1){
						boxfall[k]++;
							
						}
					}
			LevelUP();
			SDL_RenderPresent(rend);
		
		

}
