#include<stdio.h>
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<SDL2/SDL_timer.h>
#include<GL/gl.h>
#include<math.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>	
#include<bits/stdc++.h>
#include<time.h>
#include"Gamefunc/gamefunc.h"
#include"Level/level.h"

//Global declaration
	
	extern int RED,GREEN,BLUE,YELLOW;
	int level=1;
	extern int i,j,k;
	extern int barterm;
	extern int rev;
	extern int rollr,rolll;
	extern int doorclose[4];
	
	extern SDL_Window* win;
	extern SDL_Renderer* rend;
	
	extern SDL_Surface* num;
	extern SDL_Texture* one;
	extern SDL_Texture* two;
	extern SDL_Texture* three;
	extern SDL_Texture* four;
	extern SDL_Texture* five;
	extern SDL_Texture* six;
	extern SDL_Texture* seven;
	extern SDL_Texture* eight;
	extern SDL_Texture* nine;
	
	
	extern SDL_Surface* grassfield;
	extern SDL_Texture* Grassfield;
	
	extern SDL_Surface* door1;
	extern SDL_Texture* DoorR;
	extern SDL_Surface* door2;
	extern SDL_Texture* DoorG;
	extern SDL_Surface* door3;
	extern SDL_Texture* DoorB;
	extern SDL_Surface* door4;
	extern SDL_Texture* DoorYe;
	
	extern SDL_Surface* ladder1;
	extern SDL_Surface* ladder2;
	extern SDL_Texture* Ladder;
	extern SDL_Texture* Ladder1;
	
	extern SDL_Surface* swtch1;
	extern SDL_Surface* swtch2;
	extern SDL_Surface* swtch3;
	extern SDL_Surface* swtch4;
	extern SDL_Surface* swtchoff1;
	extern SDL_Surface* swtchoff2;
	extern SDL_Surface* swtchoff3;
	extern SDL_Surface* swtchoff4;
	extern SDL_Texture* SwitchR;
	extern SDL_Texture* SwitchB;
	extern SDL_Texture* SwitchG;
	extern SDL_Texture* SwitchY;
	extern SDL_Texture* SwitchRoff;
	extern SDL_Texture* SwitchGoff;
	extern SDL_Texture* SwitchBoff;
	extern SDL_Texture* SwitchYoff;
	
	extern SDL_Surface* jack;
	extern SDL_Texture* Jackrest;
	extern SDL_Texture* Jackwalk1;
	extern SDL_Texture* Jackwalk2;
	extern SDL_Texture* Jackwalk3;
	extern SDL_Texture* Jackwalk4;
	extern SDL_Texture* Jackwalk5;
	extern SDL_Texture* Jackwalk6;
	extern SDL_Texture* Jackwalk7;
	extern SDL_Texture* Jackwalk8;
	extern SDL_Texture* Jackclimb1;
	extern SDL_Texture* Jackclimb2;
	extern SDL_Texture* Jackdrag;
	
	extern SDL_Surface* paper;
	extern SDL_Texture* PRoll;
		
	extern SDL_Surface* box;
	extern SDL_Texture* BoxS;
	extern SDL_Surface* barrel;
	extern SDL_Texture* Barrel;
	
	extern SDL_Surface* restart;
	extern SDL_Texture* Restart;
	extern SDL_Surface* hhome;
	extern SDL_Texture* Home;
	extern int home;
	extern int savex,savey;
	extern SDL_Rect JACKK;
	extern SDL_Rect BARREL;
	extern SDL_Surface* bggg;
	extern SDL_Texture* Bgg;
	extern SDL_Event event;
	extern SDL_Event e;
	extern SDL_Surface* vic;
	extern SDL_Texture* Vic;
	int ui1=0;
	extern int fullterm;
	
//END


int main(int agr, char* args[]){

	
	if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_AUDIO)!=0){
		printf("Video or timer error:%s\n",SDL_GetError());
	}
	if(!(IMG_Init(IMG_INIT_PNG))){
		printf("Image error:%s\n",IMG_GetError());
	}
	if(!(IMG_Init(IMG_INIT_JPG))){
		printf("Image error:%s\n",IMG_GetError());
	}
	printf("Initialization Complete");
	
	if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048)<0)
	{
	printf("Error");
	}	
	if(TTF_Init()<0){
		printf("ERROR");
	}
	
	int ScreenHeight=1080;
	int ScreenWidth=1920;
	int zerox=960;
	int zeroy=540;
	
	
	
	
//###################################################################################################
//function
	
		
		
//##############################################################################################
	
//Window loading

	SDL_Window* winload = SDL_CreateWindow("Dr Maddy",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, 500 , 400 ,SDL_WINDOW_BORDERLESS);
	
	
	Uint32 render_flagsload= SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;	
	SDL_Renderer* rendload= SDL_CreateRenderer(winload,-1,render_flagsload);
	SDL_Surface* Sur_load =IMG_Load("Texture/Loading/output-onlinepngtools(3).png");
	SDL_Texture* Tex_load =SDL_CreateTextureFromSurface(rendload,Sur_load);
	SDL_FreeSurface(Sur_load);

	SDL_Rect load;
	
	SDL_QueryTexture(Tex_load,NULL,NULL,&load.h,&load.w);
	load.h=400;
	load.w=500;
	load.x=0;
	load.y=0;
	
	SDL_RenderClear(rendload);
	
	
	SDL_RenderCopy(rendload, Tex_load, NULL,&load); 
	SDL_RenderPresent(rendload);
	SDL_Delay(2000);	
	
	Sur_load =IMG_Load("Texture/Loading/Loading motion.png");
	SDL_Texture* Tex_load3 =SDL_CreateTextureFromSurface(rendload,Sur_load);
	SDL_FreeSurface(Sur_load);
	
	SDL_Rect loc_2;
	SDL_QueryTexture(Tex_load3,NULL,NULL,&loc_2.w,&loc_2.h);
	loc_2.h=65;
	loc_2.w=65;
	loc_2.x=300;
	loc_2.y=170;
	
	Sur_load =IMG_Load("Texture/Loading/Loading Bar .png");
	SDL_Texture* Tex_load2 =SDL_CreateTextureFromSurface(rendload,Sur_load);
	SDL_FreeSurface(Sur_load);
	SDL_Rect loc_1;
	SDL_QueryTexture(Tex_load2,NULL,NULL,&loc_1.w,&loc_1.h);
	loc_1.h=30;
	loc_1.w=0;
	loc_1.x=0;
	loc_1.y=322.4;
	
	float p=30;
	int stop=0,speed=1;	
	while(loc_1.w!=800){
		loc_1.w+=5;
		p+=5*speed;
		stop++;
		if(stop%36>28){
			speed=0;
		}
		if(stop%36<15){
			speed=1;
		}
		if(stop%36<28 && stop%36>15){
			speed=2;
		}
		SDL_Delay(25);

		SDL_RenderClear(rendload);
		
		
		SDL_RenderCopy(rendload, Tex_load, NULL, &load);
		SDL_RenderCopyEx(rendload,Tex_load3,NULL,&loc_2,p,NULL,SDL_FLIP_NONE);
		SDL_RenderCopy(rendload, Tex_load2, NULL, &loc_1);
		SDL_RenderPresent(rendload);
	}
	//800
	SDL_Delay(0);
	SDL_DestroyRenderer(rendload);
	SDL_DestroyWindow(winload);
	//600
	SDL_Delay(0);


//##################################################################################################






//#################################################################################################
//Starting Menu

	win = SDL_CreateWindow("Dr Maddy",SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,1280,960,SDL_WINDOW_FULLSCREEN_DESKTOP);
	Uint32 render_flags= SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;	
	rend= SDL_CreateRenderer(win,-1,render_flags);
	SDL_Surface* Sur_Bg =IMG_Load("Texture/Starting/Warwolf.png");
	SDL_Texture* Tex_Bg_1 =SDL_CreateTextureFromSurface(rend,Sur_Bg);	
	SDL_FreeSurface(Sur_Bg);
	SDL_Rect war;
	SDL_QueryTexture(Tex_Bg_1,NULL,NULL,&war.w,&war.h);
	war.h=200;
	war.w=700;
	war.x=610;
	war.y=440;
	
	SDL_Rect FullRect;
	FullRect.w=1920;
	FullRect.h=1080;
	FullRect.x=0;
	FullRect.y=0;
	
	SDL_RenderDrawRect(rend,&FullRect);
	SDL_SetRenderDrawColor(rend,20,20,20,0);
	SDL_RenderFillRect(rend,&FullRect);
	int q=0;
	p=1;
	int pp=1;
	while(p!=0){
		if(q==0){
			p=p+1;
		}
		else{
			p=p-1;
		}
		if(p==255){
			q=1;
		}
		if(p<60){
			//0.5
			SDL_Delay(0.1);
		}
		else{	
			//0.2
			SDL_Delay(0.04);
		}
		SDL_SetTextureBlendMode(Tex_Bg_1,SDL_BLENDMODE_ADD);
		SDL_SetTextureAlphaMod(Tex_Bg_1,p);
		SDL_RenderClear(rend);
		SDL_RenderCopy(rend,Tex_Bg_1, NULL, &war);
		SDL_RenderPresent(rend);
		if(p==2 && q==0){
			//350
			SDL_Delay(0);
		}
	}
	
	//200
	SDL_Delay(0);
	
	Sur_Bg =IMG_Load("Texture/BgMenu/Background.png");
	SDL_Texture* Tex_Bg =SDL_CreateTextureFromSurface(rend,Sur_Bg);	
	SDL_FreeSurface(Sur_Bg);
	
	SDL_Surface* Cloud1=IMG_Load("Texture/BgMenu/Cloud.png");
	SDL_Surface* Cloud2=IMG_Load("Texture/BgMenu/Cloud3.png");
	SDL_Surface* Cloud3=IMG_Load("Texture/BgMenu/Cloud2rightlast.png");
	SDL_Surface* Leaf1=IMG_Load("Texture/BgMenu/Leaf.png");
	SDL_Surface* Leaf2=IMG_Load("Texture/BgMenu/Leaf2.png");
	SDL_Surface* Leaf3=IMG_Load("Texture/BgMenu/Leaf 3.png");
	SDL_Surface* Leaf4=IMG_Load("Texture/BgMenu/Leaf4.png");
	SDL_Surface* Leaf5=IMG_Load("Texture/BgMenu/Leaf5.png");
	SDL_Surface* Leaf6=IMG_Load("Texture/BgMenu/Leaf6.png");
	SDL_Surface* Bush=IMG_Load("Texture/BgMenu/Bush.png");
	SDL_Surface* Tree=IMG_Load("Texture/BgMenu/Tree.png");
	SDL_Surface* Fall=IMG_Load("Texture/BgMenu/FallingLeaf.png");
	SDL_Surface* sty=IMG_Load("Texture/Story.png");
	SDL_Surface* ran=IMG_Load("Texture/Random.png");
	SDL_Surface* lv1=IMG_Load("Texture/num1.png");
	SDL_Surface* lv2=IMG_Load("Texture/num2.png");
	SDL_Surface* lv3=IMG_Load("Texture/num3.png");
	SDL_Surface* lv4=IMG_Load("Texture/num4.png");
	SDL_Surface* lv5=IMG_Load("Texture/num5.png");
	SDL_Surface* lv6=IMG_Load("Texture/num6.png");
	SDL_Surface* lv7=IMG_Load("Texture/num7.png");
	SDL_Surface* lv8=IMG_Load("Texture/num8.png");
	SDL_Surface* lv9=IMG_Load("Texture/num9.png");
	SDL_Surface* lv10=IMG_Load("Texture/num10.png");
	
	
	
	SDL_Texture* c1= SDL_CreateTextureFromSurface(rend,Cloud1);
	SDL_Texture* c2= SDL_CreateTextureFromSurface(rend,Cloud2);
	SDL_Texture* c3= SDL_CreateTextureFromSurface(rend,Cloud3);
	SDL_Texture* l1= SDL_CreateTextureFromSurface(rend,Leaf1);
	SDL_Texture* l2= SDL_CreateTextureFromSurface(rend,Leaf2);
	SDL_Texture* l3= SDL_CreateTextureFromSurface(rend,Leaf3);
	SDL_Texture* l4= SDL_CreateTextureFromSurface(rend,Leaf4);
	SDL_Texture* l5= SDL_CreateTextureFromSurface(rend,Leaf5);
	SDL_Texture* l6= SDL_CreateTextureFromSurface(rend,Leaf6);
	SDL_Texture* b1= SDL_CreateTextureFromSurface(rend,Bush);
	SDL_Texture* t1= SDL_CreateTextureFromSurface(rend,Tree);
	SDL_Texture* f1= SDL_CreateTextureFromSurface(rend,Fall);
	
	SDL_Texture* num1= SDL_CreateTextureFromSurface(rend,lv1);
	SDL_Texture* num2= SDL_CreateTextureFromSurface(rend,lv2);
	SDL_Texture* num3= SDL_CreateTextureFromSurface(rend,lv3);
	SDL_Texture* num4= SDL_CreateTextureFromSurface(rend,lv4);
	SDL_Texture* num5= SDL_CreateTextureFromSurface(rend,lv5);
	SDL_Texture* num6= SDL_CreateTextureFromSurface(rend,lv6);
	SDL_Texture* num7= SDL_CreateTextureFromSurface(rend,lv7);
	SDL_Texture* num8= SDL_CreateTextureFromSurface(rend,lv8);
	SDL_Texture* num9= SDL_CreateTextureFromSurface(rend,lv9);
	SDL_Texture* num10= SDL_CreateTextureFromSurface(rend,lv10);
	
	SDL_Texture* Story= SDL_CreateTextureFromSurface(rend,sty);
	SDL_Texture* Random= SDL_CreateTextureFromSurface(rend,ran);
	
	SDL_Surface* ui=IMG_Load("Texture/BgMenu/Menu Background.png");
	SDL_Texture* UI=SDL_CreateTextureFromSurface(rend,ui);
	
	SDL_Surface* uit=IMG_Load("Texture/BgMenu/Menu Text.png");
	SDL_Texture* UIt=SDL_CreateTextureFromSurface(rend,uit);
		
	TTF_Font* font1=TTF_OpenFont("Font/ChrustyRock-ORLA.ttf",70);

	SDL_Surface* surfont= TTF_RenderText_Solid(font1,"Play",{100,100,100});
	SDL_Texture* textf=SDL_CreateTextureFromSurface(rend,surfont);
	SDL_FreeSurface(surfont);
		
	SDL_Surface* pl=IMG_Load("Texture/BgMenu/Play.png");
	SDL_Texture* Play=SDL_CreateTextureFromSurface(rend,pl);	
	
	SDL_Surface* le=IMG_Load("Texture/BgMenu/Level.png");
	SDL_Texture* Level=SDL_CreateTextureFromSurface(rend,le);	
	
	SDL_Surface* op=IMG_Load("Texture/BgMenu/Option.png");
	SDL_Texture* Option=SDL_CreateTextureFromSurface(rend,op);	
	
	SDL_Surface* qu=IMG_Load("Texture/BgMenu/Quit.png");
	SDL_Texture* Quit=SDL_CreateTextureFromSurface(rend,qu);	
	
	SDL_Surface* bgmon=IMG_Load("Texture/BgMenu/Musicon.png");
	SDL_Texture* Bgmon=SDL_CreateTextureFromSurface(rend,bgmon);
	
	SDL_Surface* bgmoff=IMG_Load("Texture/BgMenu/Musicoff.png");
	SDL_Texture* Bgmoff=SDL_CreateTextureFromSurface(rend,bgmoff);
	
	SDL_Surface* seon=IMG_Load("Texture/BgMenu/Soundeffecton.png");
	SDL_Texture* Seon=SDL_CreateTextureFromSurface(rend,seon);
	
	SDL_Surface* seoff=IMG_Load("Texture/BgMenu/Soundeffectoff.png");
	SDL_Texture* Seoff=SDL_CreateTextureFromSurface(rend,seoff);
	
	SDL_Surface* back=IMG_Load("Texture/BgMenu/Back.png");
	SDL_Texture* Back=SDL_CreateTextureFromSurface(rend,back);
	
	SDL_Surface* jl=IMG_Load("Texture/Jack.png");
	SDL_Texture* Jacklogo=SDL_CreateTextureFromSurface(rend,jl);
	
	Mix_Music* BackMusic= Mix_LoadMUS("Duck.mp3"); 
	Mix_Music* MenuMusic= Mix_LoadMUS("Nature.mp3");
		
	SDL_Rect Bg;
	SDL_Rect cl1;
	SDL_Rect cl2;
	SDL_Rect cl3;
	SDL_Rect Treee;
	
	p=1;
	int Bgx=-1080;
	int cx=2300,cxp=-1000;
	int count=0;
	int mdown;
	int mouse_p,mouse_l,mouse_o,mouse_q,mouse_b,mouse_music=-1,mouse_sound=-1;
	int story_small=0,random_small=0;
	int story_big=0,random_big=0;

	Mix_PlayMusic(MenuMusic,-1);
	int QuitFull=0;
	while(QuitFull==0){
	
	while(count!=-1){
	
	
	
	if(story_small==1){
	story_big=0;
	} 
	if(random_small==1){
	random_big=0;
	}
	int x,y;
	Uint32 mbutton;
	
	
		if(p<255){
			p=p+1;
		}
		if(Bgx!=0){
			Bgx=Bgx+4;
		}
		if(count!=-1){
			if(cx!=-1000){
				cx=cx-1;
				cxp=cxp+1;
			}
			else{
			cx=2300;
			cxp=-1000;
			}
				
		}
	count++;
	SDL_Delay(0.5);
	SDL_RenderClear(rend);
	
	
	SDL_QueryTexture(Tex_Bg,NULL,NULL,&Bg.w,&Bg.h);
	Bg.h=1080;
	Bg.w=3000;
	Bg.x=Bgx;
	Bg.y=0;
	
	SDL_Rect Ui;
	SDL_QueryTexture(UI,NULL,NULL,&Ui.w,&Ui.h);
	Ui.h=700;
	Ui.w=1100;
	Ui.x=960-550;
	Ui.y=540-350;
	
	SDL_Rect Uit;
	SDL_QueryTexture(UIt,NULL,NULL,&Uit.w,&Uit.h);
	Uit.h=400;
	Uit.w=600;
	Uit.x=960-300;
	Uit.y=610-200;
	
	
	SDL_QueryTexture(c1,NULL,NULL,&cl1.w,&cl1.h);
	cl1.h=70;
	cl1.w=0.3*1800;
	cl1.x=1.2*cx+Bgx;
	cl1.y=250;
	
	
	SDL_QueryTexture(c2,NULL,NULL,&cl2.w,&cl2.h);
	cl2.h=0.25*200;
	cl2.w=0.25*1800;
	cl2.x=1.5*cxp+Bgx;
	cl2.y=370;
	
	
	SDL_QueryTexture(c3,NULL,NULL,&cl3.w,&cl3.h);
	cl3.h=0.2*200;
	cl3.w=0.15*1800;
	cl3.x=600+0.9*cxp+Bgx;
	cl3.y=150;

	
	
	SDL_QueryTexture(t1,NULL,NULL,&Treee.w,&Treee.h);
	Treee.h=500;
	Treee.w=350;
	Treee.x=250+Bgx;
	Treee.y=310;
	
	SDL_Rect TT;
	SDL_QueryTexture(textf,NULL,NULL,&TT.w,&TT.h);
	TT.h=150;
	TT.w=500;
	TT.x=960-250;
	TT.y=280-75;

	SDL_Rect PLAY;
	SDL_QueryTexture(Play,NULL,NULL,&PLAY.w,&PLAY.h);
	PLAY.h=125;
	PLAY.w=1100;
	PLAY.x=350+50;
	PLAY.y=370;
	
	SDL_Rect STO;
	SDL_Rect RAN;

	SDL_Rect NUM1;
	SDL_QueryTexture(num1,NULL,NULL,&NUM1.w,&NUM1.h);
	NUM1.h=100;
	NUM1.w=100;
	NUM1.x=710;
	NUM1.y=420;
	
	SDL_Rect NUM5;
	SDL_QueryTexture(num5,NULL,NULL,&NUM5.w,&NUM5.h);
	NUM5.h=100;
	NUM5.w=100;
	NUM5.x=710;
	NUM5.y=420+130;
	
	SDL_Rect NUM9;
	SDL_QueryTexture(num9,NULL,NULL,&NUM9.w,&NUM9.h);
	NUM9.h=100;
	NUM9.w=100;
	NUM9.x=710;
	NUM9.y=420+260;
	
	SDL_Rect NUM2;
	SDL_QueryTexture(num2,NULL,NULL,&NUM2.w,&NUM2.h);
	NUM2.h=100;
	NUM2.w=100;
	NUM2.x=710+130;
	NUM2.y=420;
	
	SDL_Rect NUM6;
	SDL_QueryTexture(num6,NULL,NULL,&NUM6.w,&NUM6.h);
	NUM6.h=100;
	NUM6.w=100;
	NUM6.x=710+130;
	NUM6.y=420+130;
	
	SDL_Rect NUM10;
	SDL_QueryTexture(num10,NULL,NULL,&NUM10.w,&NUM10.h);
	NUM10.h=100;
	NUM10.w=100;
	NUM10.x=710+130;
	NUM10.y=420+260;
	
	SDL_Rect NUM3;
	SDL_QueryTexture(num3,NULL,NULL,&NUM3.w,&NUM3.h);
	NUM3.h=100;
	NUM3.w=100;
	NUM3.x=710+260;
	NUM3.y=420;
	
	SDL_Rect NUM7;
	SDL_QueryTexture(num7,NULL,NULL,&NUM7.w,&NUM7.h);
	NUM7.h=100;
	NUM7.w=100;
	NUM7.x=710+260;
	NUM7.y=420+130;
	
	SDL_Rect NUM4;
	SDL_QueryTexture(num4,NULL,NULL,&NUM4.w,&NUM4.h);
	NUM4.h=100;
	NUM4.w=100;
	NUM4.x=710+390;
	NUM4.y=420;
	
	SDL_Rect NUM8;
	SDL_QueryTexture(num8,NULL,NULL,&NUM8.w,&NUM8.h);
	NUM8.h=100;
	NUM8.w=100;
	NUM8.x=710+390;
	NUM8.y=420+130;

	SDL_Rect LEVEL;
	SDL_QueryTexture(Level,NULL,NULL,&LEVEL.w,&LEVEL.h);
	LEVEL.h=125;
	LEVEL.w=1100;
	LEVEL.x=360;
	LEVEL.y=490;
	
	SDL_Rect OPTION;
	SDL_QueryTexture(Option,NULL,NULL,&OPTION.w,&OPTION.h);
	OPTION.h=125;
	OPTION.w=1100;
	OPTION.x=330;
	OPTION.y=595;
	
	SDL_Rect QUIT;
	SDL_QueryTexture(Quit,NULL,NULL,&QUIT.w,&QUIT.h);
	QUIT.h=125;
	QUIT.w=1100;
	QUIT.x=340;
	QUIT.y=703;
	
	SDL_Rect MUSIC;
	SDL_QueryTexture(Bgmon,NULL,NULL,&MUSIC.w,&MUSIC.h);
	MUSIC.h=100;
	MUSIC.w=600;
	MUSIC.x=630;
	MUSIC.y=440;
	
	SDL_Rect SOUNDEFFECT;
	SDL_QueryTexture(Seon,NULL,NULL,&SOUNDEFFECT.w,&SOUNDEFFECT.h);
	SOUNDEFFECT.h=100;
	SOUNDEFFECT.w=600;
	SOUNDEFFECT.x=630;
	SOUNDEFFECT.y=590;
	
	SDL_Rect BACK;
	SDL_QueryTexture(Back,NULL,NULL,&BACK.w,&BACK.h);
	BACK.h=100;
	BACK.w=500;
	BACK.x=600;
	BACK.y=700;
	
	SDL_Rect BACK2;
	SDL_QueryTexture(Back,NULL,NULL,&BACK2.w,&BACK2.h);
	BACK2.h=120;
	BACK2.w=550;
	BACK2.x=575;
	BACK2.y=690;
	
	SDL_Rect JL;
	SDL_QueryTexture(Jacklogo,NULL,NULL,&JL.w,&JL.h);
	JL.h=200;
	JL.w=700;
	JL.x=960-350;
	JL.y=230;
	
	
	
	SDL_RenderClear(rend);
	int texblendstop;
	if(texblendstop!=11223344){
	SDL_SetTextureBlendMode(Tex_Bg,SDL_BLENDMODE_ADD);
	SDL_SetTextureAlphaMod(Tex_Bg,p);
	}
	
	if(ui1!=0){
	texblendstop=11223344;
	}
	
		
	SDL_RenderCopy(rend,Tex_Bg, NULL, &Bg);
	if(count>200){
		SDL_RenderCopyEx(rend,c1, NULL, &cl1,2,NULL,SDL_FLIP_NONE);
	}
	

	
	SDL_RenderCopyEx(rend,c2, NULL, &cl2,0,NULL,SDL_FLIP_NONE);
	SDL_RenderCopyEx(rend,c3, NULL, &cl3,5,NULL,SDL_FLIP_NONE);
	SDL_RenderCopy(rend,t1,NULL,&Treee);
	
	SDL_RenderCopy(rend,UI,NULL,&Ui);
	if(ui1==0){
		SDL_RenderCopy(rend,UIt,NULL,&Uit);
	}
	else if(ui1==1){
		SDL_RenderCopy(rend,Bgmon,NULL,&MUSIC);
		SDL_RenderCopy(rend,Seon,NULL,&SOUNDEFFECT);

		SDL_RenderCopy(rend,Back,NULL,&BACK);		
	
	
	}
	
	if(SDL_PollEvent(&event)){
		if(event.type== SDL_QUIT){
			break;
		}
		
		if(event.type == SDL_MOUSEBUTTONDOWN || mdown==1){
			mdown=1;
			if(mdown==1 && event.type==SDL_MOUSEBUTTONUP){
				mdown=0;
				
			if(mouse_p==1 && ui1==0){
				SDL_RenderClear(rend);
				break;
				}
			if(mouse_l==1 && ui1==0){
				ui1=2;
			
			}
			if(mouse_o==1 && ui1==0){
				ui1=1;
				mouse_p=0;
				mouse_l=0;
				mouse_o=0;
				mouse_q=0;
				mouse_b=0;
			}
			if(mouse_q==1 && ui1==0){
				SDL_RenderClear(rend);
				SDL_RenderPresent(rend);
				
				SDL_DestroyRenderer(rend);
				SDL_DestroyWindow(win);
				SDL_Quit();
				
				break;
			}
			if(mouse_b==1 && ui1==1){
				ui1=0;
				mouse_p=0;
				mouse_l=0;
				mouse_o=0;
				mouse_q=0;
				mouse_b=0;
				
			}
			if(ui1==1 && x<1208 && y<515 && x>1132 && y>452){
			mouse_music=-1*mouse_music;
			}
			if(ui1==1 && x<1208 && y<665 && x>1132 && y>602){
			mouse_sound=-1*mouse_sound;
			}
			
			
			
			
			}
			
		}
		
		
		if(event.type == SDL_MOUSEBUTTONDOWN){
			if(ui1==2){
				if(x<960-250+500 && x>960-250 && y<370+100+125 && y>370+100 ){
					ui1=3;
				}
				else if(x<960-250+500 && x>960-250 && y<370+275+125 && y>370+275 ){
					level=0;
					break;
				
	
				
				}
			
			
			
			
			
			
			
			
			}
			else if(ui1==3){
				if(x<810 && x>710 && y<520 && y>420 ){
					level=1;
					break;
				}
				else if(x<810+130 && x>710+130 && y<520 && y>420){
					level=2;
					break;
				}
				else if(x<810+260 && x>710+260 && y<520 && y>420){
					level=3;
					break;
				}
				else if(x<810+390 && x>710+390 && y<520 && y>420){
					level=4;
					break;
				}
				else if(x<810 && x>710 && y<520+130 && y>420+130){
					level=5;
					break;
				}
				else if(x<810+130 && x>710+130 && y<520+130 && y>420+130){
					level=6;
					break;
				}
				else if(x<810+260 && x>710+260 && y<520+130 && y>420+130){
					level=7;
					break;
				}
				else if(x<810+390 && x>710+390 && y<520+130 && y>420+130){
					level=8;
					break;
				}
				else if(x<810 && x>710 && y<520+260 && y>420+260){
					level=9;
					break;
				}
				else if(x<810+130 && x>710+130 && y<520+260 && y>420+260){
					level=10;
					break;
				}
			
			
			
			
			
			}
			
			
		}	
		
		if(event.type== SDL_MOUSEMOTION){
		mbutton= SDL_GetMouseState(&x,&y);
		
			if((x>676 && y>417) && (x<1265 && y<495) && ui1==0){	
			mouse_p=1;
			mouse_l=0;
			mouse_o=0;
			mouse_q=0;
			
			}
			else if((x>676 && y>517) && (x<1265 && y<595) && ui1==0){
			mouse_p=0;
			mouse_l=1;
			mouse_o=0;
			mouse_q=0;
			}
			else if((x>676 && y>622) && (x<1265 && y<700) && ui1==0){
			mouse_p=0;
			mouse_l=0;
			mouse_o=1;
			mouse_q=0;
			}
			else if((x>676 && y>720) && (x<1265 && y<798) && ui1==0){
			mouse_p=0;
			mouse_l=0;
			mouse_o=0;
			mouse_q=1;
			}
			else if(x<1012 && y<795 && x>606 && y>705 && ui1==1){
			mouse_b=1;
			}
			else if(x<960-250+500 && x>960-250 && y<370+100+125 && y>370+100 && ui1==2){
			story_big=1;
			random_big=0;
			story_small=0;
			}
			else if(x<960-250+500 && x>960-250 && y<370+275+125 && y>370+275 && ui1==2){
			random_big=1;
			story_big=0;
			random_small=0;
			}
			else if(!(x<960-250+500 && x>960-250 && y<370+100+125 && y>370+100) && !(x<960-250+500 && x>960-250 && y<370+275+125 && y>370+275) && ui1==2){
			story_small=1;
			random_small=1;
			}
			else{
			mouse_p=0;
			mouse_l=0;
			mouse_o=0;
			mouse_q=0;
			mouse_b=0;
			story_small=0;
			random_small=0;
			}
		
		
		
		
		
		}
		else{
			
			story_small=0;
			random_small=0;
		}
		

		
		}

	SDL_QueryTexture(Story,NULL,NULL,&STO.w,&STO.h);
	STO.h=125+20*story_big;
	STO.w=500+80*story_big;
	STO.x=960-250-40*story_big;
	STO.y=370+100-10*story_big;

	SDL_QueryTexture(Random,NULL,NULL,&RAN.w,&RAN.h);
	RAN.h=125+20*random_big;
	RAN.w=500+80*random_big;
	RAN.x=960-250-40*random_big;
	RAN.y=370+275-10*random_big;	
	
	
	if(ui1==0){
	if(mouse_p==1){
		SDL_RenderCopy(rend,Play,NULL,&PLAY);
	}
	if(mouse_l==1){
		SDL_RenderCopy(rend,Level,NULL,&LEVEL);
	}
	if(mouse_o==1){
		SDL_RenderCopy(rend,Option,NULL,&OPTION);
	}
	if(mouse_q==1){
		SDL_RenderCopy(rend,Quit,NULL,&QUIT);
	}
	}
	else if(ui1==1){
		if(mouse_b==1){
		SDL_RenderCopy(rend,Back,NULL,&BACK2);
		}
		if(mouse_music==1){
		SDL_RenderCopy(rend,Bgmoff,NULL,&MUSIC);
		
		}
		if(mouse_sound==1){
		SDL_RenderCopy(rend,Seoff,NULL,&SOUNDEFFECT);
		
		}
		
	}
	else if(ui1==2){
		SDL_RenderCopy(rend,Story,NULL,&STO);
		SDL_RenderCopy(rend,Random,NULL,&RAN);
	
	
	
	}
	else if(ui1==3){
		SDL_RenderCopy(rend,num1,NULL,&NUM1);	
		SDL_RenderCopy(rend,num5,NULL,&NUM5);	
		SDL_RenderCopy(rend,num9,NULL,&NUM9);	
		SDL_RenderCopy(rend,num2,NULL,&NUM2);	
		SDL_RenderCopy(rend,num6,NULL,&NUM6);	
		SDL_RenderCopy(rend,num10,NULL,&NUM10);
		SDL_RenderCopy(rend,num3,NULL,&NUM3);	
		SDL_RenderCopy(rend,num7,NULL,&NUM7);	
		SDL_RenderCopy(rend,num4,NULL,&NUM4);	
		SDL_RenderCopy(rend,num8,NULL,&NUM8);		
	
	
	}
	else if(ui1==-1){
		break;
	}
	
	SDL_RenderCopy(rend,Jacklogo,NULL,&JL);
	SDL_RenderPresent(rend);
	
	
	}
	
	
	
	
	
	
	
	
//##################################################################################################
//Text input
//rand()???
		Sur_Bg =IMG_Load("Texture/BgMenu/Background.png");
		SDL_Texture* Tex_Bg2 =SDL_CreateTextureFromSurface(rend,Sur_Bg);	
		SDL_FreeSurface(Sur_Bg);
		SDL_QueryTexture(Tex_Bg2,NULL,NULL,&Bg.w,&Bg.h);
		Bg.h=2100;
		Bg.w=3000;
		Bg.x=0;
		Bg.y=0;

		grassfield=IMG_Load("Tiles/platformPack_tile001.png");
		Grassfield=SDL_CreateTextureFromSurface(rend,grassfield);
		SDL_FreeSurface(grassfield);
		
		
		ladder1=IMG_Load("Tiles/platformPack_tile037.png");
		Ladder1=SDL_CreateTextureFromSurface(rend,ladder1);
		SDL_FreeSurface(ladder1);
		
		
		
		ladder2=IMG_Load("Tiles/platformPack_tile038.png");
		Ladder=SDL_CreateTextureFromSurface(rend,ladder2);
		SDL_FreeSurface(ladder2);
		
		
		
		swtch1=IMG_Load("Tiles/platformPack_tile064.png");
		SwitchR=SDL_CreateTextureFromSurface(rend,swtch1);
		swtchoff1=IMG_Load("Tiles/platformPack_tile065.png");
		SwitchRoff=SDL_CreateTextureFromSurface(rend,swtchoff1);
		SDL_FreeSurface(swtchoff1);
		SDL_FreeSurface(swtch1);
		
		
		swtch2=IMG_Load("Tiles/platformPack_tile062.png");
		SwitchG=SDL_CreateTextureFromSurface(rend,swtch2);
		swtchoff2=IMG_Load("Tiles/platformPack_tile063.png");
		SwitchGoff=SDL_CreateTextureFromSurface(rend,swtchoff2);
		SDL_FreeSurface(swtchoff2);
		SDL_FreeSurface(swtch2);
		
		
		swtch3=IMG_Load("Tiles/platformPack_tile053.png");
		SwitchB=SDL_CreateTextureFromSurface(rend,swtch3);
		swtchoff3=IMG_Load("Tiles/platformPack_tile054.png");
		SwitchBoff=SDL_CreateTextureFromSurface(rend,swtchoff3);
		SDL_FreeSurface(swtchoff3);
		SDL_FreeSurface(swtch3);
		
		swtch4=IMG_Load("Tiles/platformPack_tile055.png");
		SwitchY=SDL_CreateTextureFromSurface(rend,swtch4);
		swtchoff4=IMG_Load("Tiles/platformPack_tile056.png");
		SwitchYoff=SDL_CreateTextureFromSurface(rend,swtchoff4);
		SDL_FreeSurface(swtchoff4);
		SDL_FreeSurface(swtch4);
		
		
		num=IMG_Load("Texture/a1.png");
		one=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a2.png");
		two=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a3.png");
		three=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a4.png");
		four=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a5.png");
		five=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a6.png");
		six=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a7.png");
		seven=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a8.png");
		eight=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		num=IMG_Load("Texture/a9.png");
		nine=SDL_CreateTextureFromSurface(rend,num);
		SDL_FreeSurface(num);
		
		door1=IMG_Load("Tiles/platformPack_tile020.png");
		DoorR=SDL_CreateTextureFromSurface(rend,door1);
		SDL_FreeSurface(door1);
		
		door2=IMG_Load("Tiles/platformPack_tile019.png");
		DoorG=SDL_CreateTextureFromSurface(rend,door2);
		SDL_FreeSurface(door2);
		
		door3=IMG_Load("Tiles/platformPack_tile007.png");
		DoorB=SDL_CreateTextureFromSurface(rend,door3);
		SDL_FreeSurface(door3);
		
		door4=IMG_Load("Tiles/platformPack_tile008.png");
		DoorYe=SDL_CreateTextureFromSurface(rend,door4);
		SDL_FreeSurface(door4);
		
		box=IMG_Load("Tiles/platformPack_tile047.png");
		BoxS=SDL_CreateTextureFromSurface(rend,box);
		SDL_FreeSurface(box);
		
		paper=IMG_Load("Tiles/paper roll.png");
		PRoll=SDL_CreateTextureFromSurface(rend,paper);
		SDL_FreeSurface(paper);
		
		jack=IMG_Load("Poses/character_maleAdventurer_idle.png");
		Jackrest=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk0.png");
		Jackwalk1=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk1.png");
		Jackwalk2=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk2.png");
		Jackwalk3=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk3.png");
		Jackwalk4=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk4.png");
		Jackwalk5=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk5.png");
		Jackwalk6=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk6.png");
		Jackwalk7=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_walk7.png");
		Jackwalk8=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_climb0.png");
		Jackclimb1=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_climb1.png");
		Jackclimb2=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		jack=IMG_Load("Poses/character_maleAdventurer_drag.png");
		Jackdrag=SDL_CreateTextureFromSurface(rend,jack);
		SDL_FreeSurface(jack);
		
		barrel=IMG_Load("Tiles/Barrel.png");
		Barrel=SDL_CreateTextureFromSurface(rend,barrel);
		SDL_FreeSurface(barrel);
		
		vic=IMG_Load("Texture/Vic.png");
		Vic=SDL_CreateTextureFromSurface(rend,vic);
		SDL_FreeSurface(vic);
		
		restart=IMG_Load("Texture/Restart.png");
		Restart=SDL_CreateTextureFromSurface(rend,restart);
		SDL_FreeSurface(restart);
		
		hhome=IMG_Load("Texture/Home.png");
		Home=SDL_CreateTextureFromSurface(rend,hhome);
		SDL_FreeSurface(hhome);
		
		bggg=IMG_Load("Texture/Bgg.png");
		Bgg=SDL_CreateTextureFromSurface(rend,bggg);
		SDL_FreeSurface(bggg);

	int sw1=0,sw2=0,dr1=0,dr2=0;
	int play=0;
	extern int right,left,up,down;
	extern int boxright[4],boxleft[4],boxfall[4];
	extern int barright,barleft,barfall;
	extern int fall;
	int okr=0,okl=0,oku=0,okd=0;
	int complete=0;
	int delaycount=0;
	int boxr=0,boxl=0,boxf=0;
	int doorclose1=0,doorclose2=0;
	int JACKrest=0,JACKwalk=1,JACKclimb=1,JACKdrag=1;
	int aa=0,bb=0;
	int rr=0,ll=0,uu=0,dd=0;
	double BarMov=0;
	int RollStart=0,RollStop=0,S=1;
	int switchcount=0;
	int rota=0;
	extern int oneinc;
	count=0;
	home=0;
	
	Mix_PlayMusic(BackMusic,-1);
	
		if(level==1){
			int barx=1410;
			int bary=900;
			right=0;left=0;up=0;down=0;
			fall=-3;
			fullterm=0;
			for(k=0;k<1;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<2;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_1(&barx,&bary);
				if(home==1){
				break;
				}
			}
			
		}
		else if(level==2){
			int barx=500;
			int bary=720;
			right=0;left=0;up=0;down=0;
			fall=-3;
			fullterm=0;
			for(k=0;k<1;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_2(&barx,&bary);
				if(home==1){
				break;
				}
			}
		
		}
		else if(level==3){
			int barx=840;
			int bary=780;
			fullterm=0;
			right=0;left=0;up=0;down=0;
			fall=-3;
			for(k=0;k<1;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_3(&barx,&bary);
				if(home==1){
				break;
				}
			}
		
		}
		else if (level==4){	
		
			int barx=1400;
			int bary=420;
			fullterm=0;
			right=0;left=0;up=0;down=0;
			fall=-3;
			for(k=0;k<2;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while (complete == 0){
				level_4(&barx,&bary);
				if(home==1){
				break;
				}
			}

		}
		else if (level==5){
			int barx=1400;
			int bary=540;
			fullterm=0;
			right=0;left=0;up=0;down=0;
			fall=-3;
			for(k=0;k<2;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while (complete == 0){
		 		level_5(&barx,&bary);
				if(home==1){
				break;
				}
			}
				
		}
		else if(level==6){
			int barx=1000;
			int bary=540;
			fullterm=0;
			right=0;left=0;up=0;down=0;
			fall=-3;
			for(k=0;k<2;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_6(&barx,&bary);
				if(home==1){
				break;
				}
			}	

		}
		else if(level==7){
			int barx=480;
			int bary=660;
			right=0;left=0;up=0;down=0;
			fall=-3;
			fullterm=0;
			for(k=0;k<2;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_7(&barx,&bary);
				if(home==1){
				break;
				}
			}
		
		}
		else if(level==8){
			int barx=-10;
			int bary=-10;
			right=0;left=0;up=0;down=0;
			fall=-3;
			fullterm=0;
			for(k=0;k<3;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_8(&barx,&bary);
				if(home==1){
				break;
				}
			}
			
		}
		else if(level==9){
			int barx=1440;
			int bary=480;
			right=0;left=0;up=0;down=0;
			fall=-3;
			fullterm=0;
			for(k=0;k<3;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0;
			savex=0;
			savey=0;
			while(complete==0){
				level_9(&barx,&bary);
				if(home==1){
				break;
				}
			}
			
		}
		else if(level==10){
			int barx=1200;
			int bary=780;
			right=0;left=0;up=0;down=0;
			fall=-3;
			fullterm=0;
			for(k=0;k<2;k++){
				boxright[k]=0;
				boxleft[k]=0;
				boxfall[k]=-3;
			}
			for(k=0;k<4;k++){
				doorclose[k]=0;
			}
			barright=0;
			barleft=0;
			barfall=-3;
			rolll=0;rollr=0; 
			savex=0;
			savey=0;
			while(complete==0){
				level_10(&barx,&bary);
				if(home==1){
				break;
				}
			}
			
		}
		else if(level==0){
	//##################################################
	//##################################################
	/*C
	  O
	  M
	  I
	  N
	  G
	  
	  S
	  O
	  O
	  N*/
	//##################################################
	//##################################################	
			SDL_RenderClear(rend);
			srand(time(0));
			
			int i,j;
			int GrassCountend=(rand()%9);
				while(GrassCountend<5){
					GrassCountend=(rand()%9);
				}
			int GrassXend[GrassCountend];
			int GrassYend[GrassCountend];
			int GrassNumend[GrassCountend];
			
			int GrassXMin=29*60, GrassXMax=2*60, GrassYMin=1040, GrassYMax=100;
			int totalNum=0;
			int SortY[GrassCountend];
			int sortavr=0;
			int GrassDummyY[GrassCountend],GrassDummyNum[GrassCountend];
			int P=1;
			//Grassfield randomized organization
			
			while((!((GrassXMin<=8*60) && (GrassXMax<=26*60 && GrassXMax>=24*60) && (GrassYMin<=360) && (GrassYMax<=840 && GrassYMax>=780 && totalNum>=5*GrassCountend && sortavr>=3) && P==0))){
				
				GrassXMin=29*60;
				GrassXMax=2*60; 
				GrassYMin=1040;
				GrassYMax=100;
				totalNum=0;
				P=0;
				
			
				
				for(i=0;i<GrassCountend;i++){
					GrassXend[i]=360+(rand()%17)*60;
					GrassYend[i]=300+(rand()%10)*60;
					GrassNumend[i]=(rand()%10);
					while(GrassNumend[i]<2){
						GrassNumend[i]=(rand()%10);
					}
					if(GrassXend[i]<=GrassXMin){
						GrassXMin=GrassXend[i];
					}
					if(GrassXend[i]+GrassNumend[i]*60>=GrassXMax){
						GrassXMax=GrassXend[i]+GrassNumend[i]*60;
					}
					if(GrassYend[i]<=GrassYMin){
						GrassYMin=GrassYend[i];
					}
					if(GrassYend[i]>=GrassYMax){
						GrassYMax=GrassYend[i];
					}	
				}
				
				for(i=0;i<GrassCountend;i++){
					totalNum+=GrassNumend[i];
				}
				
				int j,YMax=0,sortp;
				
				for(i=0;i<GrassCountend;i++){
					GrassDummyY[i]=GrassYend[i];
				}
				
				for(i=0;i<GrassCountend;i++){
					YMax=0;
					for(j=0;j<GrassCountend;j++){
						if(YMax<=GrassDummyY[j]){
						YMax=GrassDummyY[j];
						sortp=j;
						}
					}
					GrassDummyY[sortp]=0;
					SortY[i]=YMax;
				}
				int sortn=0,sortdiff=0;
				for(i=1;i<GrassCountend;i++){
					if(SortY[i-1]>SortY[i]){
						sortn++;
						sortdiff+=(SortY[i-1]-SortY[i]);
					}
				}
				if(sortn!=0){
				sortavr=sortdiff/(60*sortn);
				printf("\navr:%d\tP:%d\tTotnum:%d\tGrass:%d|tXmin:%d\tXmax:%d\tYmin:%d\tYmax:%d\n",sortavr,P,totalNum,GrassCountend,GrassXMin,GrassXMax,GrassYMin,GrassYMax);
				}
				else{
					sortavr=1;
				}
				
				for(i=0;i<GrassCountend;i++){
					for(j=0;j<GrassCountend;j++){
						if(GrassYend[i]==GrassYend[j] && ((GrassXend[i]>GrassXend[j] && GrassXend[i]<=GrassXend[j]+GrassNumend[j]*60)||(i!=j && GrassXend[i]==GrassXend[j]))){
							P=1;
							break;
						}
					
					
					}
					if(P==1){
						break;
					}
				
				
				}
				
			
			}
			
			
			for(i=0;i<GrassCountend;i++){
					GrassDummyY[i]=GrassYend[i];
				}
			for(i=0;i<GrassCountend;i++){
					GrassDummyNum[i]=GrassNumend[i];
				}	
			
			//ladder randomized organisation
			
			int sortp,Xmin=30*60,GrassDummyX[GrassCountend],sortX[GrassCountend],sortn=0,sortdiff=0;
			
			int LadMapping[9][9]={0};
			int PosFinder[GrassCountend]={0};
			int pos,kkk;
			for(i=0;i<GrassCountend;i++){
				PosFinder[i]=i;
			}
			for(i=0;i<GrassCountend;i++){
				GrassDummyX[i]=GrassXend[i];
			}
			for(j=0;j<GrassCountend;j++){
				for(i=1;i<GrassCountend;i++){
					if(GrassDummyX[i-1]>GrassDummyX[i]){
						sortp=GrassDummyX[i-1];
						GrassDummyX[i-1]=GrassDummyX[i];
						GrassDummyX[i]=sortp;
						sortp=GrassDummyY[i-1];
						GrassDummyY[i-1]=GrassDummyY[i];
						GrassDummyY[i]=sortp;
						sortp=GrassDummyNum[i-1];
						GrassDummyNum[i-1]=GrassDummyNum[i];
						GrassDummyNum[i]=sortp;
						kkk=PosFinder[i-1];
						PosFinder[i-1]=PosFinder[i];
						PosFinder[i]=kkk;
					}
				
				}
			}
			
			arrayprint(GrassDummyX,GrassCountend);
			arrayprint(GrassDummyY,GrassCountend);
			arrayprint(GrassDummyNum,GrassCountend);
			arrayprint(PosFinder,GrassCountend);
			//LADDER - sorted GrassDummyX and GrassDummyY base on GrassDummyX
			
			int LadYlim[GrassCountend],limcount=0;
			int LadderYend[2*GrassCountend]={0};
			int LadderXend[2*GrassCountend]={0};
			int LadderNumend[2*GrassCountend]={0};
			int brk=0;
			int ladi=0;
			
			int Ladpos[GrassCountend];
			
			//ladder left(-60) Y-ground
			for(i=0;i<GrassCountend;i++){
				limcount=0;
				for(j=0;j<GrassCountend;j++){
					LadYlim[j]=30*60;
				}
				brk=0;
				for(j=0;j<i;j++){
					if((GrassDummyY[j]==GrassDummyY[i] && GrassDummyX[i]<=GrassDummyX[j]+GrassDummyNum[j]*60) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]+GrassDummyNum[j]*60>=GrassDummyX[i] && GrassDummyX[j]<GrassDummyX[i]) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]==GrassDummyX[i])){
						brk=1;	
					}
				}
				if(brk==1){
					continue;
				}
				
				
				
				for(j=0;j<GrassCountend;j++){
					if(GrassDummyX[j]<GrassDummyX[i] && GrassDummyX[j]+GrassDummyNum[j]*60>=GrassDummyX[i]){		
						LadYlim[limcount]=GrassDummyY[j];
						Ladpos[limcount]=j;
						limcount++;
						
					}
					
				
				}
				int MaxLim=30*60;
				
				printf("i=%d ",i);
				printf("lim:%dpos:%d\n",limcount,pos);
					
				arrayprint(LadYlim,GrassCountend);
				
				for(j=0;j<GrassCountend;j++){
					if(LadYlim[j]>GrassDummyY[i] && MaxLim>=LadYlim[j] && LadYlim[j]<18*60 && LadYlim[j]>0){
						MaxLim=LadYlim[j];
						pos=Ladpos[j];
					}
				}
				
				
				
				if(MaxLim==30*60){
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]==GrassDummyX[i] && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
							MaxLim=GrassDummyY[j];
							pos=j;
							break;
						}
					
				
					}
				
				}
				
				if(MaxLim==30*60){
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]+GrassDummyNum[j]*60==GrassDummyX[i]-60 && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
							MaxLim=GrassDummyY[j];
							pos=j;
							break;
						}
					
				
					}
				
				}
				
				
				
				
				LadderXend[ladi]=GrassDummyX[i]-60;
				
				printf("\n%d  pos%d   max%d\n",ladi,pos,MaxLim);
				arrayprint(PosFinder,GrassCountend);
				
				if(MaxLim!=30*60){
				LadMapping[PosFinder[i]][PosFinder[pos]]++;
				LadMapping[PosFinder[pos]][PosFinder[i]]++;
				}
				if(MaxLim<16*60 && MaxLim>0){
					LadderYend[ladi]=MaxLim;
				}
				else{
					LadderYend[ladi]=0;
				}
				LadderNumend[ladi]=(0-GrassDummyY[i]+LadderYend[ladi])/60;
				ladi++;
				
				printf("\nLX: ");
				arrayprint(LadderXend,2*GrassCountend);
				printf("\nLY: ");
				arrayprint(LadderYend,2*GrassCountend);
				printf("\nLN: ");
				arrayprint(LadderNumend,2*GrassCountend);
			
			}
			
			
			for(i=0;i<GrassCountend;i++){
				GrassDummyX[i]=GrassDummyX[i]+GrassDummyNum[i]*60;
			}
			int MaxLim;
			arrayprint(PosFinder,GrassCountend);
			
			for(i=0;i<GrassCountend;i++){
				for(j=1;j<GrassCountend;j++){
					if(GrassDummyX[j-1]>GrassDummyX[j]){
						MaxLim=GrassDummyX[j];
						GrassDummyX[j]=GrassDummyX[j-1];
						GrassDummyX[j-1]=MaxLim;
						MaxLim=GrassDummyY[j];
						GrassDummyY[j]=GrassDummyY[j-1];
						GrassDummyY[j-1]=MaxLim;
						MaxLim=GrassDummyNum[j];
						GrassDummyNum[j]=GrassDummyNum[j-1];
						GrassDummyNum[j-1]=MaxLim;
						kkk=PosFinder[j-1];
						PosFinder[j-1]=PosFinder[j];
						PosFinder[j]=kkk;
						
					}
				
				
				}
			
			
			}
			
			arrayprint(PosFinder,GrassCountend);
			
			printf("LADDER Right\n");
			
			
			printf("\nGrassX:");
			arrayprint(GrassDummyX,GrassCountend);
			printf("\nGrassY:");
			arrayprint(GrassDummyY,GrassCountend);
			printf("\nGrassNUM:");
			arrayprint(GrassDummyNum,GrassCountend);
			
			//ladder Right(+60) to ground
			
				for(i=0;i<GrassCountend;i++){
					printf("pass1\n");
					limcount=0;
					for(j=0;j<GrassCountend;j++){
						LadYlim[j]=30*60;
					}
					brk=0;
					for(j=i+1;j<GrassCountend;j++){
						if((GrassDummyY[j]==GrassDummyY[i] && GrassDummyX[i]>=GrassDummyX[j]-GrassDummyNum[j]*60) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]>=GrassDummyX[i] && GrassDummyX[j]-GrassDummyNum[j]*60<GrassDummyX[i]) || (GrassDummyY[j]==GrassDummyY[i]-60 && GrassDummyX[j]==GrassDummyX[i])){
							brk=1;	
						}
					}
					if(brk==1){
						continue;
					}
					printf("pass2\n");
					printf("lim:%dpos:%d\n",limcount,pos);
					
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]>GrassDummyX[i] && GrassDummyX[j]-GrassDummyNum[j]*60<=GrassDummyX[i]){		
							LadYlim[limcount]=GrassDummyY[j];
							Ladpos[limcount]=j;
							limcount++;
						}
					
				
					}
					MaxLim=30*60;
					printf("i=%d ",i);
					arrayprint(LadYlim,GrassCountend);
					for(j=0;j<GrassCountend;j++){
						if(LadYlim[j]>GrassDummyY[i] && MaxLim>=LadYlim[j] && LadYlim[j]<18*60 && LadYlim[j]>0){
							MaxLim=LadYlim[j];
							pos=Ladpos[j];
						}
					}
				
				
				
					if(MaxLim==30*60){
						for(j=0;j<GrassCountend;j++){
							if(GrassDummyX[j]==GrassDummyX[i] && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
								MaxLim=GrassDummyY[j];
								pos=j;
								break;
							}
					
				
						}
				
					}
					
					if(MaxLim==30*60){
					for(j=0;j<GrassCountend;j++){
						if(GrassDummyX[j]-GrassDummyNum[j]*60==GrassDummyX[i]+60 && GrassDummyY[j]!=GrassDummyY[i]+60 && GrassDummyY[i]<GrassDummyY[j]){		
							MaxLim=GrassDummyY[j];
							pos=j;
							break;
						}
					
				
					}
				
				}
				
				
				
					printf("\n%d  pos%d   max%d\n",ladi,pos,MaxLim);
					arrayprint(PosFinder,GrassCountend);
					LadderXend[ladi]=GrassDummyX[i];
					printf("PossFinder[i]: %d\t PossFinder[pos]:%d\n",PosFinder[i],PosFinder[pos]);
					if(MaxLim!=30*60){
					LadMapping[PosFinder[i]][PosFinder[pos]]++;
					LadMapping[PosFinder[pos]][PosFinder[i]]++;
					}
					
					printf("%d\n",MaxLim);
					
					if(MaxLim<16*60 && MaxLim>0){
						LadderYend[ladi]=MaxLim;
					}
					else{
						LadderYend[ladi]=0;
					}
					LadderNumend[ladi]=(0-GrassDummyY[i]+LadderYend[ladi])/60;
					ladi++;
					printf("\nLadderX: ");
					arrayprint(LadderXend,2*GrassCountend);
					printf("\nLadderY: ");
					arrayprint(LadderYend,2*GrassCountend);
					printf("\nLadderNUM: ");
					arrayprint(LadderNumend,2*GrassCountend);
			
			}
			printf("pos:");
			
			//single grassfield removing
			
			int connected[GrassCountend],connect=0;
			int unconnected[GrassCountend];
			
			for(i=0;i<GrassCountend;i++){
				int no_connection=0;
				for(j=0;j<GrassCountend;j++){
					if(LadMapping[i][j]!=0){
					no_connection=1;
					break;
					}
				
				}
				if(no_connection==0){
					connected[connect]=i;
					connect++;
					GrassYend[i]=-100;
				}
			
			
			}
			
			
			
			
			//Ladder map modifying && sequencing
			kkk=0;
			int k;
			for(i=0;i<GrassCountend;i++){
				for(j=0;j<GrassCountend;j++){
					if(kkk==1 && rand()%2==0 && LadMapping[i][j]==2){
						LadMapping[i][j]=1;
						LadMapping[j][i]=1;
						for(k=0;k<GrassCountend;k++){
							if((LadderXend[k]==GrassXend[i] && LadderYend[k]==GrassYend[j])){
								LadderYend[k]=0;
							}
							else if((LadderXend[k]==GrassXend[j] && LadderYend[k]==GrassYend[i])){
								LadderYend[k]=0;
							}
						}
						
					}
					else if(kkk==1 && rand()%2==1 && LadMapping[i][j]==2){
						continue;
					}
					if(LadMapping[i][j]==2){
						kkk=1;
					}
				}
			
			
			
			}

			int firstup= FirstUp(GrassXend,GrassYend,GrassCountend);
			int lastup= LastUp(GrassXend,GrassYend,GrassNumend,GrassCountend);
			
			connected[connect]=firstup;
			connect++;
			
			for(i=0;i<connect;i++){
				for(j=0;j<GrassCountend;j++){
					int nc=0;
					for(k=0;k<connect;k++){
						if(j==connected[k]){
							nc=1;
						}
					}
					
					if(LadMapping[connected[i]][j]!=0 && nc==0){
						connected[connect]=j;
						connect++;
						i=0;
						break;
					
					}
				}
			}
			
			connect=0;
			for(i=0;i<connect;i++){
				int nc=0;
				for(j=0;j<GrassCountend;j++){
					if(i==connected[j]){
						nc=1;
						break;
					}
				}
				
				if(nc==0){
					unconnected[connect]=i;
					connect++;
				}
			}
			
			for(i=0;i<connect;i++){
				for(j=0;j<GrassCountend;j++){
					int nc=0;
					for(k=0;k<connect;k++){
						if(j==unconnected[k]){
							nc=1;
						}
					}
					
					if(LadMapping[unconnected[i]][j]!=0 && nc==0){
						unconnected[connect]=j;
						connect++;
						i=0;
						break;
					
					}
				}
			}
			
			printf("CONNECTED:");
			arrayprint(connected,GrassCountend);
			
			printf("\nUNCONNECTED:");
			arrayprint(unconnected,GrassCountend);
			
			
			arrayprint(PosFinder,GrassCountend);
			matrixprint(LadMapping,GrassCountend);
			
			int jacky=GrassYend[firstup];
			
			int jackx;
			
			int endy=GrassYend[lastup],endx;
			
			
				GrassNumend[lastup]=GrassNumend[lastup]+3;
				endx=GrassXend[lastup]+(GrassNumend[lastup]-1)*60;
			

			printf("\nendx:%d endy:%d\n",endx,endy);
			
			
			if(GrassNumend[firstup]>=4){
				jackx=GrassXend[firstup]+3*60;
			}
			else{
				jackx=GrassXend[firstup];
			}
			
			printf("firstup:%d",firstup);
			
			SDL_Event ev;
			
			
			//SWITCH & DOOR CONFIG:			
			int switchRendX,switchRendY;
			int switchGendX,switchGendY;
			int switchBendX,switchBendY;
			int switchYendX,switchYendY;
			
			int doorRendX,doorRendY;
			int doorGendX,doorGendY;
			int doorBendX,doorBendY;
			int doorYendX,doorYendY;
			
			
			doorRendX=endx-60;
			doorRendY=endy;
			
			int singlelad=0,p,single[GrassCountend]={0};
			for(i=0;i<GrassCountend;i++){
				p=0;
				for(j=0;j<GrassCountend;j++){
					if(LadMapping[i][j]==1){
						p++;
					}
				}
				if(p==1){
					single[i]=1;
					singlelad++;
				}
			}
			
			for(j=0;j<singlelad;j++){
				for(i=0;i<GrassCountend;i++){
					if(single[i]==1){
						if(j==0){
						switchRendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchRendY=GrassYend[i];
						
						doorGendX=switchRendX-60;
						doorGendY=GrassYend[i];
						}
						else if(j==1){
						switchGendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchGendY=GrassYend[i];
						
						doorBendX=switchGendX-60;
						doorBendY=GrassYend[i];
						
						
						}
						else if(j==2){
						switchBendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchBendY=GrassYend[i];
						
						doorYendX=switchBendX-60;
						doorYendY=GrassYend[i];
						
						
						}
						else if(j==3){
						switchYendX=GrassXend[i]+60*((rand()%GrassNumend[i]-1)+1);	
						switchYendY=GrassYend[i];
						
						
						
						}
				
					}
				}
			}
			
			int a=rand()%GrassCountend,BoxX1=GrassXend[a]+60*(rand()%GrassNumend[a]),BoxY1=GrassYend[a];
			int b=rand()%GrassCountend;
			while(b==a){
			b=rand()%GrassCountend;
			}
			int BoxX2=GrassXend[b]+60*(rand()%GrassNumend[b]),BoxY2=GrassYend[b];
			
			int c=rand()%GrassCountend;
			while(b==c || a==c){
			c=rand()%GrassCountend;
			}
			int BarX=GrassXend[c]+60*(rand()%GrassNumend[c]),BarY=GrassYend[c];
			while(i!=-1){
			
			int BoxCountend=2;
			int BoxXend[]={BoxX1,BoxX2};
			int BoxYend[]={BoxY1,BoxY2};
			
			int DoorCount=4;
			int DoorX[]={doorRendX,doorGendX,doorBendX,doorYendX};
			int DoorY[]={doorRendY,doorGendY,doorBendY,doorYendY};
			int DoorColour[]={RED,GREEN,BLUE,YELLOW};
			int barrierCount=0;
			int barrierX[]={0};
			int barrierY[]={0};
			
			Box(BoxXend,BoxYend,BoxCountend,boxright,boxleft,boxfall);
			
			
			int rvalid=RightValid(GrassXend,GrassYend,GrassNumend,GrassCountend,BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall,DoorCount,DoorX,DoorY,LadderXend,LadderYend,LadderNumend,barrierCount,barrierX,barrierY);
			int lvalid=LeftValid(GrassXend,GrassYend,GrassNumend,GrassCountend,BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall,DoorCount,DoorX,DoorY,LadderXend,LadderYend,LadderNumend,barrierCount,barrierX,barrierY);
			int dvalid=DownValid(LadderXend,LadderYend,LadderNumend,2*GrassCountend,BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall);
			int uvalid=UpValid(LadderXend,LadderYend,LadderNumend,2*GrassCountend,BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall);
			int boxrvalid=BoxRightValid(BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall,GrassXend,GrassYend,GrassNumend,GrassCountend,DoorX,DoorY,DoorCount);
			int boxlvalid=BoxLeftValid(BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall,GrassXend,GrassYend,GrassNumend,GrassCountend,DoorX,DoorY,DoorCount);
			
			BARL(BarX,BarY,barright,barleft,barfall);
			
			
			
			if(SDL_PollEvent(&ev)){
			
				if(ev.key.keysym.sym==SDLK_RIGHT && rvalid==1){
					right++;
					for(j=0;j<BoxCountend;j++){
						if(boxrvalid==j+1){
						
							boxright[j]++;
						}
					}
				}
				else if(ev.key.keysym.sym==SDLK_LEFT && lvalid==1){
					left++;
					for(j=0;j<BoxCountend;j++){
						if(boxlvalid==j+1){
						
							boxleft[j]++;
						}
					}
				}
				else if(ev.key.keysym.sym==SDLK_UP && uvalid==1){
					up++;
				}
				else if(ev.key.keysym.sym==SDLK_DOWN && dvalid==1){
					down++;
				}
	
			}
			
			
			SDL_RenderClear(rend);
			int fvalid;
			Grass(GrassCountend,GrassXend,GrassYend,GrassNumend);
			Lad(2*GrassCountend,LadderXend,LadderYend,LadderNumend);
			Scroll(endx,endy);
			Jack(jackx,jacky,fall,right,left,up,down,uvalid,dvalid,fvalid);
			
			fvalid=FallValid(GrassXend,GrassYend,GrassNumend,GrassCountend,LadderXend,LadderYend,LadderNumend,2*GrassCountend,BoxCountend,BoxXend,BoxYend,boxright,boxleft,boxfall,barrierX,barrierY,barrierCount,DoorX,DoorY,DoorCount);
			if(fvalid==1){
				fall++;
			}



			
			
			
			
			
			
			
			int SwitchCount=4;
			int SwitchConend[]={0,0,0,0};
			int SwitchX[]={switchRendX,switchGendX,switchBendX,switchYendX};
			int SwitchY[]={switchRendY,switchGendY,switchBendY,switchYendY};
			int SwitchColour[]={RED,GREEN,BLUE,YELLOW};
			
			for(i=0;i<SwitchCount;i++){
				SwitchConend[i]=SwitchCondition(SwitchX,SwitchY,i,BoxXend,BoxYend,boxright,boxleft,boxfall,BoxCountend);
				}
			
			
			Switch(SwitchCount,SwitchX,SwitchY,SwitchColour,SwitchConend);
			
			Door(DoorCount,DoorX,DoorY,DoorColour,SwitchConend);
			
			
		
			
			
			
			SDL_RenderPresent(rend);
			SDL_Delay(20);
			
			}
		}
	}	
	SDL_Delay(1000000);

	SDL_Quit();

}

